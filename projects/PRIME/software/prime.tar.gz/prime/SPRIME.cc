// Copyright (c) 2008 by the University of Oregon
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Oregon, Computer and Information
// Sciences Department, Mirage Lab.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF Oregon makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// SPRIME.cc 
//      Code for the 'Sender Agent' 
//
// Author: 
//   Nazanin Magharei (nazanin@cs.uoregon.edu)
//
       
#include "RPRIME.h"
#include <assert.h>
#include <errno.h>


SPALApp * spal[MAX_NODES+2];
RPALApp * rprime[MAX_NODES+2];
UdpAgent * udname[MAX_NODES+2];
RapAgent * rname[(MAX_NODES+2) * 2*n_max ];
UdpAgent * srudp[MAX_NODES+2];


static class SPALClass : public TclClass
{
    public:
	SPALClass() : TclClass("Application/SPAL") {}

        TclObject* create(int, const char*const*)
        {
        	return new SPALApp();
        }
} class_spal;

void PlayoutTimer::expire(Event *)
{
        a_->startplaying();
}

void SPRIMEMessage::freepoint(AppData * data)
{
  if(data->type()==SPRIME_MSG){
  SPRIMEMessage * msg = (SPRIMEMessage*) data;
  if(msg->curbitmap!=NULL && msg->sender_id_!=0 && msg->length>0) {free(msg->curbitmap);}
 }
}

SPALApp::SPALApp(): sid_(0), n_maxp(n_max), requestindex(0), datapkt(0), playtime_(0),playtime2(-(20*PKT_PER_SEC)),startsending(0),
stopped(0),population(0),playtimer_(this),SRC_Win(20),SRC_D(n_max),DEBUG_opt(0),DEBUG_opt2(0),DEBUG_dupreq(0),DEBUG_swap(0),tempindex(0),DEBUG_lossrecov(0), DEBUG_Totext(0),DEBUG_Totreg(0),DEBUG_Tot(0),DEBUG_TotOverext(0),
DEBUG_TotOverreg(0),DEBUG_TotOver(0), DEBUG_OverWrite(0),firstreceiver(0),extra(0), DEBUG_Aggsend(0),DEBUG_Aggsend1(0),DEBUG_Aggsend2(0),DEBUG_Aggsend3(0),DEBUG_AggExtra(0),DEBUG_Aggsend4(0),firstslide(1),
startcou(0),starttime(0),late(0),late1(0),late2(0),late3(0),redundant(0),WindowStart_(0),WindowLast_(0),WindowPkt_(0),MAX_TS(0),tr_id(0),tracefile(1),
tr_sttime(0),tr_ftime(0),sdump(0),FILEEND(0),dump(50)
{
	bind("sid_", &sid_);
//	Tcl &tcl2 = Tcl::instance();
	int i;
	FILE * fp=fopen("sin.in","r");
	if(fp!=0) {fscanf(fp,"%d %d", &SRC_Win,&SRC_D);
		fclose(fp);}
		ldump=(PKT_PER_SEC*(SRC_Win*2))+1000;
		for(i=0;i<n_max;i++)
		                {bitmabk[i] = (PktList*) malloc(2048*sizeof(PktList));
		                                 bzero(bitmabk[i],2048*sizeof(PktList));}
	printf("src_win %d %d %d %d\n",SRC_Win,n_maxp,DEBUG_opt,SRC_D);
	playtime2=(-PKT_PER_SEC*SRC_Win);
//	bzero(GenTime,sizeof(GenTime));
//	playtime=(PKT_PER_SEC * SRC_Win * 0.5);
        start_all();	
}

void SPALApp::start_all()
{	int i;
	reclist = (ReceiverList*) malloc(n_maxp * sizeof(ReceiverList)); 
	bzero(reclist,n_maxp*sizeof(ReceiverList));
	
	buffersize=(int*) malloc(n_maxp * sizeof(int));
	
	drainindex=(int*) malloc(n_maxp * sizeof(int));
	bzero(drainindex,n_maxp *sizeof(int));
	
	startindex=(int*) malloc(n_maxp * sizeof(int));
	numbk_=(int*) malloc(n_maxp * sizeof(int));
	
	DEBUG_OverCount=(int*) malloc(n_maxp * sizeof(int));
	bzero(DEBUG_OverCount,n_maxp*sizeof(int));
	
	extlength=(int*) malloc(n_maxp * sizeof(int));
	bzero(extlength,n_maxp*sizeof(int));
	
	reglength=(int*) malloc(n_maxp * sizeof(int));
	bzero(reglength,n_maxp*sizeof(int));
	
	DEBUG_Overext=(float*) malloc(n_maxp * sizeof(float));
	bzero(DEBUG_Overext,n_maxp*sizeof(float));
	
	DEBUG_Overreg=(float*) malloc(n_maxp * sizeof(float));
	bzero(DEBUG_Overreg,n_maxp*sizeof(float));

	DEBUG_Over=(float*) malloc(n_maxp * sizeof(float));
	bzero(DEBUG_Over,n_maxp*sizeof(float));

	index_=(int*) malloc(n_maxp * sizeof(int));
	bzero(index_,n_maxp*sizeof(int));
	
	listsize=(int*) malloc(n_maxp * sizeof(int));

	firstseq=(int*) malloc(n_maxp * sizeof(int));
	bzero(firstseq,n_maxp*sizeof(int));
	
	num_=(int*) malloc(n_maxp * sizeof(int));
	bzero(num_,n_maxp*sizeof(int));

	recbngindex=(int*) malloc(n_maxp * sizeof(int));
	bzero (recbngindex,n_maxp*sizeof(int));
	
	recendindex=(int*) malloc(n_maxp * sizeof(int));
	bzero (recendindex,n_maxp *sizeof(int));
	
	DEBUG_BTReq=(int*) malloc(n_maxp * sizeof(int));
	bzero(DEBUG_BTReq,n_maxp * sizeof(int));
	
	firstlistaloc=(int*) malloc(n_maxp * sizeof(int));
	bzero (firstlistaloc,n_maxp * sizeof(int));
	
	first=(int*) malloc(n_maxp * sizeof(int));
	 bzero (first,n_maxp * sizeof(int));
	 
	seq=(int*) malloc(n_maxp * sizeof(int));
	bzero(seq,n_maxp * sizeof(int));
	
	repid=(int*) malloc(n_maxp * sizeof(int));
	bzero(repid,n_maxp * sizeof(int));
	
	
	occupy=(int*) malloc(n_maxp * sizeof(int));
	bzero(occupy,n_maxp*sizeof(int));
	
	drainbk=(int*) malloc(n_maxp * sizeof(int));
	bzero(drainbk,n_maxp * sizeof(int));
	
	repbk=(int*) malloc(n_maxp * sizeof(int));
	bzero(repbk,n_maxp * sizeof(int));
	
	numExtra=(int*) malloc(n_maxp * sizeof(int));
	bzero(numExtra,n_maxp * sizeof(int));
	
	LossReq=(int*) malloc(n_maxp * sizeof(int));
	bzero(LossReq,n_maxp * sizeof(int));
	
	LossStart=(int*) malloc(n_maxp * sizeof(int));
	bzero(LossStart,n_maxp * sizeof(int));
	
	seqStart=(int*) malloc(n_maxp * sizeof(int));
	bzero(seqStart,n_maxp * sizeof(int));
	
	ReqTime=(float*) malloc(n_maxp * sizeof(float));
	bzero(ReqTime,n_maxp * sizeof(float));
	
	
	for(i=0;i<n_maxp;i++)
	         {buffersize[i]=512;
	          buffermap[i]= (PktList*) malloc(buffersize[i]*sizeof(PktList));
	          bzero(buffermap[i],buffersize[i]*sizeof(PktList));
    		  reclist[i].listid=0;
		  listsize[i]=512;
                  bitmabk[i] = (PktList*) malloc(2048*sizeof(PktList));
		  bzero(bitmabk[i],2048*sizeof(PktList));
                }	
}

void SPALApp::zero_all()
{	int i;
        requestindex=0; 
        datapkt=0; playtime_=0;
        startsending=0;
        stopped=0;
        DEBUG_opt2=0;DEBUG_dupreq=0;DEBUG_swap=0;tempindex=0;DEBUG_lossrecov=0; DEBUG_Totext=0;DEBUG_Totreg=0;DEBUG_Tot=0;DEBUG_TotOverext=0;
        DEBUG_TotOverreg=0;DEBUG_TotOver=0; DEBUG_OverWrite=0;firstreceiver=0;extra=0; DEBUG_Aggsend=0;DEBUG_Aggsend1=0;DEBUG_Aggsend2=0;DEBUG_Aggsend3=0;DEBUG_AggExtra=0;DEBUG_Aggsend4=0;firstslide=1;
        startcou=0;starttime=0;late=0;late1=0;late2=0;late3=0;redundant=0;WindowStart_=0;WindowLast_=0;WindowPkt_=0;MAX_TS=0;
        
	FILE * fp=fopen("sin.in","r");
	if(fp!=0) {fscanf(fp,"%d %d", &SRC_Win,&SRC_D);
		fclose(fp);}
		for(i=0;i<n_max;i++)
                { bzero(bitmabk[i],2048*sizeof(PktList));}
	printf("zero all src_win %d %d %d %d\n",SRC_Win,n_maxp,DEBUG_opt,SRC_D);
	playtime2=(-PKT_PER_SEC*SRC_Win);
	bzero(reclist,n_maxp*sizeof(ReceiverList));
	
	
	bzero(drainindex,n_maxp *sizeof(int));
	
	
	bzero(DEBUG_OverCount,n_maxp*sizeof(int));
	
	bzero(extlength,n_maxp*sizeof(int));
	
	bzero(reglength,n_maxp*sizeof(int));
	
	bzero(DEBUG_Overext,n_maxp*sizeof(float));
	
	bzero(DEBUG_Overreg,n_maxp*sizeof(float));

	bzero(DEBUG_Over,n_maxp*sizeof(float));

	bzero(index_,n_maxp*sizeof(int));
	

	bzero(firstseq,n_maxp*sizeof(int));
	
	bzero(num_,n_maxp*sizeof(int));

	bzero (recbngindex,n_maxp*sizeof(int));
	
	bzero (recendindex,n_maxp *sizeof(int));
	
	bzero(DEBUG_BTReq,n_maxp * sizeof(int));
	
	
	 bzero (first,n_maxp * sizeof(int));
	 
	
	bzero(seq,n_maxp * sizeof(int));
	
	bzero(repid,n_maxp * sizeof(int));
	
	bzero(occupy,n_maxp*sizeof(int));
	
	bzero(drainbk,n_maxp * sizeof(int));
	
	bzero(repbk,n_maxp * sizeof(int));
	
	bzero(numExtra,n_maxp * sizeof(int));
	
	bzero(LossReq,n_maxp * sizeof(int));
	
	bzero(LossStart,n_maxp * sizeof(int));
	
	bzero(seqStart,n_maxp * sizeof(int));
	
	bzero(ReqTime,n_maxp * sizeof(float));
	
	
	for(i=0;i<n_maxp;i++)
	         {
	          bzero(buffermap[i],buffersize[i]*sizeof(PktList));
                 }
	for(i=0;i<n_maxp;i++)
		{
		 reclist[i].listid=0;
		}

}

void SPALApp::stop()
{	if(sid_==0) n_maxp=SRC_D;
	static FILE *fp = fopen("SPRIMEOverwrite.out", "a+");
	if(fp==0) fp = fopen("SPRIMEOverwrite.out", "w+");
	 static FILE *fp1 = fopen("Overwrite.out", "a+");
	 if(fp1==0) fp1 = fopen("Overwrite.out", "w+");
  	int i=0, totow = 0, totreq = 0,btreq=0;
	int j=0,count=0,k;
	for(j=0;j<requestindex;j++)
	{for (i = 0; i < MAX_LAYER; i++)
	 {	
		assert(reclist[j].listid<n_maxp);
		totreq += DEBUG_Requested[reclist[j].listid][i];
		btreq += DEBUG_BTReq[reclist[j].listid];
	 }
	 count+=DEBUG_OverCount[reclist[j].listid];      
	 if(fp!=0) {fprintf(fp, "%d -1 %d %d \t%.2f  %.2f %.2f \t%d %d %f %d %f\n", sid_ , reclist[j].id,totreq,100 * ((DEBUG_OverCount[reclist[j].listid] > 0) ? (float)DEBUG_Overext[reclist[j].listid] / (float)DEBUG_OverCount[reclist[j].listid] : 0),100 * ((DEBUG_OverCount[reclist[j].listid] > 0) ? (float)DEBUG_Overreg[reclist[j].listid] / (float)DEBUG_OverCount[reclist[j].listid] : 0),100 * ((DEBUG_OverCount[reclist[j].listid] > 0) ? (float)DEBUG_Over[reclist[j].listid] /(float) DEBUG_OverCount[reclist[j].listid] : 0),btreq,LossReq[reclist[j].listid],(seq[reclist[j].listid]>0) ? (float)LossReq[reclist[j].listid]/(float)seq[reclist[j].listid] : 0,LossStart[reclist[j].listid],(seqStart[reclist[j].listid]>0) ? (float)LossStart[reclist[j].listid]/(float)seqStart[reclist[j].listid] : 0);
		    fflush(fp);}
 	 totow=0;
         totreq=0;
         btreq=0;
	}
	if(fp!=0) {fprintf(fp,"-2 %d %d %d %d %d %.2f %.2f %d %d\n",DEBUG_Aggsend,DEBUG_AggExtra,DEBUG_Totext,DEBUG_Totreg,DEBUG_Tot,DEBUG_OverWrite,100* (count>0 ? (float)DEBUG_OverWrite/(float)count : 0),late,DEBUG_Aggsend4);
	           fprintf(fp,"-2 %d %.2f %d %.2f %d %.2f %d %.2f\n",DEBUG_TotOverext,100*(DEBUG_Totext>0 ? (float)DEBUG_TotOverext/(float)DEBUG_Totext : 0),DEBUG_TotOverreg,100*(DEBUG_Totreg>0 ? (float)DEBUG_TotOverreg/(float)DEBUG_Totreg : 0),DEBUG_TotOver,100*(DEBUG_Tot>0 ? (float)DEBUG_TotOver/(float)DEBUG_Tot: 0),late,100*(DEBUG_Tot>0 ? (float)late/(float)DEBUG_Tot: 0));
		   fflush(fp);
	          }
	 if(sid_!=0 && fp1!=0) {fprintf(fp1,"%d %d %d %d %d %d %.2f %.2f %.2f %d %.2f %.2f %.2f %d %d %d %d %d %d %.2f %.2f %d\n",sid_,DEBUG_Aggsend,DEBUG_AggExtra,DEBUG_Totext,DEBUG_Totreg,DEBUG_Tot,DEBUG_OverWrite,100* (count>0 ? (float)DEBUG_OverWrite/(float)count : 0),100*(DEBUG_Tot>0 ? (float)late/(float)DEBUG_Tot: 0),late,(DEBUG_Aggsend1>0 ? (float)late1/(float)DEBUG_Aggsend1 : 0),(DEBUG_Aggsend2>0 ? (float)late2/(float)DEBUG_Aggsend2 : 0),(DEBUG_Aggsend3>0 ? (float)late3/(float)DEBUG_Aggsend3 : 0),late1,late2,late3,DEBUG_Aggsend1,DEBUG_Aggsend2,DEBUG_Aggsend3,((350-starttime) >0) ? (float)((DEBUG_Aggsend+DEBUG_AggExtra)*8)/(350-starttime) : 0,starttime,DEBUG_lossrecov); }

        if(sid_==0)
          {int unreq=0,dup=0,req=0;
           int startts=PKT_PER_SEC*SRC_Win*2;
           int MAX=(playtime2<MAX_TS ? playtime2 : MAX_TS);
           int tempmax_ts=MAX_TS;
           int swar1=0,swar2=0;
           MAX_TS=MAX;
           for(i=startts;i<MAX;i++)
           { for(j=0;j<MAX_LAYER;j++)
              {if(sendbuf[j][i]<=0) unreq++;
               else if(sendbuf[j][i]>1) dup+=(sendbuf[j][i]-1);
               if(sendbuf[j][i]>0) req++;
              }
           }
           fprintf(fp,"-3 %d %d %d %d \t%.2f %.2f %.2f %.2f %d %d %d %d\n",MAX_TS*MAX_LAYER,req,unreq,dup,100*(req>0 ? (float)dup/(float)(dup+req) : 0),100*((MAX_TS*MAX_LAYER)>0 ? (float)unreq/(float)(MAX_TS*MAX_LAYER) : 0),( (DEBUG_Aggsend+DEBUG_AggExtra) > 0 ? (float)DEBUG_Aggsend/(float)(DEBUG_Aggsend+DEBUG_AggExtra) : 0),(float)((DEBUG_Aggsend+DEBUG_AggExtra)*8)/(350-starttime),DEBUG_opt,DEBUG_opt2,DEBUG_dupreq,DEBUG_swap); //src bw in Kb/s
           if(fp1!=0) {fprintf(fp1,"%d %d %d %d %d %d %.2f %.2f %.2f %.2f %.2f %.2f %.2f %d  %.2f %.2f %.2f %d %d %d %d %d %d %d %f %d\n",sid_,DEBUG_Aggsend,DEBUG_AggExtra,DEBUG_Totext,DEBUG_Totreg,DEBUG_Tot,DEBUG_OverWrite,100* (count>0 ? (float)DEBUG_OverWrite/(float)count : 0),100*(req>0 ? (float)dup/(float)(dup+req) : 0),100*(((MAX_TS-startts)*MAX_LAYER)>0 ? (float)unreq/(float)((MAX_TS-startts)*MAX_LAYER) : 0),( (DEBUG_Aggsend+DEBUG_AggExtra) > 0 ? (float)DEBUG_Aggsend/(float)(DEBUG_Aggsend+DEBUG_AggExtra) : 0),(float)((DEBUG_Aggsend+DEBUG_AggExtra)*8)/(350-starttime),100*(DEBUG_Tot>0 ? (float)late/(float)DEBUG_Tot: 0),late,(DEBUG_Aggsend1>0 ? (float)late1/(float)DEBUG_Aggsend1 : 0),(DEBUG_Aggsend2>0 ? (float)late2/(float)DEBUG_Aggsend2 : 0),(DEBUG_Aggsend3>0 ? (float)late3/(float)DEBUG_Aggsend3 : 0),late1,late2,late3,DEBUG_Aggsend1,DEBUG_Aggsend2,DEBUG_Aggsend3,datapkt,starttime,DEBUG_lossrecov);}
          }
          if(sid_!=0)
          { for(i=0;i<requestindex;i++)
            { assert(i>=0);
              assert(reclist[i].id>0);
              removeid(reclist[i].id,i); 
              if(requestindex==0) break;
              else i=-1;
              }
          }
          else  { for(i=0;i<requestindex;i++) {removeid(reclist[i].id,i);
                                                            if(requestindex==0) break;
                                                            else i=-1;}
                }    
          stopped=1;
          if(sid_!=0) zero_all();

}


int SPALApp::command(int argc, const char*const* argv)
{	
        Tcl& tcl = Tcl::instance();
        if (argc == 2) {
                if (strcmp(argv[1], "start") == 0) {
                        //start();
                        return (TCL_OK);
                }
                if (strcmp(argv[1], "stop") == 0) {
                        stop();
                        return (TCL_OK);
                }
        }
        else if (argc == 3) {
        	if (strcmp(argv[1], "attach-rap-agent") == 0) {
                        rap_ = (RapAgent*) TclObject::lookup(argv[2]);
                        if (rap_ == 0) {
                                tcl.resultf("no such agent %s", argv[2]);
                                return(TCL_ERROR);
                        }
                        rap_->attachApp(this);
                        return(TCL_OK);
                }
        }
        return (Application::command(argc, argv));
}

/*
In this function before starting the rap or tcp connections, peers as parents periodically send udp messages to their children containing their 
newly available packets OR if they have nothing yet, an empty packet. 
This function is triggered by a random timer and in each call send a udp message to only one child.
In source, this function is responsible for increasing source playtime
The second part of this function is for reading the trace file for peers arrival and departure time in source (in implementation this can be omitted)

*/
void SPALApp::sendingupdate()
{
 if(stopped) {return;}
 if(sid_==0) n_maxp=SRC_D;
 float randd=drand48()/2.0;
 int i,cou=0,temp1,temp2;
 if(randd==0) randd=drand48()/2.0;
 if(sid_!=0) {int len=rprime[sid_]->readts();
	      assert(requestindex<=n_maxp);
	      if( len!=0 )
	       {for(i=tempindex;i<requestindex;i++)
		 {if(reclist[i].active==1)
		   continue;
		  int temp=reclist[i].id; 
		  assert(temp<MAX_NODES);
		  int rapp= findemptrap(temp);
        	  reply= new RPRIMESigMSG;
	          int length;
        	  length=sendbitmap(i,reclist[i].listid);
	          reply->tp=rprime[sid_]->readtp();
        	  reply->tp2=rprime[sid_]->readtp2();
	          reply->tb=rprime[sid_]->readtbuf();
	          reply->sprime_id_=sid_;
        	  reply->rprime_id_=sid_;
        	  reply->dist=rprime[sid_]->distance;
	          reply->list_=NULL;
        	  reply->length=length;
	          reply->request_list_=NULL;
        	  if(length>0) 
        	  {reply->curbitmap=curbitma;
        	   reply->repid=repid[reclist[i].listid]++;
        	   reply->repbk=repbk[reclist[i].listid];
        	  }
		  else {reply->curbitmap=NULL;
		        reply->repid=repid[reclist[i].listid]; //send the last one
		        reply->repbk=repbk[reclist[i].listid];
		       } 
	          reply->request_flag_=1; // means this contains bitmap
        	  reply->emptrap=rapp;
	          int nbytes=reply->size();
	          assert(temp<MAX_NODES);
	          srudp[sid_]->connect((ns_addr_t)udname[temp]->faddr());
        	  srudp[sid_]->send(nbytes,reply);
		  cou++;
		  tempindex++;
		  if(tempindex>=requestindex) tempindex=0;
		  break;
	         }
               }
	      if(cou==0 && tempindex==0) {startsending=0;
	                                  return; //nothing left to be notified
	                                 } 
	      if(cou==0) tempindex=0;
	      
	      playtimer_.resched(randd/5.00);	
	      return;
	     }
}

/*
In this function before starting the rap or tcp connections, source periodically sends udp messages to their children containing its
newly available packets. 
This function is triggered by a timer every PKT_PER_SEC and also is responsible for increasing source playtime
and calling slidewindow when it has enough pkts to start sending to children (playtime_ >= (SRC_Win * PKT_PER_SEC) && requestindex >= Rec_Th)
*/
void SPALApp::startplaying()
{
 if(stopped) {return;}
 if(sid_==0) n_maxp=SRC_D;
 int i,cou=0,temp1,temp2;
 int rand2=0,rand3=0;
 if(requestindex!=0)  {rand2=rand() % requestindex;
			rand3=rand() % (requestindex+1);
		      }
if(sid_==0 && firstslide==0) {temp1=rand2<rand3 ? rand2 : rand3;
				    temp2= rand3>rand2 ? rand3 : rand2;
				    if(temp1>=requestindex) temp1=0;
				    if(temp2>requestindex) temp2=requestindex;
				    for(i=temp1;i<temp2;i++)
				    { assert(i<requestindex && i>=0);
				      if(reclist[i].active==1)
					continue;
				      else Sendudpfromsource(1,reclist[i].id,reclist[i].rapport);
				    }
				   } 
 if(stopped) return;

 if(TIME+SRC_Win>=30)
   { playtime_++;
     if(sid_==0) GenTime[playtime_]=TIME;
   }             
 if (startsending) 
 {
	playtime2++;
	WindowStart_++; // the last timestamp that it is announce
 }
 else if(playtime_ >= (SRC_Win * PKT_PER_SEC) && requestindex >= Rec_Th) //so we have enough pkts generated to start sending to receivers
  {startsending=1;
   slidewindow();
  }

   playtimer_.resched(1.0/PKT_PER_SEC);
}

/*
This function is called in source only and malloc sendbuf to keep track of how many pkts are send for each timestamp
By calling this function the actuall streaming will be initiallized.
*/
void SPALApp::slidewindow()
{	int i,j;
        static int firstsendbuf=1;
	if(sid_==0) n_maxp=SRC_D;
	
	if(sid_==0 && firstsendbuf)
	{
	 for(i=0;i<MAX_LAYER;i++)
	 { sendbuf[i] = (int*) malloc(MAX_SIM_TIME*PKT_PER_SEC*sizeof(int));
	   bzero(sendbuf[i],MAX_SIM_TIME*PKT_PER_SEC*sizeof(int)); 
	 } 
	   sendbufts=(int*) malloc(MAX_SIM_TIME*PKT_PER_SEC*sizeof(int));
	   bzero(sendbufts,MAX_SIM_TIME*PKT_PER_SEC*sizeof(int));
	 firstsendbuf=0;
	} 
	if(stopped) return;
	printf("%f window is slided %d %d\n",TIME,playtime_,requestindex);
	WindowPkt_=SRC_Win * PKT_PER_SEC;
	WindowStart_=WindowLast_+WindowPkt_; //at first it is w 
	WindowLast_=playtime_;
	firstslide=0;
	assert(requestindex<=n_maxp);
	for(i=0;i<requestindex;i++)
	 Sendudpfromsource(1,reclist[i].id,reclist[i].rapport);

}

/*
This function is called in source to send udp message to children
*/
void SPALApp::Sendudpfromsource(int flag,int rid,int rapport)
{	if(sid_==0)  n_maxp=SRC_D;
	if(stopped) return;
  	  reply= new RPRIMESigMSG;
          reply->tb=WindowStart_;
          reply->tp=playtime2;
	  reply->tp2=0;
	  reply->dist=0;
	  reply->dist2=0;
          reply->sprime_id_=sid_;
	  if(WindowStart_!=0)
		{ if(playtime2<0)
			  reply->length=WindowStart_*MAX_LAYER;
		  else reply->length=(WindowStart_-playtime2)*MAX_LAYER;
		}
          else reply->length=0;
	  reply->rprime_id_=-1;
          reply->list_=NULL;
	  reply->request_flag_=flag;
          reply->request_list_=NULL;
          reply->emptrap=rapport;
	  reply->curbitmap=NULL;
	  reply->repid=-1;
	  reply->repbk=-1;
	  reply->list_=NULL;
	  reply->request_list_=NULL;
          int nbytes=reply->size();
          assert(rid<MAX_NODES);
          assert(rid>0);
           srudp[sid_]->connect((ns_addr_t)udname[rid]->faddr());
           srudp[sid_]->send(nbytes,reply);
}

/*
Upon receiving a udp message in parent this function will be called.
If request_flag_ =0 -> request for bitmap
request_flag_ =1 -> request for content
request_flag_ =-1 -> departure notification or connection terminated by child
*/
void SPALApp::process_udp_data(int size, AppData* data)
{	static int all=0;
        if(sid_==0) {n_maxp=SRC_D;
                     if(all==0) {//start_all();
                                 printf("startall in source %f %d\n",TIME,n_maxp);
                                 all=1;}
                     }
        
	if(stopped) return;
        RPRIMESigMSG* message = (RPRIMESigMSG*) data;
	int i,temp,found=0,req=0,k;
	req=message->request_flag_;
	temp=message->rprime_id_;
	int temprap=0,nbytes;
	temprap= message->emptrap;
	int rapp=0;
	if(sid_==0 && req==0)
	{ //joining or leaving the system
	  rapp=findemptrap(temp);
	  for (k=0;k<requestindex;k++)
                 if (temp == reclist[k].id)  {reclist[k].time=TIME; break;};
	  if(rapp!=-1) // upto n_max rap connection at any time
           {  if (firstreceiver ==0 && requestindex>=Rec_Th)
	     { GenTime = (float*) malloc(sizeof(int)*MAX_SIM_TIME*PKT_PER_SEC); //only for source
	       bzero(GenTime,sizeof(GenTime));
	       startplaying();
	       firstreceiver =1;
	     }
 	       Sendudpfromsource(1,temp,rapp);
	   }
	   else {
	     Sendudpfromsource(-1,temp,-1);
           }
	 
	}
	else if(req==0)
	{ if(startsending==0) {//start_all();
	                       sendingupdate();
	                       startsending=1;}
	  rapp= findemptrap(temp);
	  for (k=0;k<requestindex;k++)
                 if (temp == reclist[k].id)  {reclist[k].time=TIME; break;};
          reply= new RPRIMESigMSG;
	  int length;
          if(rapp>=0) 
          {
           length=sendbitmap(k,reclist[k].listid);
	   reply->tp=rprime[sid_]->readtp();
	   reply->tp2=rprime[sid_]->readtp2();
	   reply->tb=rprime[sid_]->readtbuf();
           reply->sprime_id_=sid_;
	   reply->rprime_id_=sid_;
           reply->list_=NULL;
           reply->dist=rprime[sid_]->distance;
           reply->length=length;
	   reply->request_list_=NULL;
           if(length>0) {reply->curbitmap=curbitma;
                        reply->repid=repid[reclist[k].listid]++;
                        reply->repbk=repbk[reclist[k].listid];
                       } 
	   else {reply->curbitmap=NULL;
	         reply->repid=repid[reclist[k].listid];
	         reply->repbk=repbk[reclist[k].listid];
                }
           reply->request_flag_=1; // means this contains bitmap
          }
          else {reply->request_flag_=-1;
                reply->curbitmap=NULL;
                reply->repid=-1;
                reply->repbk=-1;
                reply->dist=rprime[sid_]->distance;
                reply->sprime_id_=sid_;
                reply->rprime_id_=sid_;
                reply->tp=rprime[sid_]->readtp();
                reply->tp2=rprime[sid_]->readtp2();
                reply->tb=rprime[sid_]->readtbuf();
                reply->list_=NULL;                      
                reply->request_list_=NULL;
                reply->length=0;
               } 
          reply->emptrap=rapp;
	  nbytes=reply->size();
	  if(sid_!=0) {reply->dist=rprime[sid_]->distance;
	               }
	  else  {reply->dist=0;
	         reply->dist2=0;}
	  assert(temp<MAX_NODES);
	  srudp[sid_]->connect((ns_addr_t)udname[temp]->faddr());
	  srudp[sid_]->send(nbytes,reply);
	}
	else  if(req==1)
	{found=0; 
	 if(sid_==0) assert(startsending); //only after startsending one can request for pkts from src
	 for(i=0;i<requestindex;i++)
	  if(reclist[i].id==temp) {found=1; reclist[i].time=TIME; break;}
 	 if (found==1)
	 { if(reclist[i].active==1) process_request(temp,temprap,message->request_list_,message->length,1,message->seq_,message->extlen,message->reglen);	  
	   else {assert(temprap<((MAX_NODES+1)*2*n_max)); assert(i<requestindex && i>=0); addid(temp,reclist[i].rapport,rname[temprap]->addr(),1,0,i); process_request(temp,temprap,message->request_list_,message->length,0,message->seq_,message->extlen,message->reglen);}
	 }
         else // there isn't any idle rap connection so request will be denied
         {if(sid_==0)	Sendudpfromsource(-1,temp,-1);
	  else 
	  {reply= new RPRIMESigMSG;
           reply->emptrap=0;
	   reply->request_flag_=-1;
	   reply->sprime_id_=sid_; 
	   reply->rprime_id_=sid_;
	   reply->curbitmap=NULL;
	   reply->repbk=-1;
	   reply->repid=-1;
	   reply->list_=NULL;
	   if(sid_!=0) {reply->dist=rprime[sid_]->distance;
                       }
	   else {reply->dist=0;
                 reply->dist2=0;}
	   
	   reply->request_list_=NULL;
 	   nbytes=reply->size();
 	   assert(temp<MAX_NODES);
	  srudp[sid_]->connect((ns_addr_t)udname[temp]->faddr());
	  srudp[sid_]->send(nbytes,reply);
	  }
	 }
 	} 
	else if(req==-1) // leave the system 
	{ found=0;
	  for(i=0;i<requestindex;i++)
           if(reclist[i].id==temp) {found=1; break;}
	  if(found==1) { if(reclist[i].active==1) 
	  		  removeid(temp,i);
			 else {	printf("remove %d from sending in %d \n",temp,sid_);
	                        removeid(temp,i);
				assert(requestindex>=0 && requestindex<=n_maxp);
			 }
			}
	} 		    
}

/* This is similar to a function in child code (rprime.cc) and is responsible for finding the index of rap connection. 
If it finds the index the return value is that index.
Otherwise, if all are full it returns -1
Or if it could add the new child (by addid), it will find an idle index and return it.
*/
int SPALApp::findemptrap(int rid)
{	int found=0,i,j,flag;
	if(sid_==0) n_maxp=SRC_D;
  for (i=0;i<requestindex;i++)
         if (rid == reclist[i].id) {found=1; break;} 
  if(found==1) {return reclist[i].rapport;} 
  else if(found != 1)
  {
   if(requestindex>n_maxp-1) return -1; 
   for (i=(sid_*2*n_max);i<(sid_*2*n_max)+n_maxp;i++)
   { j=0;
     flag=0;
     while(j<requestindex)
      if(reclist[j++].rapport==i) {flag=1; break;}
     if(flag!=1) break; 
   }
   if ( flag==1) return -1; 
   addid(rid,i,-1,0,1,1);
   	
  }
return i;
}

/*
Add a child to reclist.
id is the child id
loport is the rap index in the parent
dsport is the rap index in the child (destination)
act shows whether the connection is active meaning its corresponding rap/tcp is started yet or not
neww shows whether this is a new connection or an existing one
j is the index of the existing connection in reclist (if neww is 0, j has a meaning)
*/
void SPALApp::addid(int id,int loport ,int dsport,int act,int neww, int j)
{  int i;
   assert(id!=0 && id<MAX_NODES);
   
   if(sid_==0) n_maxp=SRC_D;
   if (neww)
   {reclist[requestindex].id=id;
    reclist[requestindex].rapport=loport;
    reclist[requestindex].recaddr=dsport;
    reclist[requestindex].active=act; 
	for (i=0;i<n_maxp;i++)
		if(occupy[i]==0) 
		{	
			reclist[requestindex].listid=i;
          		assert(reclist[requestindex].listid<n_maxp);
         		
	
			if(firstlistaloc[i]) bzero(list_[i],listsize[i] * sizeof(SendList));
			bzero(bitmabk[i],2048*sizeof(PktList));
			repid[i]=0;
			repbk[i]=0;
			drainbk[i]=0;
			drainindex[i]=0;
			
			bzero(Receiving[i],2010*sizeof(SendList));
			num_[i]=0;
			numbk_[i]=0;
			ReqTime[i]=0;
			first[i]=0;
			occupy[i]=1;
			index_[i]=0;
			firstseq[i]=0;
			break;
		}
    reclist[requestindex].time=TIME;
    fillnew(requestindex,id);
    requestindex++;
    assert(requestindex<=n_maxp);
    
  }
  else {
        assert(j<n_maxp);  
        reclist[j].time=TIME;
  }
}

/* This function terminates an existing connection, 
id is the child id
index is the index in reclist for that id
*/
void SPALApp::removeid(int id,int index)
{	if(sid_==0) n_maxp=SRC_D;
	assert(index<n_maxp); 
	assert(reclist[index].rapport<((MAX_NODES+1)*2*n_max));
	 if(!spal[id]->stopped && first[reclist[index].listid]) {
	 printf("rap agent stopped sender %d rec %d\n",sid_,id);
	 rname[reclist[index].rapport]->stop();
	 }
	 if(sid_==0) Sendudpfromsource(-1,id,-1);
	 else {				reply= new RPRIMESigMSG;
	                                reply->emptrap=0;
                                        reply->request_flag_=-1;
                                        reply->sprime_id_=sid_;
                                        if(sid_!=0)
                                         {reply->dist=rprime[sid_]->distance;
                                          }
                                        else {reply->dist=0; 
                                              reply->dist2=0;}
                                        reply->rprime_id_=sid_;
					reply->curbitmap=NULL;
					reply->repbk=-1;
					reply->repid=-1;
					reply->request_list_=NULL;
					reply->list_=NULL;
					reply->length=0;
					int nbytes=reply->size();
					assert(id<MAX_NODES);
                                        srudp[sid_]->connect((ns_addr_t)udname[id]->faddr());
					srudp[sid_]->send(nbytes,reply);
	 }

         int temp=reclist[index].listid;
	 assert(temp<n_maxp);
	 occupy[temp]=0;
	 if(firstlistaloc[temp]) bzero(list_[temp],listsize[temp]*sizeof(SendList));
	 repid[temp]=0;
	 repbk[temp]=0;
	 drainbk[temp]=0;
	 drainindex[temp]=0;
	 bzero(bitmabk[temp],2048*sizeof(PktList));
	 bzero(Receiving[temp],2010*sizeof(SendList));
	 first[temp]=0;
	 ReqTime[temp]=0;
	 requestindex--;
	 reclist[index]=reclist[requestindex];
	 reclist[requestindex].id=0;
	 reclist[requestindex].active=0;
	 reclist[requestindex].rapport=-1;
	 reclist[requestindex].recaddr=0;
	 assert(requestindex>=0);
}

/* This function is called by the receiver side of the peer and copy each arrived in buffermap for all children
*/
void SPALApp::fillcontent(int time,int layer)
{ 
 int i;
  for(i=0;i<requestindex;i++)
  {int ind=reclist[i].listid;
   if((drainindex[ind]+1)>=buffersize[ind])
   {printf("increased to %d\n",buffersize[ind]+128);
    buffersize[ind]=buffersize[ind]+128;
    buffermap[ind]=(PktList*) realloc(buffermap[ind],buffersize[ind]*sizeof(PktList));
   } 
   assert(layer>=0 && layer<MAX_LAYER);
   buffermap[ind][drainindex[ind]].layer_id=layer;
   buffermap[ind][drainindex[ind]].timestamp=time;
   drainindex[ind]++;
  }
}

/* Whenever a child is accepted, we should call this function to copy all the available packets in buffer to the buffermap of the new child. This is done for reporting available packets to the child
*/
void SPALApp::fillnew(int index,int id)
{ 
  int ind=reclist[index].listid;
  int playt=rprime[id]->playtime;
  int playp=rprime[sid_]->playtime;
  int st=(playp>playt) ? playp : playt;
  int j,i;  
  for(j=0;j<MAX_LAYER;j++)
  {if(st<=rprime[sid_]->BufEndIndex[j])
   {for(i=st;i<rprime[sid_]->BufEndIndex[j];i++)
    {if((drainindex[ind]+1)>=buffersize[ind])
     {printf("increased to %d\n",buffersize[ind]+128);
      if((buffersize[ind]+128)<=2048)
        buffersize[ind]=buffersize[ind]+128;
      buffersize[ind]=2048;  
      buffermap[ind]=(PktList*) realloc(buffermap[ind],buffersize[ind]*sizeof(PktList));
     }
     if(drainindex[ind]>=2047) { 
                                 break;
                               }  
     if(rprime[sid_]->buf[j][i%MAX_BUFFER].flag>0) 
     {buffermap[ind][drainindex[ind]].layer_id=j;
      buffermap[ind][drainindex[ind]].timestamp=i;
      drainindex[ind]++;
     } 
    }
   }  
  }  
 
}  

/*
This function is called whenever we want to send report (bitmap) to the child. 
We keep a backup pointer as we send each report twice to prevent any loss. However, if in implementation we are using tcp, we can 
omit the back up pointer.
(drainbk is the previous drainindex)
*/
int SPALApp::sendbitmap(int id,int listid)
{	if(sid_==0) n_maxp=SRC_D;
	
	int bitmapsize=0;
	bitindex=0;
	int i;
	int len=drainindex[listid];
	int lenbk=drainbk[listid];
	if(len+lenbk>0)
 	  curbitma=(PktList*) malloc((len+lenbk+10) * sizeof(PktList)); 
	else  {curbitma=NULL; repbk[listid]=0; assert(drainbk[listid]==0); return 0;}
	
	if(len>0 || lenbk>0)
        {
	 if(curbitma==NULL) {return -1;}
	 bzero(curbitma,(len+lenbk+10)*sizeof(PktList));
	 for(i=0;i<lenbk;i++)
	       curbitma[bitindex++]=bitmabk[listid][i];
         assert(len<2048);
           
	 for(i=0;i<len;i++)
		{curbitma[bitindex++]=buffermap[listid][i];
		 bitmabk[listid][i]=buffermap[listid][i];
		}
         repbk[listid]=drainbk[listid];
	 drainbk[listid]=len;	 
	 drainindex[listid]=0;
        }
        else {repbk[listid]=0;
              drainbk[listid]=0;
              assert(drainindex[listid]==0);
             } 
        assert(bitindex==(len+lenbk));
	bitmapsize= bitindex;
	return bitmapsize;	
}

/* This function processes the requests of children. 
id is the child id
rapid is the index of rap connection
request contains the packets that the child is requested
length is the length of that request
flag shows whether this the first request of this child or not (if this is the first we start rap connection and make the connection active reclist[tempid2].active)
seq_ is the seq number of the requests of this child
extlen is the portion of the request that is extra (based on deviation of bw rather than bw)
reglen is the portion of request in terms of number of packets based on bw estimation
-------------------------------
After taking care of some debugging metrics, we call PktToRec function to capture packets that are on the way to the receiver so we dont send them again, if requested.
Then, we zero index_[], make num_[] equal to length and copy request to the list_[][] while making sure the packets which are copied are not on their way to the child (AboutToRec serves this purpose)
*/	
void SPALApp::process_request(int id,int rapid,PktList* request,int length,int flag,int seq_,int extlen,int reglen)
{	if(stopped) return;
	if(sid_==0) n_maxp=SRC_D;
	int i, tempid,found=0,lay, count=0;
        int ts,tempid2;
       static FILE *fp20= fopen("SPRIMESendingTrace.out","w+");
	if(fp20==0) fp20= fopen("SPRIMESendingTrace.out","a+");
	assert(requestindex<=n_maxp);
	for (i=0;i<requestindex;i++)
           if (id == reclist[i].id) {found=1; break;}


          assert(found==1);
          tempid=reclist[i].listid;
          tempid2=i;
	
        if(flag==0)
        { reclist[tempid2].active=1;
	 assert(rapid<((MAX_NODES+1)*2*n_max));
          reclist[tempid2].recaddr=rname[rapid]->addr();
          assert(reclist[tempid2].rapport<((MAX_NODES+1)*2*n_max));
          rname[reclist[tempid2].rapport]->connect((ns_addr_t)rname[rapid]->faddr());
          rname[rapid]->connect((ns_addr_t)rname[reclist[tempid2].rapport]->faddr());
	  rname[rapid]->listen();
        }
	assert(tempid<n_maxp);
	ReqTime[tempid]=TIME;
	if(first[tempid]) 
	{	
		
		if(TIME<MAX_SIM_TIME)
		{ DEBUG_OverCount[tempid]++;
		  DEBUG_Totext+=extlength[tempid];
		  DEBUG_Totreg+=reglength[tempid];
		  DEBUG_Tot+=numbk_[tempid]-reglength[tempid]-extlength[tempid];
		  DEBUG_OverWrite+=(numbk_[tempid]>0 ? (float)num_[tempid]/(float)numbk_[tempid] : 0);
		  if(num_[tempid]>extlength[tempid] && extlength[tempid]>0)
		   {DEBUG_Overext[tempid]+=1;
		    DEBUG_TotOverext+=extlength[tempid];
		    num_[tempid]-=extlength[tempid];
		   }
		  else if(extlength[tempid]>0)
		      {DEBUG_Overext[tempid]+=(extlength[tempid]>0 ? (float)num_[tempid]/(float)extlength[tempid] : 0); 
		        DEBUG_TotOverext+=num_[tempid]; 
		        num_[tempid]=0;
		      }  
		  if(num_[tempid]>reglength[tempid] && reglength[tempid]>0)  
		   {DEBUG_Overreg[tempid]+=1;
		    DEBUG_TotOverreg+=reglength[tempid];
		    num_[tempid]-=reglength[tempid];
		   }
		  else if(reglength[tempid]>0)
		       {DEBUG_Overreg[tempid]+=(reglength[tempid]>0 ? (float)num_[tempid]/(float)reglength[tempid] : 0); 
		        DEBUG_TotOverreg+=num_[tempid];
		        num_[tempid]=0;
		       } 
		  if(num_[tempid]>0)
		   {DEBUG_Over[tempid]+=((numbk_[tempid]-reglength[tempid]-extlength[tempid])>0 ? (float)num_[tempid]/(float)(numbk_[tempid]-reglength[tempid]-extlength[tempid]) : 0);  
		    DEBUG_TotOver+=num_[tempid];
		   } 
		  
		   
		}   
                PktToRec(tempid);
	}
	if(firstlistaloc[tempid]==0 && length<listsize[tempid]) 
				{ list_[tempid]=(SendList*) malloc(listsize[tempid] * sizeof(SendList));
				  firstlistaloc[tempid]=1;}
	else if(firstlistaloc[tempid]==0 && length>=listsize[tempid]) 
				{listsize[tempid] *=2;
				 list_[tempid]=(SendList*) malloc(listsize[tempid] * sizeof(SendList));
				 firstlistaloc[tempid]=1;
				}
	if(length>=listsize[tempid] && firstlistaloc[tempid]!=0)
			{ while(listsize[tempid]<length) listsize[tempid] *=2;
			  list_[tempid]=(SendList*) realloc(list_[tempid],listsize[tempid]*sizeof(SendList));
			}
	if(length>=(listsize[tempid]-30) && firstlistaloc[tempid]!=0) 
	              { while(listsize[tempid]<length) listsize[tempid] *=2;
                        list_[tempid]=(SendList*) realloc(list_[tempid],listsize[tempid]*sizeof(SendList));
                      }		

	num_[tempid] = length; index_[tempid] = 0;
	numbk_[tempid]=length;
	extlength[tempid]=extlen;
	reglength[tempid]=reglen;
	if (num_[tempid] > 0) {
		bzero(list_[tempid],listsize[tempid]*sizeof(SendList));
		if( seq_-seq[tempid]>1 && seq_!=1) LossReq[tempid]++;
		if(seq_==1) { printf("total requests that were lost %d from %d in %d total %d\n",LossReq[tempid],id,sid_,seq[tempid]);
			      LossStart[tempid]=LossReq[tempid];
			      seqStart[tempid]=seq[tempid];
			      LossReq[tempid]=0;
			    }
		seq[tempid] = seq_;
	}
        for (i=0 ; i<num_[tempid]; i++)
         {    
	      lay=request[i].layer_id;
              ts= request[i].timestamp;
        	if(!AboutToRec(lay,ts,tempid)){    
		assert(count<=listsize[tempid]);
		list_[tempid][count].layer_id = lay;
		list_[tempid][count].timestamp = ts;
                count++;
              }
		if(lay!=-2 && lay!=-3) DEBUG_Requested[tempid][lay]++;
		if(lay==-2 || lay==-3) DEBUG_BTReq[tempid]++;
	}
        num_[tempid]=count;  
	if (!first[tempid]) 
	{	assert(tempid2<n_maxp);
		first[tempid] = 1;
		assert(reclist[tempid2].rapport<((MAX_NODES+1)*2*n_max) && rapid<((MAX_NODES+1)*2*n_max));
		int found=-1;
		for(i=0;i<rprime[id]->Grayindex;i++)
		  {if(rprime[id]->GrayList[i].nodid==sid_) 
		    {found=i; break;}
		  }  
		if(found>=0 && i<rprime[id]->Grayindex)
    		  rprime[id]->LastBWCalc[found]=TIME;
		rname[reclist[tempid2].rapport]->start();
		static int start=1;
		if(sid_==0 && start) {starttime=TIME; start=0;}
		if(sid_!=0 && !startcou) {starttime=TIME; startcou=1;}
		
	}
        numExtra[tempid]=0;

}

void SPALApp::findloss(int seqq,int rid)
{ int ts,lay,i,tempid=0;
   for (i=0;i<requestindex;i++)
    if (rid == reclist[i].id)
    { tempid=reclist[i].listid;
      break;
    }  
   if ((seqq-firstseq[tempid])<index_[tempid] && seqq>=firstseq[tempid])
   {   int ind=seqq-firstseq[tempid];
       assert (ind>=0 && ind<index_[tempid]);
       lay=list_[tempid][ind].layer_id;
       ts=list_[tempid][ind].timestamp;
       if(sid_==0)
       {
        if(lay>=0 && ts>=0 && list_[tempid][ind].seqq==seqq)
        {
         assert(list_[tempid][ind].seqq==seqq);
         sendbuf[lay][ts]--;
         sendbufts[ts]--;
         assert(sendbuf[lay][ts]>=0 && sendbufts[ts]>=0);
        }
       } 
       if(lay>=0 && ts>=0 && list_[tempid][ind].seqq==seqq)
       {DEBUG_lossrecov++; 
        if((index_[tempid]+num_[tempid])>=listsize[tempid])
         return;
        assert((index_[tempid]+num_[tempid])<listsize[tempid]);
        list_[tempid][index_[tempid]+num_[tempid]].layer_id=lay;
        list_[tempid][index_[tempid]+num_[tempid]].timestamp=ts;
        num_[tempid]++;
        assert(list_[tempid][ind].seqq==seqq);
       }
   }
}
                                                                                                                                                                                                                   
      
                                                 
/* This function is called by application level (rap or tcp) whenever we should send a rap/tcp message to a particular child.
If we dont have any outstanding packet in list_ to send, we will send a marked packet (-1,-1) 
otherwise, we decrement num_[], increment index_[] for the corresponding child.
Parent also sends the hopcount of each packet which is read through a function call in child side (rprime[sid_]->readhop(ts,lay)).
*/
AppData* SPALApp::get_prime_data(int& nbytes,int rapaddr)
{       int i,tempid;
	if(sid_==0) n_maxp=SRC_D;
	message_ = new SPRIMEMessage;
	int templist =0;
	for(i=0;i<requestindex;i++)
         if(reclist[i].recaddr==rapaddr) { templist=i; break;}
	
	tempid=reclist[i].listid;
	message_->sender_id_ = sid_;
	if(stopped)  {
			num_[tempid]=0;
		     }		
	int hopcou=0;
	int lay,ts;
	assert(tempid<n_maxp);
	if(num_[tempid]<=0)
        {       message_->layer_id_ = -1;
                message_->timestamp_ = -1;
                if(templist>=requestindex) tempid=0;
                numExtra[tempid]++;
		if(TIME<MAX_SIM_TIME) DEBUG_AggExtra++;
        }
        else if (num_[tempid] > 0) {
		if(TIME<MAX_SIM_TIME) {DEBUG_Aggsend++;
		              if(reclist[templist].id<21) DEBUG_Aggsend1++;
		              else if(reclist[templist].id<61) DEBUG_Aggsend2++;
		              else DEBUG_Aggsend3++;
		              } 
		if(sid_!=0) {
			hopcou=0;
			while(hopcou==0)
			{
			  if(num_[tempid]==0)
                         { lay = -1;
                           ts = -1;
                           hopcou=1;
                           message_->hopc=0;
                           numExtra[tempid]++;
                           break;
			 }
 			 else {assert(index_[tempid]<listsize[tempid] && index_[tempid]>=0);
				lay=list_[tempid][index_[tempid]].layer_id;
	                       ts=list_[tempid][index_[tempid]].timestamp;
	                       assert(reclist[templist].rapport<((MAX_NODES+1)*2*n_max));
	                       list_[tempid][index_[tempid]].seqq=rname[reclist[templist].rapport]->GetSeqno()+1;
	                       if (index_[tempid]==0) firstseq[tempid]=list_[tempid][index_[tempid]].seqq;
			       list_[tempid][index_[tempid]].time=TIME;
			       num_[tempid]--; index_[tempid]++;
        	               if((lay==-2 && ts==-2 ) || (lay==-3 && ts==-3 )) { hopcou=1; break;}
                	       else {hopcou= rprime[sid_]->readhop(ts,lay);}
 			 }
			 if(hopcou==0) 
			  {assert(i<requestindex); 
			   if(TIME<MAX_SIM_TIME) {late++;
			                             if(reclist[templist].id<21) late1++;
			                             else if(reclist[templist].id<61) late2++;
			                             else late3++;
			                            } 
			   
			  }
			 else {hopcou++;
	                       message_->hopc=hopcou;
			      }
			}
		
		}
		else { 
		//Source DEBUG_optimization
		        lay=list_[tempid][index_[tempid]].layer_id;
                        ts=list_[tempid][index_[tempid]].timestamp;
        	        source_opt(tempid,&lay,&ts);
			list_[tempid][index_[tempid]].time=TIME;
			list_[tempid][index_[tempid]].layer_id=lay;
			list_[tempid][index_[tempid]].timestamp=ts;
			assert(reclist[templist].rapport<((MAX_NODES+1)*2*n_max));
			list_[tempid][index_[tempid]].seqq=rname[reclist[templist].rapport]->GetSeqno()+1;
			if (index_[tempid]==0) firstseq[tempid]=list_[tempid][index_[tempid]].seqq;
			message_->hopc =1;
			num_[tempid]--;
                        index_[tempid]++;
		}
		message_->timestamp_= ts;
		message_->layer_id_=lay;
		if(ts<0) assert(lay<0);
	}
	assert(reclist[templist].rapport<((MAX_NODES+1)*2*n_max));
	message_->srtt_ = rname[reclist[templist].rapport]->srtt();
	int len=0;

        if(sid_!=0)
	{
	 len=sendbitmap(templist,tempid);
	 message_->length=len;
	 if(len>0) {message_->curbitmap=curbitma;
                    message_->repid=repid[tempid]++;
                    message_->repbk=repbk[tempid];
                   } 
	 else {message_->curbitmap=NULL;
	       message_->repid=repid[tempid];
	       message_->repbk=repbk[tempid];
	      } 
	 
	 message_->tb=rprime[sid_]->readtbuf();
	 message_->tp=rprime[sid_]->readtp();
	 message_->tp2=rprime[sid_]->readtp2();
	}
	else {
	 message_->tb=WindowStart_;
	 
	 if(message_->timestamp_>=0 && message_->layer_id_>=0)
	  { assert(message_->timestamp_<=MAX_SIM_TIME*PKT_PER_SEC);
	    assert(message_->layer_id_<MAX_LAYER);
	    sendbuf[message_->layer_id_][message_->timestamp_]++;
	    sendbufts[message_->timestamp_]++;    
	    if(MAX_TS<message_->timestamp_) MAX_TS=message_->timestamp_;  
	    if(TIME<MAX_SIM_TIME)
  	      {if(playtime2>message_->timestamp_) late++;
  	       DEBUG_Aggsend4++;
  	       }
	 }
	 message_->tp=playtime2;
	 message_->curbitmap=NULL;
	 message_->repid=-1;
	 message_->repbk=-1;
	 if(playtime2>0) message_->length=(WindowStart_-playtime2) * MAX_LAYER;
	 else message_->length=WindowStart_ * MAX_LAYER;
	}
	message_->sequence_ = seq[tempid];
	if(sid_!=0) message_->dist=rprime[sid_]->distance;
                    
	else {message_->dist=0;
	     message_->dist2=0;} 
	nbytes = PKT_SIZE;
        return message_;
}

/* This is for source optimization and finds the packet that is sent the fewest number of times
*/
void SPALApp::source_opt(int tempid,int *lay, int *ts)
{
       	       int k,flagg=0;
               *lay=list_[tempid][index_[tempid]].layer_id;
               *ts=list_[tempid][index_[tempid]].timestamp;
               if(DEBUG_opt>=0 && *ts>=0)
                       { if(*lay<0 || *lay >=MAX_LAYER)
                          printf("lay %d %d\n",*lay,*ts);
                         assert(*lay>=0 && *lay<MAX_LAYER);
                         int minlay=*lay;
                         int tempts=*ts;
                         int mints=*ts;
                         int minn=sendbufts[*ts];
                         if(sendbufts[tempts]>=(MAX_LAYER) && *ts>0)
                           tempts=*ts-1;
                         if(sendbufts[tempts]>=(MAX_LAYER))
                           tempts=*ts+1;
                         if(sendbufts[tempts]>=(MAX_LAYER))
                           {DEBUG_dupreq++; 
                            while(tempts>(*ts-120) && tempts>1 && sendbufts[tempts]>=(MAX_LAYER))
                             {  tempts--;
                                if(minn>sendbufts[tempts]) {minn=sendbufts[tempts]; mints=tempts;}
                             } 
                             
                            }
                            if(sendbufts[tempts]<(MAX_LAYER))
                             DEBUG_swap++;   
                            else tempts=mints; 
        		 *ts=tempts;
                         tempts=*ts;       
                         if(*ts<0) printf("ts %d %d\n",*ts,*lay);                 
                         assert(*ts>=0 && *lay>=0 && *lay<MAX_LAYER);
                         int min=sendbuf[*lay][*ts];
                         if(sendbuf[*lay][tempts]>0)
                          {for(k=0;k<MAX_LAYER;k++)
                           {if(sendbuf[k][tempts]<min)
                               {min=sendbuf[k][tempts];
                                minlay=k;
                               } 
                             if(sendbuf[k][tempts]>0)
                              continue;
                             else
                              {flagg=1;
                               break;
                              } 
                           }
                           if(flagg==1)
                            *lay=k; 
                           else {
                                 *lay=minlay;
                                 DEBUG_opt2++;
                                }   
                          }
                       }      
 }                      
/* This function stores all the packets that are sent but assumed not yet received in the child in an array called Receiving[][].
Further this array will be checked in AboutToRec and all packets that we think are going to be received in the next rtt, are not going to be sent if they are requested again.
*/
void SPALApp::PktToRec(int tempid)
{ if(sid_==0) n_maxp=SRC_D;
  int i=0,tempid2=0;
  int ReceivingTot=0;
  assert(tempid<n_maxp);
  for(i=0;i<requestindex;i++)
	if(reclist[i].listid==tempid) tempid2=i;
  for (i=0; i < index_[tempid]; i++) 
   if ((TIME - rname[reclist[tempid2].rapport]->srtt()) < list_[tempid][i].time )
   {   if (recendindex[tempid] >=2000) recendindex[tempid]=0;
       Receiving[tempid][recendindex[tempid]++] =list_[tempid][i];
       ReceivingTot++;
   } 
  if (ReceivingTot ==0) 
	{recbngindex[tempid]=0;
	 recendindex[tempid]=0;
	 return;}
  while(TIME-Receiving[tempid][recbngindex[tempid]].time > rname[reclist[tempid2].rapport]->srtt())
  {     if(recbngindex[tempid] >=2000) recbngindex[tempid]=0;
	else recbngindex[tempid]++;
  }     
}

/* This function finds out whether a packet with ts, layer is on the fly for a child (tempid) meaning, is it on its way to the destination or not yet sent.
This is done as we dont want to send duplicate packets to children
*/
int SPALApp::AboutToRec(int layer, int ts,int tempid)
{  int i;
  if(sid_==0) n_maxp=SRC_D;
  if(first[tempid])
    for (i=recbngindex[tempid]; i< recendindex[tempid]; i++)
     {  if(layer==-2 || layer==-3) return 0;
	assert(i<2000);

	assert(tempid<n_maxp);
       if(layer == Receiving[tempid][i].layer_id && ts == Receiving[tempid][i].timestamp)
       {
        return 1;}
    }  
   return 0;
}
