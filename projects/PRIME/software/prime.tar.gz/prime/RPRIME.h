// Copyright (c) 2008 by the University of Oregon
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Oregon, Computer and Information
// Sciences Department, Mirage Lab.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF Oregon makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// RPRIME.h 
//      Header Code for the 'Receiver Agent' 
//
// Author: 
//   Nazanin Magharei (nazanin@cs.uoregon.edu)
//
  
#ifndef ns_rpal_h
#define ns_rpal_h

#include "PRIMECommon.h"
#include "SPRIME.h"

class RPALApp;

class DrainTimer : public TimerHandler
{
     public:
	DrainTimer(RPALApp *a) : TimerHandler() { a_ = a; }
     protected:
	void expire(Event *e);
	RPALApp *a_;
};

class StartTimer : public TimerHandler
{
     public:
             StartTimer(RPALApp *a) : TimerHandler() { a_ = a; }
                  protected:
                  void expire(Event *e);
                  RPALApp *a_;
};

class StopTimer : public TimerHandler
{
     public:
                  StopTimer(RPALApp *a) : TimerHandler() { a_ = a; }
                        protected:
                        void expire(Event *e);
                        RPALApp *a_;
};
                                                                                                          
class EWMABWTimer : public TimerHandler
{
     public:
	EWMABWTimer(RPALApp *a) : TimerHandler() { a_ = a; }
     protected:
	void expire(Event *e);
	RPALApp *a_;
};

class PendRequest : public TimerHandler
{
     public:
             PendRequest(RPALApp *a) : TimerHandler() { a_ = a; }
                  protected:
                          void expire(Event *e);
                                  RPALApp *a_;
};
                                  
                                  
struct ConTab {		//this struct is for table in receivers
  int flag; 	//to show the availability of this packet
  int Listid[n_max];  
  int Listind[n_max];  
 };
 
struct buffer {
  int flag;
  int hopcount;
  float time;
};

class RPALApp : public Application
{
    public:
        RPALApp();
        ~RPALApp() {};

        void process_sigmsg_data(int size, AppData* data);
        void process_udp_data(int size, AppData* data);
        void process_udpboot_data(int size, AppData* data);
        void process_rap_data(int size, AppData* data);
        int command(int argc, const char*const* argv);
	void Drain();
	void PendingReq();
	void PendingAss();
	void CalculateEWMABW();
        void start();
        void stop();
        int readtp();
        int readtp2();
        int readtbuf();
        int readhop(int timestamp,int layer);
        int readts();
        int * readlast();
        buffer ** readbuf();
	int n_maxp,n_minp;
	int activeindex;
        float recrapconnection[n_max][3];
	int distance,distance_ch1,distance_ch2,difindex,stdifindex,stopped_;
	float tr_down,tr_start,*LastBWCalc,distance_t;
	PktList * rare;
	buffer *buf[MAX_LAYER + 1];
	buffer difbuf[MAX_BUFFER];
	int playtime,BufEndIndex[MAX_LAYER],startup,Grayindex;
	StartTimer starttimer_;
	StopTimer stoptimer_;
        nodelist * GrayList;
        void Dumpsnap();
        int rid_;
        int degree;
    protected:
        PktListBoot * UdpList;
	UdpAgent *rudp_[MAX_NODES+1];
	UdpAgent *sudp_;
	int * nodeidpool;
	int * lastsendparent;
	int Num_Senders,TargetPkt,DEBUG_Excesspkt,DEBUG_Excessevent,MaxPktLoss;
	int firstqa,firstfill,playindex,SendRand,firstrequest,firstcal,firstbw,startpoint;
	int starttimestamp,endtimestamp,Quality,PlayQuality,srcwin,opt;
	int *  firstduealoc;
	float * AssBWRatio;
	float  qual,startplay,fastmode;
	float lastSend,dumptime,bwflag;
	nodelist *nodepool;
	int tablemirror[MAX_LAYER][MAX_BUFFER];
	int * tabqualmirror;
	int * DEBUG_availwin;
	int ** DEBUG_avail; 
	int * DEBUG_availwin2;
        int ** DEBUG_avail2; 
	int bufquality[MAX_BUFFER],DEBUG_neg2pkt,asyn;
	int srcflag; 
	int firstboot,udpindex2,targetneigh,MaxTab,OldMaxTab,DEBUG_upper,DEBUG_down,DEBUG_totalpkt;
	float lasttry,Ref_TH;
	int bufplayindex,bufindex[MAX_LAYER],buftailtimestamp[MAX_LAYER],tailbuf[MAX_LAYER];
	float *srtt, *ewmausebw,*ewmabw, *sampleBW,*DEBUG_sampleContBTBW,*DEBUG_ewmaconbtbw,*DEBUG_ewmabw2,*DevUseBW,*DevBW;
	int *NumPktRcvd,*NumUseful,*DEBUG_NumPRIMEPktRcvd,*NumConBT;
	int *DueSize;
	PktList *DuePkt[n_max],*DueExtraPkt[n_max];
	int DEBUG_TotExt,DEBUG_TotExt2,DEBUG_NumAggPkt,DEBUG_NumAggPkt1,DEBUG_NumAggPkt2,DEBUG_NumAggPrime1,DEBUG_NumAggPrime2,DEBUG_NumAggPrime;
	float DEBUG_ewmahop,DEBUG_ewmatime,EWMAH,DEBUG_DevHop,DEBUG_Devtime,DEBUG_TotAvail,DEBUG_TotAvailExt;
	int *DueNumPkt,*diffind,*assignindex,*RemNumPkt,*index;
	int *DueNumPktCons,*DueNumExtraPkt,DEBUG_Extrasw2,DEBUG_Extrasw3,DEBUG_Extradif2,DEBUG_Extradif3,DEBUG_AGGdiff,DEBUG_AGGsw;
	float *sending_time,DEBUG_avggapavailtmax,DEBUG_avggaptmax,DEBUG_avggaplastthis,DEBUG_avggapstretch,DEBUG_avggapmaxlast,DEBUG_avgdelta;
	int WindowStart, WindowSize,WindowPkt,DEBUG_avgcount,dumpflag,DEBUG_tottimestamp;	// in packet
	float WindowWidth,DEBUG_normpa,DEBUG_normbuf,DEBUG_normplay,DEBUG_normqual,DEBUG_normnew,DEBUG_normnewbw,DEBUG_normbufbw;
	int playtime2, DEBUG_Late[MAX_LAYER],DEBUG_NumPktReq[MAX_LAYER],DEBUG_NumDup[MAX_LAYER],DEBUG_laterequests;
	void DumpData();
	void DumpSimData();
	void PktDiff();
	void Checkbufdif();
	int seed;
	float LastBWCalcTime;
	void Startup();
	RPALMessage *message_;
        int SRC_D;	
	RPRIMEMSGBoot *tobootmessage_;
	RPRIMESigMSG *frombootmessage_; //udp message to recievers from boot
	RPRIMESigMSG  *signalingmessage_; //udp message to recievers from other recievers
	RPRIMESigMSG  *signalingmessage2;
	PendRequest pendingtimer_;
	DrainTimer draintimer_;
	EWMABWTimer ewmabwtimer_;
	float maxsrtt();
	int ActiveLayers;
	float totbw();
	float totbw2();
	float minbw();
	float C;
	void SendRequestToAll();
	void SlideWindow();
	void RFC(int);
	int CheckBufferState();
	void QA();
	float DEBUG_AvgQuality, DEBUG_AvgQuality2,DEBUG_AvgQuality3;
	int DEBUG_NumOfChangeSum;
	int *DEBUG_ExtraPkt, *DEBUG_ExtraPkt2,*Sender_TotPkt;
	int Extra,DEBUG_ExtraPkt3,*DEBUG_ContDif,*DEBUG_ContSW;
	float WIN_SIZE,MWM; 
	int IsOverlap, EnableQACheck;
	float EWMABW_WT,LookAhead;
	int MAX_PACKETS, DEBUG_TotalPktRequested;
	int DEBUG_DropCount;
	int *LossCount, *LossCount2, *EndSeqNo, *BeginSeqNo, *StSeqNo,*TotalLoss;
	int *seqnum,*Ack,*repnum,DEBUG_LossC2,DEBUG_Nloss;
	float DEBUG_Inefficiency, DEBUG_LayerDiff, DEBUG_Unrequested, PktSlope, *LossRate;
	void OrderListWithBufferSlope();
	void PA(int[MAX_BUFFER]);
	void SendRequest(int, PktList*, int,int);
	int WarmUp;
	void CalAvgBuf();
	float DEBUG_avghopcount,DEBUG_avgelaps;
	int DEBUG_hopdist[n_max+1][MAX_NODES+1];
	int *extralength,*reglength;
	float RefTime;
	int pendindex,firstpend;
        int LastWindowStartPosition,firstslide,firststart;  
        void bootStartup();
        int nodeindex,udpindex;
        void SendToBootstrap();
        void checkttl();
        void assignparent(int,int);
        void checkneigh(PktListBoot * ,int);
        void EstablishUdp();
        void sendudpRequest(int,int,PktList*,int);
        void SendTobootstrap(int,int);                
        void process_sigmsg(AppData* );
        void removefromlist(int);
        int findrap(int);
        ConTab * table[MAX_LAYER];
        int * table2[MAX_LAYER];
        int * tabqual;
        int bufferlength;
        void checkrapconnection();
        void extractcontent(int,PktList*,int,int,int,int,int,int,int);
        int assignglobrare(int);
        void sortrare(int,int,int,int[MAX_BUFFER],int);
        int assign(int,int);
        int SenderAssign(int,int,int);
        int *Fullsender,DEBUG_totrcvd, maxts;
        int ActualPkt,lasttmax;
        int DEBUG_reportloss,DEBUG_recloss,coop;
        int *DEBUG_reporloss;
        float lasttimeboot; 
        int scan,ALL,Rand,DIFF,population;
        float firstst,startuptime,DEBUG_avgpar,DEBUG_avgpar2,DEBUG_avgch,DEBUG_prevavg,DEBUG_prevavg2,DEBUG_avgdist,DEBUG_prevavgdist;
        int randomstart,prestop;
        float DEBUG_lastpar,DEBUG_lastdist,DEBUG_lastparavg,DEBUG_lastdistavg;
        int DEBUG_parch,DEBUG_distch;
        void start_all();
        void init();
        void zero_all();
    };

#ifndef ns_rpalglob_h
#define ns_rpalglob_h
#endif
#endif
