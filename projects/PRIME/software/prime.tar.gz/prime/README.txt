In this directory:

   Source code:
          PRIMECommon.h  Common variables and constants
	
       Receiver side of a peer:
	  RPRIME.h	 Variables and constants used in receiver (RPRIME.cc)
	  RPRIME.cc	 Code for receiver side of a peer
	  RPRIME.o	 Binary for the receiver

       Sender side of a peer and source functionality: 
	  SPRIME.h	Variables and constants used in sender (SPRIME.cc)
	  SPRIME.cc	Code for the sender side of a peer
    	  SPRIME.o 	Binary for the sender
	