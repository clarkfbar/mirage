// Copyright (c) 2008 by the University of Oregon
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Oregon, Computer and Information
// Sciences Department, Mirage Lab.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF Oregon makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// RPRIME.cc 
//      Code for the 'Receiver Agent' 
//
// Author: 
//   Nazanin Magharei (nazanin@cs.uoregon.edu)
//

#include "RPRIME.h"
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
extern SPALApp * spal[MAX_NODES+2];
extern RPALApp * rprime[MAX_NODES+2];
extern UdpAgent * udname[MAX_NODES+2];
extern RapAgent * rname[(MAX_NODES+2)*2*n_max];
extern UdpAgent * srudp[MAX_NODES+2];

static class RPALClass : public TclClass
{
    public:
        RPALClass() : TclClass("Application/RPAL") {}

        TclObject* create(int, const char*const*)
        {
        	return new RPALApp();
        }
} class_rpal;


void DrainTimer::expire(Event *)
{
	a_->Drain();
}

void StartTimer::expire(Event *)
{
        a_->start();
}

void StopTimer::expire(Event *)
{
        a_->stop();
}
                
void EWMABWTimer::expire(Event *)
{
	a_->CalculateEWMABW();
}

void PendRequest::expire(Event *)
{
        a_->PendingReq();
}
        
void RPRIMESigMSG::freepoint(AppData* data)
{ 
 if(data->type()==RPRIME_Sig)
 {
   RPRIMESigMSG * msg  = (RPRIMESigMSG*) data;
  if(msg->list_!=NULL) {free(msg->list_);}
  if(msg->request_list_!=NULL) {free(msg->request_list_);}
  if(msg->sprime_id_!=0 && msg->curbitmap!=NULL && msg->length>0) { 
			    PktList * bitmap=msg->curbitmap;	
			    assert(msg->length>0);
			    free(bitmap);}
 }
}

RPALApp::RPALApp() : n_maxp(10),n_minp(5),distance(0),difindex(0),stdifindex(0),stopped_(1),
        tr_down(0),tr_start(0),distance_t(0),playtime(0),startup(1),Grayindex(0),starttimer_(this),stoptimer_(this),rid_(0),degree(400000),Num_Senders(0),
        TargetPkt(0),DEBUG_Excesspkt(0),DEBUG_Excessevent(0),MaxPktLoss(0),firstqa(0),firstfill(1),firstrequest(1),firstcal(1),firstbw(1),startpoint(-1),
        starttimestamp(0),endtimestamp(0),Quality(1),PlayQuality(1),srcwin(20),qual(0), startplay(-2),fastmode(-1),lastSend(-1),dumptime(200),
        DEBUG_neg2pkt(0),asyn(2),srcflag(-1),firstboot(0),udpindex2(0),targetneigh(0),MaxTab(0),OldMaxTab(0),DEBUG_upper(0),DEBUG_down(0),
        DEBUG_totalpkt(0),lasttry(0), Ref_TH(1),bufplayindex(0),DEBUG_TotExt(0),DEBUG_TotExt2(0),DEBUG_NumAggPkt(0),DEBUG_NumAggPkt1(0),DEBUG_NumAggPkt2(0),
        DEBUG_NumAggPrime1(0),DEBUG_NumAggPrime2(0),DEBUG_NumAggPrime(0),DEBUG_ewmahop(0),DEBUG_ewmatime(0),EWMAH(0.01),DEBUG_DevHop(0),DEBUG_Devtime(0),DEBUG_TotAvail(0),
        DEBUG_TotAvailExt(0),DEBUG_Extrasw2(0),DEBUG_Extrasw3(0),DEBUG_Extradif2(0),DEBUG_Extradif3(0),DEBUG_AGGdiff(0),DEBUG_AGGsw(0), DEBUG_avggapavailtmax(0),DEBUG_avggaptmax(0), 
        DEBUG_avggaplastthis(0),DEBUG_avggapstretch(0),DEBUG_avggapmaxlast(0), DEBUG_avgdelta(0), WindowStart(0), WindowSize(0),WindowPkt(0),
        DEBUG_avgcount(0),dumpflag(1),DEBUG_tottimestamp(0),WindowWidth(0),DEBUG_normpa(0),DEBUG_normbuf(0),DEBUG_normplay(0),DEBUG_normqual(0),DEBUG_normnew(0),
        DEBUG_normnewbw(0),DEBUG_normbufbw(0), playtime2(-2000), DEBUG_laterequests(0),seed(0),SRC_D(n_max),pendingtimer_(this),draintimer_(this), 
        ewmabwtimer_(this),DEBUG_AvgQuality(0),DEBUG_AvgQuality2(0), DEBUG_AvgQuality3(0), DEBUG_NumOfChangeSum(1), DEBUG_ExtraPkt3(0),WIN_SIZE(5),
        MWM(0.4),IsOverlap(1),EnableQACheck(1), EWMABW_WT(0.01), LookAhead(2.0), DEBUG_DropCount(0),DEBUG_LossC2(0),DEBUG_Nloss(0), DEBUG_Inefficiency(0), 
        DEBUG_LayerDiff(0), DEBUG_Unrequested(0),PktSlope(1), WarmUp(1), DEBUG_avghopcount(0),DEBUG_avgelaps(0), RefTime(0), pendindex(0), 
        LastWindowStartPosition(0), firstslide(0), firststart(1),udpindex(0),bufferlength(0),DEBUG_totrcvd(0),maxts(0),lasttmax(-1),DEBUG_reportloss(0),
        DEBUG_recloss(0),coop(1),lasttimeboot(0),firstst(1),startuptime(0),DEBUG_avgpar(0),DEBUG_avgpar2(0),DEBUG_avgch(0),
        DEBUG_prevavg(0),DEBUG_prevavg2(0),randomstart(1),prestop(0), DEBUG_lastpar(0),DEBUG_lastdist(0),DEBUG_lastparavg(0),DEBUG_lastdistavg(0),DEBUG_parch(0),DEBUG_distch(0)
{
	int i,j;

	bind("rid_", &rid_);
	bind("degree",&degree);
	
	FILE * fp=fopen ("rin.in","r");
	if(fp!=0) {fscanf(fp,"%f %d %d %d %d ",&WIN_SIZE,&srcwin,&n_maxp,&SRC_D,&seed);	
		n_minp=n_maxp; fclose(fp);}
	printf("winsize %f srcwin %d %d %d %f seed %d SRC_D %d\n",WIN_SIZE,srcwin,n_maxp,n_minp,dumptime,seed,SRC_D);
	firstpend=-1;  	      
	LookAhead = WIN_SIZE + MWM;
	DEBUG_TotalPktRequested = 0;
	bzero(DEBUG_hopdist,sizeof(DEBUG_hopdist));
	MAX_PACKETS = (int)(PKT_PER_SEC * MAX_SIM_TIME * 2);
	Tcl& tcl2 = Tcl::instance();
	if(rname[0] ==NULL)
	{
	for (i=0;i<MAX_NODES+1;i++)
         { tcl2.evalf("set spal(%d) [new Application/SPAL]",i);
           spal[i]=(SPALApp *) tcl2.lookup(tcl2.result());
	 }

	for (i=0; i<((MAX_NODES+1) * 2*n_max) ; i++)
         { tcl2.evalf("set nrap(%d) [new Agent/RAP]",i);
	   rname[i]=(RapAgent *) tcl2.lookup(tcl2.result());
	   tcl2.evalf("$nrap(%d) set ipg_ .20",i);
           tcl2.evalf("$nrap(%d) set srtt_ .20",i);
	   tcl2.evalf("$nrap(%d) set delta_ 0.2",i);
	}
	 printf("rap agents were built %d\n",i);

	 for(i= 0; i<MAX_NODES+1; i++) 
    	  for(j=2*n_max*i;j<2*n_max*(i+1);j++)
     	    tcl2.evalf("$ns attach-agent $peer(\%d) $nrap(\%d)",i,j);
		 
	printf("rap agents were built %d\n",j);
           
	 for (i=1; i<MAX_NODES+1; i++)
	  {tcl2.evalf("set udp(%d) [new Agent/UDP]",i);
           udname[i]=(UdpAgent *) tcl2.lookup(tcl2.result());
	   tcl2.evalf("$ns attach-agent $peer(\%d) $udp(\%d)",i,i);
          }
	
	 for(i=0;i<MAX_NODES+1; i++)
          {tcl2.evalf("set sudp(%d) [new Agent/UDP]",i);
           srudp[i]=(UdpAgent *) tcl2.lookup(tcl2.result());
	   tcl2.evalf("$ns attach-agent $peer(\%d) $sudp(\%d)",i,i);
           srudp[i]->attachApp(spal[i]);
          }

	for(i=0;i<MAX_NODES+1; i++)
	 for (j=0; j<n_max; j++)
          {assert((i*2*n_max+j)<(MAX_NODES+2)*2*n_max);
	   rname[i*2*n_max+j]->attachApp(spal[i]);
   	  }
	 }

	int W=(int)((srcwin*2)/WIN_SIZE);
	
    	DEBUG_avail=(int**) malloc((W+2)*sizeof(int*));
	DEBUG_avail2=(int**) malloc((W+2)*sizeof(int*));
	for(i=0;i<(W+2);i++)
	 {DEBUG_avail[i]=(int*)malloc((n_maxp+2) *sizeof(int));
	  DEBUG_avail2[i]=(int*)malloc((n_maxp+2) *sizeof(int));
	 } 
	DEBUG_avail[0][0]=0;
	DEBUG_availwin=(int*)malloc((W+2)*sizeof(int));
	DEBUG_availwin2=(int*)malloc((W+2)*sizeof(int));
	nodepool = (nodelist *) malloc((MAX_NODES+1) * sizeof(nodelist));
	nodeidpool = (int *) malloc((1+MAX_NODES) * sizeof(int));
	bzero(nodeidpool,(MAX_NODES+1) * sizeof(int));
	bzero(DEBUG_NumDup,sizeof(DEBUG_NumDup));
	bzero(DEBUG_NumPktReq,sizeof(DEBUG_NumPktReq));
	bzero(bufindex,sizeof(bufindex));
	bzero(difbuf,sizeof(difbuf));
	bzero(buftailtimestamp,sizeof(buftailtimestamp));
	bzero(tailbuf,sizeof(tailbuf));
	activeindex=0;
        for (i = 0; i <= MAX_LAYER; i++)
		{buf[i] = (buffer*) calloc(MAX_BUFFER, sizeof(buffer));	
		} 
        for (i = 0; i < MAX_LAYER; i++)
               { table[i] = (ConTab*) calloc(MAX_BUFFER, sizeof(ConTab));
                 table2[i]= (int*) calloc(MAX_BUFFER, sizeof(int));    
               }  
	bzero(bufquality,sizeof(bufquality));
        for (i = 0; i <= MAX_LAYER; i++)
          {bzero(buf[i], sizeof(buffer)*MAX_BUFFER); 
           for(j=0;j<MAX_BUFFER;j++)
	   {buf[i][j].flag=0;
	    buf[i][j].hopcount=0;
	    buf[i][j].time=0;
	   }
	  }
	 for (i = 0; i < MAX_LAYER; i++)
	  {bzero(table[i], sizeof(ConTab)*MAX_BUFFER);
	   bzero(table2[i], sizeof(int)*MAX_BUFFER);
	   for(j=0;j<MAX_BUFFER;j++)
	    {table[i][j].flag=0;
	     table2[i][j]=0;
	    } 
          }
                  
        bzero(tablemirror,MAX_BUFFER*MAX_LAYER*sizeof(int));	                                                                   
        tabqual=(int*) malloc(MAX_BUFFER*sizeof(int));
        tabqualmirror=(int*) malloc(MAX_BUFFER*sizeof(int));
        bzero(tabqualmirror,sizeof(int)*MAX_BUFFER);
        bzero(tabqual,sizeof(int)*MAX_BUFFER);
	bzero(DEBUG_Late, sizeof(DEBUG_Late));
	bzero(BufEndIndex, sizeof(BufEndIndex));
	C = PKT_SIZE * PKT_PER_SEC;
}

//This function is called every packet per sec for computing of available quality for each timestamp
//It also computes number of losses (gaps), extra packets (more than quality descriptions), hop count of each delivered packets and so on. 
//These variables will be averaged at the end of the simulation
void RPALApp::DumpData()
{
	static FILE *log16 = fopen("RPRIMElog.out", "a+");
	if(stopped_) {
			return;
	}
	int i, playoutlayer = 0;
	int  maxlayer = 0;
	int hop;
	for (i = 0; i < MAX_LAYER; i++)
	{	if (buf[i][bufplayindex].flag > 0) 
		{	if(startup==0 && TIME>(startuptime+20)) {DEBUG_avghopcount+=buf[i][bufplayindex].hopcount;
		                                       DEBUG_avgelaps+=buf[i][bufplayindex].time;
		                                      }  
			hop=buf[i][bufplayindex].hopcount;
			if(startup==0 && TIME>(startuptime+20)) DEBUG_totrcvd++;
			if(DEBUG_ewmahop==0)
	                { DEBUG_ewmahop=hop; DEBUG_DevHop=0;}
        	          else {DEBUG_ewmahop=hop*EWMAH+(1-EWMAH)*DEBUG_ewmahop;
                	      DEBUG_DevHop= EWMAH * DEBUG_DevHop + (1-EWMAH) * fabs (hop- DEBUG_ewmahop);
                     	}
                     	if(DEBUG_ewmatime==0)
	                { DEBUG_ewmatime=buf[i][bufplayindex].time; DEBUG_Devtime=0;}
                        else {DEBUG_ewmatime=buf[i][bufplayindex].time*EWMAH+(1-EWMAH)*DEBUG_ewmatime;
                	      DEBUG_Devtime= EWMAH * DEBUG_Devtime + (1-EWMAH) * fabs (buf[i][bufplayindex].time- DEBUG_ewmatime);
                     	}
	
			maxlayer++;
		}
		if(startup==0 && TIME>(startuptime+20))
		{if(buf[i][bufplayindex].flag > 1)
		  DEBUG_NumDup[i] += (buf[i][bufplayindex].flag -1);
		 if (buf[i][bufplayindex].flag !=0)
		   DEBUG_NumPktReq[i]++;
		
		
		 if( buf[i][bufplayindex].flag<0  ) TotalLoss[i]++;
		 if( buf[i][bufplayindex].flag==0  ) DEBUG_Unrequested++;
	 	}
	}
		if(startup==0 && TIME>(startuptime+20))
		{if(buf[MAX_LAYER][bufplayindex].flag>=maxlayer)
		  DEBUG_LayerDiff = DEBUG_LayerDiff+buf[MAX_LAYER][bufplayindex].flag-maxlayer;
     		 DEBUG_tottimestamp++;
		}
	if(maxlayer!=bufquality[bufplayindex]) printf("error max %d quali %d %d in %d\n",maxlayer,bufquality[bufplayindex],bufplayindex,rid_);
	assert(maxlayer==bufquality[bufplayindex]);
	if(startup==0 && TIME>(startuptime+20))
	{
	 if (bufquality[bufplayindex] > buf[MAX_LAYER][bufplayindex].flag) 
             {DEBUG_Excesspkt+= bufquality[bufplayindex]-buf[MAX_LAYER][bufplayindex].flag;
	      DEBUG_Excessevent++;
	     }
	 DEBUG_AvgQuality+=maxlayer;
	 DEBUG_AvgQuality3+=buf[MAX_LAYER][bufplayindex].flag;
	 if(maxlayer>buf[MAX_LAYER][bufplayindex].flag)
		DEBUG_AvgQuality2+=buf[MAX_LAYER][bufplayindex].flag;
	 else DEBUG_AvgQuality2+=maxlayer;
	}
	playoutlayer=maxlayer;
	return;
}

/*This function is responsible for sending/resending pending requests. 
If we send all the requests (udp messages) to all of the requesters(!) simultaneously, we observe a high loss rate. So we spread them over a short time scale.
A timer is started (for a random duration) each time there are requests (or udp messages) not yet sent.
1. This function keeps track of sending heartbeat messages to bootstrap or periodically requesting additional parents if needed.
2. It tries to establish udp connections to potentional parents over time
3. In startup phase, this function is responsible for triggering of scheduling event by calling SendRequestToAll function
4. It sends udp requests to one parent at a time if the previous request is lost or not have been sent yet
5. This function is also called by bootstrap. bootstrap has rid_=0 and keeps track of assigning parents to peers that are asked for. This assigning is spreaded over a short time scale.
If we send all the udp messages  to all of the requesters(!) simultaneously, we observe a high loss rate. So we spread them over a short time scale. 
A timer is started (for a random duration<20msec) each time there are udp messages not yet sent.
*/ 
void RPALApp::PendingReq()
{	if(stopped_) return;
	float randd=drand48()/50;
	int i=0,num=0;
        if(rid_==0)
        {if(pendindex!=nodeindex)
         { for(i=pendindex;i<nodeindex;i++)
           {pendindex++;
            if(lastsendparent[i]!=-1)
            { assignparent(nodeidpool[i],rprime[nodeidpool[i]]->n_maxp);
              break;
            }
           }
         }
         if(pendindex<nodeindex) pendingtimer_.resched(randd/2);
         return;
        }
         
	if(startup || Grayindex<n_minp)
	{ if(rid_!=0)
         { if( ((TIME-lasttimeboot) >  Heartbeat) || (TIME-lasttry)>TryEstab)
           {     if(Grayindex<n_minp && udpindex2==udpindex) SendTobootstrap(0,n_maxp);
                 else if( (TIME-lasttimeboot) > Heartbeat) SendTobootstrap(1,0);
           }
          if(lasttry !=0 && (TIME-lasttry) >  TryEstab)
                if(Grayindex<n_minp && udpindex2!=udpindex) EstablishUdp();
         }
        }
        if(startup) 
	{  if( (TIME-lastSend)>2 && (lastSend!=-1) )
		SendRequestToAll();
	 
	}
	if(rid_!=0)
        { if( ( (TIME-RefTime) > Ref_TH ) || (firstpend==-1) )
          {
          for(i=0;i<Grayindex;i++)
          {if ( (GrayList[i].bufsize==0) || (sending_time[i]==0 && DueNumPkt[i]==0))
           {sendudpRequest(0,GrayList[i].nodid,0,0);
            num++;
            pendindex=i+1;
            RefTime=TIME; 
            firstpend=0; 
            if(num>=1) break;
           }
          }                                                                                               
         }
         else
          {for(i=pendindex;i<Grayindex;i++)
           {
            if(GrayList[i].bufsize==0 || (sending_time[i]==0 && DueNumPkt[i]==0))
            {firstpend=1;
             pendindex++;
             sendudpRequest(0,GrayList[i].nodid,0,0);
             break;
           }
          }
         }                                                                                                      
	                             
	 int count=0;
	 randd=drand48();
	 while(randd==0 && count<=2) { count++; randd=drand48();}
	 int flag=0;
	 for (i=0; i< Grayindex;i++) {
		if( (DueNumPkt[i]!=0) && (sending_time[i]==0)) 
			{if(WindowPkt <(WindowWidth * PKT_PER_SEC/2)) {printf("error error late request %d %d\n",rid_,GrayList[i].nodid);
			                                               DEBUG_laterequests++;
			                                              }    
			 SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],1);
	                 pendingtimer_.resched(randd/(20.000));
			 flag=1;
			 break;
			}
                else if ( (DueNumPkt[i]!=0) && (Ack[i] != 1) && (sending_time[i]!=0) && ((TIME-sending_time[i])>(srtt[i]*2)) )
                {       
			seqnum[i]++;
                        SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],1);
			if(flag==0) pendingtimer_.resched(randd/10.000);
			flag=1;
                        break;
                }
         }
	  if(flag==0 || startup)  pendingtimer_.resched(randd/50.0); 	
	}
}

/*
This function is mainly responsible for simulating the actual playing of packets. It is timer driven and is called very PKT_PER_SEC seconds to play each timestamp. Empty the buffer at the playtime
and calling the Sliding window function if needed every delta seconds.
Additional tasks are:
1.Due to timers being expensive, this same function also check the requirement for sending a hearbeat or a parent request message from bootstrap for every Heartbeat (20sec) seconds.
2.It also keeps track of the first time for triggering the scheduling event during startup phase, which depends on buffer status of parents.
3.In startup phase, this function keeps track of terminating of startup phase or changing to fast mode phase.
*/
void RPALApp::Drain()
{ if(stopped_) {printf("was stopped %d \n",rid_); return;}	
  if(tr_down!=0 && tr_down<=TIME) {printf("%f: peer id %d is stopped by trace at %f\n",TIME, rid_,tr_down); stop();}
       if(rid_==0) {
                      return;
                   }                     
         draintimer_.resched(1.0 / PKT_PER_SEC);                                                      
	int num=0,i=0; 
       if(rid_!=0 && !startup ) 
	{ if((TIME-lasttimeboot) >  Heartbeat) 
	  {	if(Grayindex<n_minp && udpindex2==udpindex) SendTobootstrap(0,n_maxp); 
		else SendTobootstrap(1,0);
	  }
	}

	num=0;
	for(i=0;i<Grayindex;i++)
         {  if(GrayList[i].bufsize==0) continue;
              else num++;
	 }
	 
	if(num>0 && firstfill && startup ) 
	{if((TIME-lastSend)>1 || (lastSend==-1))
	 {firstfill=0;
	  Num_Senders=num;
	  printf("%f first fill table in %d with %d %d \n",TIME,rid_,num,Grayindex);
	  SendRequestToAll();
	 } 
	}	 

	Num_Senders=Grayindex;
	if(startup)
	{	if(startplay !=0 && startplay!=-1 && startplay !=-2 && startplay-TIME<=0) {startplay=0;
				    fastmode=TIME+ 6;
				  printf("in fastmode %d %f %f %f\n",rid_,fastmode,TIME,startplay);}
    
		if(startplay==0 || startplay==-1) 
			if(fastmode-TIME<=0)  {fastmode=0;
								
						printf("warning startup condition is not met but fast mode expires %f %d %d %d\n",TIME,rid_,startpoint,playtime);
						Startup();
					      }
	}
	if(startup ) {if(playtime2!=-2000)
			playtime2++;
			return;
		     }
	else playtime2=-2000;
	bufplayindex=playtime % MAX_BUFFER;
	DumpData();
	int temp=playtime % MAX_BUFFER;
	bufferlength=bufferlength-bufquality[temp];
	bufquality[temp]=0;
	for(i=0;i<=MAX_LAYER;i++)
	{	buf[i][temp].flag=0;
		buf[i][temp].hopcount=0;
		buf[i][temp].time=0;
		assert(bufferlength>=0);
		if(i != MAX_LAYER)
		  if( BufEndIndex[i]<playtime)
		  {	
			BufEndIndex[i]=playtime;
			bufindex[i]=playtime % MAX_BUFFER;
		  }
	}


	playtime++;
	int k;
	tabqual[temp]=0;
	bufplayindex=playtime % MAX_BUFFER;
	for(i=0;i<MAX_LAYER;i++)
	{ assert(playtime+MAX_BUFFER > buftailtimestamp[i]);	
	  table[i][temp].flag=0;
	  table2[i][temp]=0;
	  for(k=0;k<n_max;k++)
	  { table[i][temp].Listid[k]=0;
	    table[i][temp].Listind[k]=0;
	  }
	    
	  if( BufEndIndex[i]<playtime)
                  {	if(buf[i][bufplayindex].flag>0) 
                          {printf("error in buffer %d \n",buf[i][bufplayindex].flag); buf[i][bufplayindex].flag=0;}
                        BufEndIndex[i]=playtime;
                        bufindex[i]=playtime % MAX_BUFFER;
                  }
	}
	WindowPkt--;
	if (WindowPkt == 0)
	{
		printf("%f : playtime very close to window, sliding window\n", TIME);
		
		SlideWindow();
	}
}

/* This function is responsible for calculating ewma of bandwidth periodically (every max rtt seconds or 200 msec).
*/
void RPALApp::CalculateEWMABW()
{	if (stopped_) return;
	int i;

	float curtime, interval[n_maxp];
	curtime = TIME;
	
	float sampleBW2[n_maxp];
	bzero(sampleBW2,sizeof(sampleBW2));
	float EWMABW_WT2=0.01;
	for (i = 0; i < Grayindex; i++)
	{	interval[i]= curtime - (LastBWCalc[i]>0 ? LastBWCalc[i] : LastBWCalcTime);
	        assert(interval[i]> 0 || NumPktRcvd[i] ==0);
	        if(interval[i]>0)
	        {sampleBW[i] = NumPktRcvd[i] * PKT_SIZE / interval[i];
          	 sampleBW2[i]= NumUseful[i]*PKT_SIZE/interval[i];
          	} 
          	else {sampleBW[i]=0; sampleBW2[i]=0;}
          	if(LastBWCalc[i]>0) LastBWCalc[i]=TIME;
          	
          	if(ewmausebw[i]==0)
		{ewmausebw[i]= sampleBW2[i];
		 DevUseBW[i]=0;
		} 
        	else {ewmausebw[i] = (1 - EWMABW_WT2) * ewmausebw[i] + EWMABW_WT2 * sampleBW2[i];
	         DevUseBW[i]= 0.9 * DevUseBW[i] + 0.1 * fabs (sampleBW2[i]- ewmausebw[i]);
	        } 
        	 if(firstbw || DEBUG_ewmabw2[i]==0)
        	 {  DEBUG_ewmabw2[i] = sampleBW[i];
        	    DevBW[i]=0;		
        	 }
        	 else { DEBUG_ewmabw2[i]=0.99 * DEBUG_ewmabw2[i] + 0.01 * sampleBW[i];
                      DevBW[i] = 0.9 * DevBW[i] + 0.1 * fabs (sampleBW[i]- DEBUG_ewmabw2[i]);
                 }
                  
        	 if (firstbw || ewmabw[i]==0)
          	 {
          		ewmabw[i] = sampleBW[i];
        	 }
        	 else
        	 { 		
                  ewmabw[i] = 0.99 * ewmabw[i] + 0.01 * sampleBW[i];
                 }
	}
     
	if(!startup)
	 for(i=0;i<Grayindex;i++)
	{	if(interval[i]>0)
                   DEBUG_sampleContBTBW[i] =(float) (NumConBT[i] * PKT_SIZE) / interval[i];
                else DEBUG_sampleContBTBW[i]=0;   
		
		 if(DEBUG_ewmaconbtbw[i]==0)
			DEBUG_ewmaconbtbw[i]=DEBUG_sampleContBTBW[i];
		 else DEBUG_ewmaconbtbw[i]=(1 - EWMABW_WT) * DEBUG_ewmaconbtbw[i] + EWMABW_WT * DEBUG_sampleContBTBW[i];
	}

	firstbw=0;
        float next=maxsrtt();
        if(next==0) next=0.2;
        ewmabwtimer_.resched(next);
	bzero(NumPktRcvd, n_maxp*sizeof(int));
	bzero(NumUseful,n_maxp*sizeof(int));
	bzero(NumConBT,n_maxp*sizeof(int));
	LastBWCalcTime = curtime;
	WarmUp = 0;
	if (EnableQACheck && !startup)
	{	
		int SlideWindowNow = CheckBufferState();
		if (SlideWindowNow ) {
			printf("%f : layer dropped before end of window\n", TIME);
			SlideWindow();
		}
        }
}

/*
This function initializes the bootstrap. spal[0] is source that in implementation you can ignore it.
*/
void RPALApp::bootStartup()
{
	nodeindex=0;
	srand(seed*2);
	printf("%f boot started\n",TIME);
	nodeidpool[nodeindex]=0;
	nodepool[nodeindex].nodid=0;
	nodepool[nodeindex++].uptime=TIME;
	lastsendparent = (int*) malloc((MAX_NODES+1) * sizeof(int));
	bzero(lastsendparent,(MAX_NODES+1) * sizeof(int));
}

/*
This function is called only in startup phase and checks whether startup condition is met. 
1. If we are in fastmode (last delta seconds in startup phase) then should check where there is any gap in the first 2*delta packets from startpoint. If there 
is no gap we set startplay to -1 meaning that for the remaining time in startup phase we can ask for more than one description for each packet.

2. If startup phase is finished we clean our buffer from the range outside startpoint and the last informed packet. And call SlideWindow function for the first time.
*/
void RPALApp::Startup()
{
	if (!WarmUp)		
	{	
		int i, found=0;
			int starttimebuf=(startpoint>0 ? startpoint : 0) % MAX_BUFFER;
			int temp=(int) (2*WIN_SIZE*PKT_PER_SEC)+(startpoint>0 ? startpoint : 0);
			int endtimebuf=temp % MAX_BUFFER;

		if(!firststart && fastmode>0 && startplay!=-1)
			if(starttimebuf<=endtimebuf)
 			  for(i=starttimebuf;i<endtimebuf;i++)
			  { found=0; 
			    if(bufquality[i]>0) {found=1;}
 			     if(found!=1) { break;} 
			  }
			else
			 { for(i=starttimebuf;i<MAX_BUFFER;i++)
                           { found=0;
			    if(bufquality[i]>0) {found=1;}
                             if(found!=1) { break;} 
			   }
                         
			   if(found==1)
			    for(i=0;i<endtimebuf;i++)
                            { found=0;
				if(bufquality[i]>0) found=1;
                             if(found!=1) {break;} 
 	 				
			    }
                         }	
 		         
			 if(fastmode>0 && startplay!=-1)
				 if(found==1) startplay=-1; 
			 if(fastmode!=0) return;
                if (fastmode==0)
		{	
			for(i=0;i<Grayindex;i++)
				{seqnum[i]=0;
				 StSeqNo[i]=EndSeqNo[i];
				} 
			startup = 0;
			startuptime=TIME;
			DEBUG_prevavg=TIME;
			DEBUG_prevavgdist=TIME;
			DEBUG_avgpar=0;
			DEBUG_avgch=0;
			DEBUG_avgdist=0;
			printf("%f : end of startup phase fastmode: %f startplaying: %f\n", TIME,fastmode,startplay);
			Quality = 1;	
			int k,m,MAX=MaxTab;
                	int tempstarttime=startpoint%MAX_BUFFER;
                	int maxts=MaxTab%MAX_BUFFER;
                	if(OldMaxTab>MaxTab && (OldMaxTab-startpoint)<MAX_BUFFER)
                	 {maxts=OldMaxTab%MAX_BUFFER;
                	  MAX=OldMaxTab;
                	 } 
                	 if(MAX<startpoint)
                	 {
                	  for(k=0;k<MAX_LAYER;k++)
			  { if(startpoint<0) continue;
			    for(i=(startpoint);i>(startpoint-MAX_BUFFER);i--)
			     { if(i<0) break;
			       table[k][i%MAX_BUFFER].flag=0;
			       table2[k][i%MAX_BUFFER]=0;
			       buf[k][i%MAX_BUFFER].flag=0;
			       buf[k][i%MAX_BUFFER].hopcount=0;
			       buf[k][i%MAX_BUFFER].time=0;
			       bufquality[i%MAX_BUFFER]=0;
			       for(m=0;m<n_max;m++)
                               { table[k][i%MAX_BUFFER].Listid[m]=0;
                                table[k][i%MAX_BUFFER].Listind[m]=0;
                               }
                             }
                          }
                         }
                             
                	assert((MaxTab-startpoint)<MAX_BUFFER);
			for(k=0;k<MAX_LAYER;k++)
			 { if(startpoint<0) continue;
			   if(maxts>=tempstarttime)
			   {for(i=0;i<tempstarttime;i++)
			     { table[k][i%MAX_BUFFER].flag=0;
			       table2[k][i%MAX_BUFFER]=0;
			       buf[k][i%MAX_BUFFER].flag=0;
			       buf[k][i%MAX_BUFFER].hopcount=0;
			       buf[k][i%MAX_BUFFER].time=0;
			       bufquality[i%MAX_BUFFER]=0;
			       for(m=0;m<n_max;m++)
                               { table[k][i%MAX_BUFFER].Listid[m]=0;
                                table[k][i%MAX_BUFFER].Listind[m]=0;
                               }
                             }
                            for(i=(maxts+1);i<MAX_BUFFER;i++)
                            { table[k][i%MAX_BUFFER].flag=0;
                              table2[k][i%MAX_BUFFER]=0;
                              buf[k][i%MAX_BUFFER].flag=0;
                              buf[k][i%MAX_BUFFER].hopcount=0;
                              buf[k][i%MAX_BUFFER].time=0;
                              bufquality[i%MAX_BUFFER]=0; 
                              for(m=0;m<n_max;m++)
                              { table[k][i%MAX_BUFFER].Listid[m]=0;
                                table[k][i%MAX_BUFFER].Listind[m]=0;
                              }
                            }   
                           }
                           else
                           {for(i=(maxts+1);i<tempstarttime;i++)
                            {table[k][i%MAX_BUFFER].flag=0;
                             table2[k][i%MAX_BUFFER]=0;
                             buf[k][i%MAX_BUFFER].flag=0;
                             buf[k][i%MAX_BUFFER].hopcount=0;
                             buf[k][i%MAX_BUFFER].time=0;
                             bufquality[i%MAX_BUFFER]=0;
                             for(m=0;m<n_max;m++)
                             { table[k][i%MAX_BUFFER].Listid[m]=0;
                               table[k][i%MAX_BUFFER].Listind[m]=0;
                             }
                            }
                           }
                         }			                                                     
                         SlideWindow();
		}
	}
	if (firststart)
	{	
		firststart = 0;
		printf("start %d \n", rid_);

	        SendTobootstrap(0,n_maxp);
		PendingReq();
                Drain();
	}
}

/*
This function slides the window and call QA (quality adaptation function). 
It stores playing quality for the first window [playtime+MWM,playtime+delta+MWM],
sets various variables needed for schedulings, e.g. starttimestamp, WindowSize, WindowPkt and so on.

**In case of churn there might be a situation that the peer does not have any parent (Grayindex=0) in this case we dont call QA and reset WindowPkt for 1 second worth of packets to make sure
we wont fall behind. (WindowPkt is decremented every PKT_PER_SEC in Drain function and if it reaches zero, SlideWindow() is called).
*/
void RPALApp::SlideWindow()
{	
        int i,k,n,m;
        int flag=0;
        i=0;
        k=0;
        n=0;
        m=0;
        int extraindex=0;
        extraindex=0;
        flag=0;
	WindowStart = playtime +(int) (LookAhead * PKT_PER_SEC);
	WindowWidth = WIN_SIZE;
	WindowPkt = (int)(WindowWidth * PKT_PER_SEC);
	printf("winstart = %d, playtime = %d WindowPkt %d \n", WindowStart, playtime,WindowPkt);
	WindowSize=WindowStart+WindowPkt; 
	if(firstslide==0) LastWindowStartPosition=playtime+(int)(MWM*PKT_PER_SEC);
	int tempstart= WindowStart % MAX_BUFFER; 
	int templast = LastWindowStartPosition % MAX_BUFFER;
	assert(WindowStart < LastWindowStartPosition + MAX_BUFFER);
	if( templast<=tempstart)
		for (i = templast; i < tempstart; i++)
			buf[MAX_LAYER][i].flag = PlayQuality;
	else {	for(i=templast; i < MAX_BUFFER; i++)
                        buf[MAX_LAYER][i].flag = PlayQuality;
		for(i=0; i < tempstart; i++)
                        buf[MAX_LAYER][i].flag = PlayQuality;
	     }
	starttimestamp=LastWindowStartPosition;
	LastWindowStartPosition = WindowStart;
	firstslide=1;
	if(Grayindex>0)
        	QA();		
        else WindowPkt = (int)(1 * PKT_PER_SEC); 
              
}

/*
This function is called only during startup and computes the remaining packets that each parent are going to send.
If the remaining packets which is captured by DueNumPkt is fewer than a threshhold then the scheduling function of startup phase (SendRequestToAll) will be called.

*/
void RPALApp::RFC(int idind)
{
	int pkt, flag = 0;
	float RFC_THD = 0.3;
	if ( (TIME-sending_time[idind]>(float)2) && (sending_time[idind]!=0) )
		flag=1;
	pkt = (int)(ewmabw[idind] * srtt[idind] * RFC_THD / PKT_SIZE);
	if (flag == 1 && DueNumPkt[idind] <= pkt) 	
	{				
		if (startup)
                {
			SendRequestToAll();
		}
		else
		{
			SlideWindow();
		}
	}	
}

/*
This function assigns a packet (ts, layer) to a parent with particular specification, e.g. random or minimum assigned to total bandwidth ratio.
Once the parent which is not full (shown by Fullsender) is determined, SenderAssign function is called to assign the packet to that parent.
The function returns -1 if fails.
Returns 1 if successful.
*/

int RPALApp::assign(int ts, int layer)
{ 
  int flagg=0;
  int senflag=0;
  int Minsender=0, Minsenderid=0;
  int firsttime=1;
  int m;        
  int safe=(int)((float)PKT_PER_SEC*srtt[0]*2.0);
  if(table[layer][ts%MAX_BUFFER].flag>0)
   {
       
    assert((table[layer][ts%MAX_BUFFER].Listind[0]<Grayindex) && (table[layer][ts%MAX_BUFFER].Listind[0]>=0));
    if(table[layer][ts%MAX_BUFFER].flag==1 && !Fullsender[table[layer][ts%MAX_BUFFER].Listind[0]])
    {if (GrayList[table[layer][ts%MAX_BUFFER].Listind[0]].tplay<(ts+safe))
     {int tempsenn =table[layer][ts%MAX_BUFFER].Listind[0];
      if(table[layer][ts%MAX_BUFFER].Listid[0]!=GrayList[tempsenn].nodid) 
       {printf("inconsistent rid %d old %d %d\n",rid_,table[layer][ts%MAX_BUFFER].Listid[0],GrayList[0].nodid);
        return -1;
       } 
      senflag=SenderAssign(tempsenn,ts,layer); flagg=2;
      if(senflag==-1) return -1;
      else return 1;
     }
    } 
    if(table[layer][ts%MAX_BUFFER].flag==1 && Fullsender[table[layer][ts%MAX_BUFFER].Listind[0]])
     return -1;
     
    if(table[layer][ts%MAX_BUFFER].flag==1 && GrayList[table[layer][ts%MAX_BUFFER].Listind[0]].tplay>(ts+safe))
     return -1;
      
    for(m=0;m<table[layer][ts%MAX_BUFFER].flag;m++)
     {

           assert(table[layer][ts%MAX_BUFFER].Listind[m]<n_maxp);

           if(Fullsender[table[layer][ts%MAX_BUFFER].Listind[m]]) continue;
           if(GrayList[table[layer][ts%MAX_BUFFER].Listind[m]].tplay>(safe+ts)) continue;  
           if(table[layer][ts%MAX_BUFFER].Listid[m]!=GrayList[table[layer][ts%MAX_BUFFER].Listind[m]].nodid)
           {printf("inconsistent rid %d old %d %d m %d ts %d lay %d flag %d\n",rid_,table[layer][ts%MAX_BUFFER].Listid[m],GrayList[table[layer][ts%MAX_BUFFER].Listind[m]].nodid,m,ts,layer,table[layer][ts%MAX_BUFFER].flag);
            continue;
           } 
            flagg=1;
           assert(Fullsender[table[layer][ts%MAX_BUFFER].Listind[m]]!=1);
           if(firsttime )
           {Minsender=table[layer][ts%MAX_BUFFER].Listind[m];
            Minsenderid=table[layer][ts%MAX_BUFFER].Listid[m];
            if(Minsenderid==-1) return -1;
            firsttime=0;
           }                                                                                                                                                                                                                                                                                                                                                                     
           if(AssBWRatio[table[layer][ts%MAX_BUFFER].Listind[m]]<AssBWRatio[Minsender])
            {Minsender=table[layer][ts%MAX_BUFFER].Listind[m]; Minsenderid=table[layer][ts%MAX_BUFFER].Listid[m];
             if(Minsenderid==-1) return -1;
            } 
     }
   } 
   if(!flagg)      { 
                      return -1;
                   }
   senflag=SenderAssign(Minsender,ts,layer);
   if(senflag==-1) return -1;
   else return 1;
}                                                                           

/*
This function is responsible for identifying packets in each region to be requested. 
Its inputs are: startbuf-> timestamp of start of region to be requested,
endbuf-> timestamp of last packet in the region to be requested, 
tempQuality-> maximum quality in terms of the number of descriptions should be requested for this region
BufState[MAX_BUFFER]-> state of buffer at the peer (how many descriptions the peer has for each timestamp
scanflag is 1 only for playing window [playtime+MWM,playtime+MWM+delta], meaning that we dont need to shuffle packets!

The description of algorithm is similar to the description document of prime.
** one point is the different behavior towards source. If source is among parents as it does have all the packets, we give the lowest priority to it. Meaning that we 
first try to assign each packet to parents other than source and if failed and source is among parents assign it to source. 
srcflag shows whether source is among parents or not (-1 means it is not among parents)
** Note that, in array of "table" which stores available packets among parents, we dont store available packets at source if it is among parents, to reduce computation cost of the code.
*/

void RPALApp::sortrare(int startbuf,int endbuf,int tempQuality,int BufState[MAX_BUFFER],int scanflag)
{	int i=0,j=0;
        if(Grayindex==0) {printf("no parents in %d\n",rid_);
                          return;
                         } 
        int max_pkt=0;
        bzero(AssBWRatio,n_maxp*sizeof(float));
        
        int fflag=0;
        assert(startbuf<endbuf);
        if (startbuf<endbuf) max_pkt=endbuf-startbuf+2;
        else max_pkt=1;
	SentList rare[Grayindex][MAX_LAYER*max_pkt];
	bzero(rare,sizeof(SentList)*Grayindex*(MAX_LAYER*max_pkt));
	
	int indrare[Grayindex];
	bzero(indrare,sizeof(int)*Grayindex);
	int diff=0,aloc=0;
	int flag=0;
	int assignqual=tempQuality;
	int W=(int)((srcwin*2)/WIN_SIZE);

        for(j=startbuf;j<endbuf;j++)
	{int delta=(int)floor((float)(j-(playtime+(int)(MWM * PKT_PER_SEC)))/((float)(WIN_SIZE*PKT_PER_SEC)));
	 assert(delta<W+2 && delta>=0);
	 if(j<WindowSize) assignqual=Quality;
	 else assignqual=tempQuality;
	 diff = assignqual-BufState[j%MAX_BUFFER]; 
	 aloc=0;
	 
	 for(i=0;i<MAX_LAYER;i++)
	   { 
                flag=0;
                fflag=0;
                if(table[i][j%MAX_BUFFER].flag>0) 
                 {int tempind=table[i][j%MAX_BUFFER].flag+((srcflag!=-1) ? 1 : 0);
                  if(tempind>Grayindex) tempind=Grayindex;
                  assert(tempind<(Grayindex+1));
                  
                  DEBUG_avail[delta][tempind]++;
                  DEBUG_avail2[delta][tempind]++;
                  DEBUG_availwin[delta]++;
                  DEBUG_availwin2[delta]++;
                   
                  if(diff>0)
                  {
                   rare[tempind-1][indrare[tempind-1]].ts=j;
                   rare[tempind-1][indrare[tempind-1]++].lay=i;
                  } 
                 }   
                else if( srcflag!=-1 && buf[i][j%MAX_BUFFER].flag<=0) 
                 {assert(table[i][j%MAX_BUFFER].flag<=0); 
                  
                  
                    DEBUG_avail[delta][1]++;
                    DEBUG_avail2[delta][1]++;
                    DEBUG_availwin[delta]++;
                    DEBUG_availwin2[delta]++;
                    
                  if(diff>0)
                  {if(table[i][j%MAX_BUFFER].flag!=-3 )
                   {rare[0][indrare[0]].ts=j;
                    rare[0][indrare[0]++].lay=i;
                   }
                  }  
                 }  
                else if(buf[i][j%MAX_BUFFER].flag<=0) { DEBUG_avail[delta][0]++;} 
                else {
                      
                      DEBUG_avail[delta][Grayindex+1]++;
                      DEBUG_availwin[delta]++;

                      int count=0;
                      count=table2[i][j%MAX_BUFFER];
                       
                      assert(count>0 || srcflag!=-1);
                      if(srcflag!=-1) count++;
                      if(count>Grayindex) count=Grayindex;
                      assert(count<(Grayindex+1));
                      DEBUG_avail[delta][count]++;
                      
                     }
         }  
	} 
	assert(endbuf>startbuf);

       SentList tempshuf[1];
       for(j=0;j<Grayindex;j++)
       {
        if(scanflag==0) 
        {for(i=0;i<indrare[j];i++)
         {int shuf=rand() % indrare[j];
          tempshuf[0]=rare[j][shuf];
          rare[j][shuf]=rare[j][i];
          rare[j][i]=tempshuf[0];
         }
        }                                                
        
         for(i=0;i<indrare[j];i++)
         {if(ActualPkt<=0 || TargetPkt<=0)  return;
          if(rare[j][i].ts<WindowSize) assignqual=Quality;
          else assignqual=tempQuality;
          
          if(assignqual==BufState[rare[j][i].ts%MAX_BUFFER])
           continue;
          flag=assign(rare[j][i].ts,rare[j][i].lay);
          if(flag==-1 && srcflag!=-1)
          {if(RemNumPkt[srcflag]>0 && Fullsender[srcflag]==0)
           { int layer=rare[j][i].lay;
             int ts=rare[j][i].ts;
             assert((ts-playtime)<=MAX_BUFFER && ts>=playtime);
             assert(layer>=0 && layer<MAX_LAYER);
              if(tablemirror[layer][ts%MAX_BUFFER]!=-2 && table[layer][ts%MAX_BUFFER].flag!=-3 && ts>=GrayList[srcflag].tplay && buf[layer][ts%MAX_BUFFER].flag<=0)
               {SenderAssign(srcflag,ts,layer); flag=1;}
           }
    	  }
    	  if(flag==1) BufState[rare[j][i].ts%MAX_BUFFER]++;
    	 }
        }
}

/*
This function is only used during startup phase for scheduling. 
Its input (tabind) determines timestamp of the packet to be requested (%MAX_BUFFER).
It stores the list of parents that has this timestamp (tss) in senlist, and choose the one with minimum ratio of assigned to total bandwidth.
Further to select the description or layer, it chooses a random description among the available descriptions at this parent.
After determining the parent and description, we call SenderAssign function.
This function returns -1 if fails and 1 if it successfully assign the packet.
*/

int RPALApp::assignglobrare(int tabind)
{	
 
	int senlist[n_maxp][MAX_LAYER+1];
	int senindex[n_maxp];
	bzero(senindex,sizeof(senindex));
	bzero(senlist,sizeof(senlist));
	int i=0,m=0,k=0,flagg=0;
	int senflag=0;
        assert(tabqual[tabind]>0);
        if(tabqual[tabind]<=0) return -1; 
        int tss;
        int tempp=playtime % MAX_BUFFER;
        if(tabind<tempp) tss=playtime+(MAX_BUFFER-tempp)+tabind;
        else tss=tabind-tempp+playtime;       
        assert((tss-playtime)<=MAX_BUFFER && tss>=playtime);
        int Minsender, Minsenderid;
        int firsttime=1,Minlay=-1;
	for(i=0;i<MAX_LAYER;i++)
	{	
		if(table[i][tabind].flag>0 && tablemirror[i][tabind]!=-2) 
		{  
		   k=i;
		   assert((table[i][tabind].Listind[0]<Grayindex) && (table[i][tabind].Listind[0]>=0));
		   if(table[i][tabind].flag==1 && !Fullsender[table[i][tabind].Listind[0]]) 
			{int tempsenn =table[i][tabind].Listind[0];
			 senflag=SenderAssign(tempsenn,tss,i); flagg=2;
			 }
	             		 
		     if(flagg==2 && senflag!=-1) {
		                                return 1;
		                                }
                   
		   if(table[i][tabind].flag==1 && Fullsender[table[i][tabind].Listind[0]])
			continue;
		   for(m=0;m<table[i][tabind].flag;m++)	
		   {	
			assert(table[k][tabind].Listind[m]<n_maxp);
			 if( Fullsender[table[i][tabind].Listind[m]])
			   continue;
                         flagg=1;
			if(senlist[table[k][tabind].Listind[m]][MAX_LAYER]==0)  
                          {
			   senlist[table[k][tabind].Listind[m]][MAX_LAYER]=1; 
			  }
			 assert(Fullsender[table[i][tabind].Listind[m]]!=1);
			 senlist[table[k][tabind].Listind[m]][senindex[table[k][tabind].Listind[m]]++]=i;
			if(firsttime ) 
			{Minsender=table[k][tabind].Listind[m];
			 Minsenderid=table[k][tabind].Listid[m];
			 Minlay=k;
			 firsttime=0;
			}
			if(AssBWRatio[table[k][tabind].Listind[m]]<AssBWRatio[Minsender]) 
			  {Minsender=table[k][tabind].Listind[m]; Minsenderid=table[k][tabind].Listid[m];
			  }
		   }
		}
	}

	senflag=0;
	if(!flagg)	{
	                tabqualmirror[tabind]=-1;
	                return -1;
	                }
	assert(k<MAX_LAYER);
	int layrand;
	flagg=1;
	layrand=rand()%senindex[Minsender];
	layrand=senlist[Minsender][layrand];
	senflag=SenderAssign(Minsender,tss,layrand);	
	if(senflag==-1) return -1;
	else return 1;


}	

/*
This function adds the selected packet (timestamp,layer) to the parent's (senderind) list of requesting packets (DuePkt).
Its inputs are: senderind is the index of parent that this packet is going to be requested from
timestamp and layer are obvious!
*/

int RPALApp::SenderAssign(int senderind,int timestamp,int layer)
{	int tabindex=timestamp % MAX_BUFFER;
	static FILE * log1=fopen("RPRIMESendAss.out","a+");
	if (!log1 ) {
         log1 = fopen("RPRIMESendAss.out", "w+");
         if (!log1) {
            printf("can not open file for writing.\n");
         }
    	}
	if(ActualPkt>0 && TargetPkt>0)	
	{	if(RemNumPkt[senderind]>0)
		{ ActualPkt--;
		  if(!startup) TargetPkt--;
		  RemNumPkt[senderind]--;
		  if(RemNumPkt[senderind]==0) Fullsender[senderind]=1;
		  DuePkt[senderind][assignindex[senderind]].timestamp=timestamp;
		  DuePkt[senderind][assignindex[senderind]++].layer_id=layer;
		  AssBWRatio[senderind]+=((float)1/(float)DueNumPkt[senderind]);
		  tablemirror[layer][tabindex]=-2;
		  tabqualmirror[tabindex]--;
		  assert(buf[layer][tabindex].flag<=0);
		  assert(layer>=0);
		  buf[layer][tabindex].flag--;
		  if(buftailtimestamp[layer]<timestamp)
		  { buftailtimestamp[layer]=timestamp;
		    tailbuf[layer]=tabindex;
		  }
		  assert(buftailtimestamp[layer]<MAX_BUFFER + playtime);		  
		  return 1;
		}
		else 
		{
		  Fullsender[senderind]=1;
		  return -1;
		}
	}
 	else return 0;
   
}		  

/*
This function is periodically called by CalculateEWMABW() and checks the status of buffer. 
If the available bandwidth can not compensate for the playing quality based on the status of the buffer, this function returns 1. Upon returning 1, the window is slided and 
a layer will be dropped from quality.
*/
int RPALApp::CheckBufferState()
{
	int i=0, j=0, effbufpresent, totbufneeded, totbufpresent, temp;
	int lookaheadpkt = (int)(LookAhead * PKT_PER_SEC), TotPkt, LayerPkt;

	float TotBW = totbw();float TotBW2= totbw2();
	int TotPkt2=0;
	float TempWindowWidth ;
	TempWindowWidth= WindowPkt / PKT_PER_SEC;
	
	TotPkt = (int)(TotBW * TempWindowWidth / PKT_SIZE);		
	TotPkt2 = (int)(TotBW2 * TempWindowWidth / PKT_SIZE);
	LayerPkt = (int)(MWM * PKT_PER_SEC + TempWindowWidth * PKT_PER_SEC);
		      
	int lookaheadindex=lookaheadpkt % MAX_BUFFER;
	assert(playtime+MAX_BUFFER>lookaheadpkt);
	totbufpresent=effbufpresent=0;	
	totbufneeded = PlayQuality * LayerPkt - TotPkt;
	int max=0;
	for(i=0;i<MAX_LAYER;i++) if(max<BufEndIndex[i]) max=BufEndIndex[i];
	assert(max<MAX_BUFFER+playtime+lookaheadpkt);
	max=max % MAX_BUFFER;
	if(bufplayindex+lookaheadindex<=max)
	{for (j = bufplayindex + lookaheadindex; j <= max; j++)
	      {    temp = (Quality > bufquality[j]) ? bufquality[j] : Quality;
                   effbufpresent += temp;
		   totbufpresent += bufquality[j];
               }
	}        
        else 
        {      for(j=bufplayindex+lookaheadindex; j< MAX_BUFFER; j++)
                {temp = (Quality > bufquality[j]) ? bufquality[j] : Quality;
		 totbufpresent += bufquality[j];
                 effbufpresent += temp;
                 }
                for (j =0; j < max; j++)
                {        temp = (Quality > bufquality[j]) ? bufquality[j] : Quality;
                         effbufpresent += temp;
			 totbufpresent += bufquality[j];
		 }
	 }
	assert(effbufpresent <= totbufpresent);
	if (effbufpresent <= totbufneeded && PlayQuality > 1) {
		return 1;
	}
	else {  
		return 0;
	}
}

/* 
Upon sliding window in SlideWindow(), this function is called for quality adaptation and calling the packet scheduling functions (e.g. sortrare). 
1. This function computes the loss rate to determine maximum number of packets to be requested from playing window. 
2. Similar to CheckBufferState(), this function captures the state of buffer to determine adding or dropping a layer (description).
3. Finally, it calls sortrare() for various regions of buffer based on determined orders of packet scheduling to select and assign packets in each region.
*/

void RPALApp::QA()
{
        static FILE * log20 = fopen("RPRIMElog2.out","w+");
        if(log20==0) log20=fopen("RPRIMElog2.out","a+");
        static FILE *log51= fopen("RPRIMElog4.out","w+");
        if(log51==0) log51=fopen("RPRIMElog4.out","a+");
        static FILE *log50 = fopen("RPRIMElog3.out","w+");
        if(log50==0) log50=fopen("RPRIMElog3.out","a+");
	static FILE *log19=fopen("RPRIMENeigh.out","w+");
        if(log19==0) log19=fopen("RPRIMENeigh.out","a+");
	static FILE * log2= fopen("RPRIMETMAXBT.out","w+");
        if(!log2) log2= fopen("RPRIMETMAXBT.out","a+");
        static FILE * log21 = fopen("RPRIMEplaygap.out","w+");
        if(log20==0) log21=fopen("RPRIMEplaygap.out","a+");

	if(stopped_)
    	  return;

        bzero(tabqualmirror,MAX_BUFFER*sizeof(int));
	bzero(tablemirror,MAX_BUFFER*MAX_LAYER*sizeof(int));         
	int PktPerLayer[MAX_LAYER],OverEstPkt=0;
	float TotBW = totbw(), lossrate = 0, EWMAalpha = 0.3, samplelossrate=0;
	float TotUseBW =totbw2();
	float lossdev=0,LossDev[n_maxp];
	int i=0, j=0, TotPkt=0, TotPktCopy=0;
        bzero(LossDev,sizeof(LossDev));

        int max=0;
        for(i=0;i<MAX_LAYER;i++)
           {if(max<=BufEndIndex[i]) max=BufEndIndex[i];
           } 
        maxts=(max>WindowSize ? max : WindowSize);                                        
	float TotDev=0,TotUseDev=0;
        int TotalLoss=0;
	for (i = 0; i < Grayindex; i++)
	{   	TotDev+=DevBW[i];
	        TotUseDev+=DevUseBW[i];
		if ( EndSeqNo[i] != BeginSeqNo[i])
		{
		 samplelossrate = 100 * LossCount2[i] / (float)(EndSeqNo[i] - BeginSeqNo[i]);
		 if (!firstqa) {
			LossRate[i] = samplelossrate;
			LossDev[i]=0;
		 }
		 else { 
			LossRate[i] = (1 - EWMAalpha) * LossRate[i] + EWMAalpha * samplelossrate;
			LossDev[i] = (1 - EWMAalpha) * LossDev[i] + EWMAalpha * fabs (samplelossrate - LossRate[i]);
		 }
                }
                else if(!firstqa){
			LossRate[i] = samplelossrate;
                        LossDev[i]=0;		
			}
		else { LossRate[i]= (1 - EWMAalpha) * LossRate[i] + EWMAalpha * 100;
		       LossDev[i] = (1 - EWMAalpha) * LossDev[i] + EWMAalpha * fabs (samplelossrate - LossRate[i]);
		 }
                lossrate += LossRate[i];
		lossdev += LossDev[i];

		BeginSeqNo[i] = EndSeqNo[i]; 
                if(firstqa) TotalLoss+=LossCount2[i];               
                else TotalLoss=0;
                if((GrayList[i].dist+1)<distance) {
                                                   assert(DEBUG_lastdist<=TIME);
                                                   DEBUG_lastdistavg+=(TIME-DEBUG_lastdist);
                                                   DEBUG_lastdist=TIME;
                                                   DEBUG_distch++;
                                                   distance_t=TIME;
                                                   DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
                                                   DEBUG_prevavgdist=TIME;
                                                   distance=GrayList[i].dist+1;
                                                   assert(distance<=10);
                                                  } 
	}
	lossrate /= (100 * Grayindex);
	lossdev /= (100 * Grayindex);
	Extra = (int)(TotDev * 3 * WindowWidth / PKT_SIZE);	
        TotPktCopy = TotPkt = (int)(TotBW * WindowWidth / PKT_SIZE);	
        if(TotPkt==0) {TotPkt=START_PKT*Grayindex;}
	int TotPkt2 = (int)(TotUseBW * WindowWidth /PKT_SIZE);
	int maxlosspkt = (TotPkt2>0 ? (int)(lossrate * TotPkt2) : 1);      
	lossrate = lossrate + lossdev;
        int maxlosspkt2 = (int)(lossrate * TotPkt2);
        maxlosspkt=maxlosspkt2;
        MaxPktLoss=maxlosspkt;
	int tot=0,zerobw=0;
	for(i=0;i<Grayindex;i++)
	 if(ewmabw[i]==0) {zerobw++;}
	 assert(zerobw<=Grayindex); 
	 for (i = 0; i < Grayindex; i++)
         { if(zerobw!=0 && Grayindex!=0)  
	   {if(ewmabw[i]!=0) DueNumPkt[i]=(int)( ( (float)(TotPkt * (Grayindex-zerobw)) * ewmabw[i])/(float)(Grayindex*TotBW));
	    else DueNumPkt[i]=(int) TotPkt/Grayindex;
	   }
	   else	DueNumPkt[i] = (int)(TotPkt * ewmabw[i] / TotBW);          
		assignindex[i]=0;
		tot +=DueNumPkt[i];
                if(TotDev!=0) DueNumExtraPkt[i]=(int)(Extra * DevBW[i] /TotDev);
		else DueNumExtraPkt[i]=0;
		LossCount2[i]=0;
	 }
	i=0;
	if(tot>0)
	{
	while(tot < TotPkt)
	 { if(i>=Grayindex) i=0;
	   DueNumPkt[i]++; tot++;
           i = (i + 1) % Grayindex;
	  
	   i++;
         }
	}
	int count=0;
	if(Grayindex>1)
	{for (i = 0; i < Grayindex; i++)
         {
                 if (DueNumPkt[i] == 0)          
                {
                        j = (i + 1) % Grayindex;
                        while (DueNumPkt[j] <= 1) j = (j + 1) % Grayindex;
                        DueNumPkt[i]++; DueNumPkt[j]--;
                }
                if(GrayList[i].dist>=distance) count++;
	 }
	} 
	float tempavail=0, tempavailext=0;
	for (i = 0; i < Grayindex; i++)
        {
	  if(firstduealoc[i]==0)
   	   { DuePkt[i]=(PktList*) malloc(DueSize[i]*sizeof(PktList));
             firstduealoc[i]=1;
           }

          Fullsender[i]=0;
    	  DueNumPkt[i]=DueNumPkt[i]+DueNumExtraPkt[i];	 
          if(DueNumPkt[i]>=DueSize[i])
            {while(DueSize[i]<DueNumPkt[i]) DueSize[i] *= 2;
	     assert(DueSize[i]>=DueNumPkt[i]);
             DuePkt[i]=(PktList*) realloc (DuePkt[i],DueSize[i] * sizeof(PktList));
	    }
	  bzero(DuePkt[i],DueSize[i] * sizeof(PktList));
	  RemNumPkt[i]=DueNumPkt[i];
        }

	if(srcflag!=-1) {DEBUG_TotAvail+=(Grayindex>1) ? tempavail/(Grayindex-1) : 0;	
			 DEBUG_TotAvailExt+=(Grayindex>1) ? tempavailext/(float)(Grayindex-1) : 0;}
	else {DEBUG_TotAvail+=(Grayindex>0) ? tempavail/Grayindex : 0;	
	      DEBUG_TotAvailExt+=(Grayindex>0) ? tempavailext/Grayindex : 0;}

        if (IsOverlap)
		OverEstPkt = TotPkt + Extra;		
	else
		OverEstPkt = TotPkt;
        int tempbufamt2[MAX_BUFFER];
	bzero(tempbufamt2,sizeof(tempbufamt2));
	int startindex;
	int tempindex;
	assert(WindowStart+MAX_BUFFER>WindowSize);
	tempindex=MaxTab % MAX_BUFFER;
	assert(WindowSize+MAX_BUFFER>MaxTab);
	if(MaxTab <= WindowSize)
	{tempindex=readtbuf();
	 if(tempindex==0) {printf("useless parents at %d with %d\n",rid_,Grayindex);
                           WindowPkt= (int)(0.5 * PKT_PER_SEC);
	                   return;
	                  }
	 assert (tempindex!=0);
	 tempindex=tempindex % MAX_BUFFER;
	 assert(WindowSize+MAX_BUFFER>tempindex);
	}
	memcpy(tempbufamt2,bufquality,MAX_BUFFER * sizeof(int));

	int flag = 1, effbufpresent=0, totbufneeded, totbufpresent;
	int NumLoss=0;
	int MinPktPerLayer = (int)(MWM * PKT_PER_SEC + WindowWidth * PKT_PER_SEC);
        int startloss=starttimestamp;
	endtimestamp=WindowStart;
	tempindex=endtimestamp % MAX_BUFFER;
        startindex= starttimestamp % MAX_BUFFER;
	bzero(diffind,n_maxp*sizeof(int));
	ActualPkt=TotPkt;
	TargetPkt=5000;
	int pkt=0;
	TargetPkt=MaxPktLoss;
	int W=(int)((srcwin*2)/WIN_SIZE);
	for(i=0;i<(W+2);i++)
  	  {bzero(DEBUG_avail[i],sizeof(int)*(n_maxp+2));
  	   bzero(DEBUG_avail2[i],sizeof(int)*(n_maxp+2));
	  }
	bzero(DEBUG_availwin,sizeof(int)*(W+2));
	bzero(DEBUG_availwin2,sizeof(int)*(W+2));

	if(dumpflag && startup==0 && TIME>(startuptime+20)) 
	  {  if(log50!=0) fprintf(log50,"%d %f %d ",rid_,tr_down,Grayindex);
             if(log51!=0) fprintf(log51,"%d %d \n",rid_,distance);
	     if(log20!=0) fprintf(log20,"%.2f %d %d ",TIME,rid_,playtime);
	     if(log21 !=0) fprintf(log21,"%d %d \n",rid_,playtime);
	     for(i=0;i<Grayindex;i++)
       	             {if(log20!=0) fprintf(log20,"%d %d %d \t",GrayList[i].nodid,GrayList[i].tplay,GrayList[i].tbuf);
 		      if(log50!=0) fprintf(log50,"%d ",GrayList[i].nodid);
		     }
	     if(log50!=0) fprintf(log50,"\n");
	     if(log20!=0) fprintf(log20,"\n");
	     fflush(log50);
             fflush(log20);
 	     dumpflag=0;
	  }			 
	 if(log19!=0) fprintf(log19,"%f %d %d %d %d %d %d %d %d ",TIME,rid_,playtime,WindowStart,lasttmax,Quality,PlayQuality,NumLoss,Grayindex);
	 for(i=0;i<Grayindex;i++)
        	 if(log19!=0) fprintf(log19,"%d : %d %d \t",GrayList[i].nodid,GrayList[i].tplay,GrayList[i].tbuf);
 	 if(log19!=0) fprintf(log19,"\n");
	 PlayQuality=Quality;
	 int TotPktCopy2=TotPkt2;
	int temp;
        int swarmbudget=0;
        TotPkt=TotPkt+Extra;
        int startswarm =WindowSize % MAX_BUFFER;
        int endswarm = ((max+1)>WindowSize ? (max+1) : WindowSize) % MAX_BUFFER;
        int effswarmbuf=0,swarmbuf=0,effswarmbuf2=0;
        int PktPerSwarm=0;
        while (flag ==1)
        {	effswarmbuf=0;
                swarmbuf=0;
                effswarmbuf2=0;
                if(startswarm<=endswarm)
                {for(j=startswarm; j<endswarm;j++)
                 { effswarmbuf += ((Quality >tempbufamt2[j]) ? tempbufamt2[j] : Quality);
                   effswarmbuf2 += (((Quality+1) >tempbufamt2[j]) ? tempbufamt2[j] : (Quality+1));
                   swarmbuf += tempbufamt2[j];
                 }
                }
                else 
                {for(j=startswarm; j< MAX_BUFFER; j++)
                 {effswarmbuf +=  ((Quality > tempbufamt2[j]) ? tempbufamt2[j] : Quality);
                  effswarmbuf2 += (((Quality+1) >tempbufamt2[j]) ? tempbufamt2[j] : (Quality+1));
                  swarmbuf += tempbufamt2[j];
                 }                                                        
                 for (j =0; j < endswarm; j++)
                 {effswarmbuf +=  ((Quality > tempbufamt2[j]) ? tempbufamt2[j] : Quality);
                  effswarmbuf2 += (((Quality+1) >tempbufamt2[j]) ? tempbufamt2[j] : (Quality+1));
                  swarmbuf +=tempbufamt2[j];
                 } 
                }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
                PktPerSwarm=((max+1)>WindowSize ? (max+1) : WindowSize) - WindowSize;
		TotPkt2 = TotPktCopy2; 
		TotPkt2 -= NumLoss;
		if(TotPkt2<0) {printf("error in totpkt2 %d %d \n",TotPkt2,NumLoss); 
                               TotPkt2=0;}

		flag = totbufpresent = effbufpresent = 0;
		totbufneeded = Quality * MinPktPerLayer - TotPkt2;		
		tempindex=WindowSize % MAX_BUFFER;
		startindex= WindowStart % MAX_BUFFER;
                if(startindex<=tempindex)
                 {      for(j=startindex; j<tempindex;j++)
			{ temp = (Quality > tempbufamt2[j]) ? tempbufamt2[j] : Quality;
                          effbufpresent += temp;
			}
                 }
                 else 
                 {      for(j=startindex; j< MAX_BUFFER; j++)
                        {temp = (Quality > tempbufamt2[j]) ? tempbufamt2[j] : Quality;
                         effbufpresent += temp;
			}
                	for (j =0; j < tempindex; j++)
                        {temp = (Quality > tempbufamt2[j]) ? tempbufamt2[j] : Quality;
                         effbufpresent += temp;
			}
	         }
	         
	         swarmbudget=(int)(TotUseBW * (float)(PktPerSwarm)/C); 
	         
                printf("time %f TotPkt %d TotPkt2 %d effbuf %d totbufneed %d totbufpres %d Totbw %f numloss %d totbw2 %f\n", TIME,TotPkt,TotPkt2,effbufpresent,totbufneeded, totbufpresent,TotBW,NumLoss,TotUseBW); 
              if( PlayQuality > 1 && Quality>1)
	      {	
		if (effbufpresent <= totbufneeded || (effswarmbuf+swarmbudget)<=(Quality*PktPerSwarm)) 
		{
			int totbuf = 0;
			int ineffbuf=0;
		 if(startindex<=tempindex)
                 {      for(j=startindex; j<tempindex;j++)
                        { if(tempbufamt2[j]>=Quality)
                           ineffbuf += tempbufamt2[j]-Quality;
                           totbuf += tempbufamt2[j];
                        }
                 }
                 else 
                 {      for(j=startindex; j< MAX_BUFFER; j++)
                        { if(tempbufamt2[j]>=Quality)
                            ineffbuf += tempbufamt2[j]-Quality;
                          totbuf += tempbufamt2[j]; 
                        }
                        for (j =0; j < tempindex; j++)
                        { if(tempbufamt2[j]>=Quality)
			    ineffbuf += tempbufamt2[j]-Quality;
                          totbuf += tempbufamt2[j];
                        }
                 }
		 startindex=tempindex;
	         tempindex=MaxTab % MAX_BUFFER;
                 assert(WindowSize+MAX_BUFFER>MaxTab);
		 if(MaxTab<= WindowSize)
	         {tempindex=readtbuf();
        	 assert (tempindex!=0);
	         tempindex=tempindex % MAX_BUFFER;
        	 assert(WindowSize+MAX_BUFFER>tempindex);
	         }

	         int ineffbufout=0;
 	         int totbufout=0;
	         if(startindex<=tempindex)
        	 {      for(j=startindex; j<tempindex;j++)
                         {  if (tempbufamt2[j] >=Quality)
				ineffbufout += tempbufamt2[j]-Quality;
			   totbufout += tempbufamt2[j];
			 }
	         }
        	 else 
	         {      for(j=startindex; j< MAX_BUFFER; j++)
                          {if (tempbufamt2[j] >=Quality)
				ineffbufout += tempbufamt2[j]-Quality;
                           totbufout += tempbufamt2[j];
			  }
                        for (j =0; j < tempindex; j++)
			{if (tempbufamt2[j] >=Quality)
                                ineffbufout += tempbufamt2[j]-Quality;
                           totbufout += tempbufamt2[j];
			}
	          }


			assert(totbuf+totbufout >= 0);
			Quality--;		
			PlayQuality--;
			float inefficiencyout = 100 * (((totbuf+totbufout) > 0) ? (ineffbuf+ineffbufout) / (float)(totbuf+totbufout) : 0);
			float inefficiency = 100 * (((totbuf) > 0) ? (ineffbuf) / (float)(totbuf) : 0);
			DEBUG_DropCount++; DEBUG_Inefficiency += inefficiency;
			printf("%f : layer %d dropped. DEBUG_Inefficiency = %.2f %f %%\n", TIME, Quality, inefficiency,inefficiencyout);
			flag = 1;
		}
	      }	
	}


	TotPktCopy = TotPkt;

	bzero(PktPerLayer, sizeof(PktPerLayer));
	if (TotBW < 0.1) 
		TotBW = 0.1;	
	assert(TotBW >= 0.1);

        int bufbw=0,newbw=0;

              
		ActualPkt=TotPkt;
		float tempqual=0,tempqual2=0;
		int tempPkt=0;
		int tempneeded=0;

		tempqual=0;
		tempqual2=0;
		starttimestamp=endtimestamp;
		TotPkt=ActualPkt;
		int newbt=0,newneeded=0;
		int bufneeded=0,bufbt=0;
		int qualneeded=0,qualbt=0;
		int targetqual=Quality;
		if(TotPkt>0 && MaxTab>WindowSize)
		{       qual = ((float)Quality); 
			endtimestamp=MaxTab+1;
			
			if(endtimestamp<=starttimestamp) { if(log2!=0) fprintf(log2,"%f %d %d %d %f %d %d %d\n",TIME,rid_,TotPkt,TotPktCopy,TotBW,ActualPkt,starttimestamp,endtimestamp);
						  	   else printf("%f %d %d %d %f %d %d %d\n",TIME,rid_,TotPkt,TotPktCopy,TotBW,ActualPkt,starttimestamp,endtimestamp);
							   TotPkt=0;
                                            		 }
			if(!firstqa && lasttmax==-1) {lasttmax=endtimestamp-(int)(WIN_SIZE*PKT_PER_SEC); firstqa=1;}
			
			starttimestamp=((max+1)>WindowSize ? (max+1) : WindowSize);
			maxts=starttimestamp-1;
						  
                        float tempqual=(float)TotBW/(float)C;
                        targetqual=(int)ceil(tempqual);
                        if(targetqual>MAX_LAYER) targetqual=MAX_LAYER;
                        if(targetqual<Quality) targetqual=Quality;

			TotPkt=ActualPkt; 
			TargetPkt=TotPkt;
			int W=(int)((srcwin*2)/WIN_SIZE);
			
			if(TotPkt>0 && endtimestamp>WindowStart)
			{  
			   tempPkt=TotPkt;
			   tempneeded=TargetPkt-Extra;			   
			   if (tempneeded<0) tempneeded=0;
			   qualneeded=ActualPkt;
			   starttimestamp=WindowStart;
                           endtimestamp=MaxTab+1;
                           int tempstarttimestamp=0;
      		           
      		           tempstarttimestamp=((max+1)>WindowSize ? (max+1) : WindowSize);      		            
                           if(endtimestamp==tempstarttimestamp) {tempstarttimestamp=tempstarttimestamp-1; if (tempstarttimestamp<0) tempstarttimestamp=0; }
                           if(endtimestamp<tempstarttimestamp) 
                             {
                              tempstarttimestamp=(endtimestamp-(int)(WindowWidth * PKT_PER_SEC))>0 ? (endtimestamp-(int)(WindowWidth * PKT_PER_SEC)) : 0;
                              assert(tempstarttimestamp>=0);
                             } 
                           sortrare(tempstarttimestamp,endtimestamp,targetqual,tempbufamt2,0);      		           

                           TargetPkt=MaxPktLoss;
                           starttimestamp=startloss;
                           endtimestamp=WindowStart;
                           for(i=0;i<Grayindex;i++)
                             {
                              if(GrayList[i].nodid==0)  
                                Fullsender[i]=1;                                      
                             }                            
                          	
                          sortrare(starttimestamp,endtimestamp,Quality,tempbufamt2,1);
                          NumLoss=TotPkt-ActualPkt;


                          TotPkt=TotPkt-NumLoss;
                          if(TotPkt<0) {printf("error in totpkt2 %d %d \n",TotPkt,NumLoss); 
                      	  TotPkt=0;}
                          TargetPkt=TotPkt;                        
                          for(i=0;i<Grayindex;i++)
                              diffind[i]=assignindex[i];
                          
                          endtimestamp=WindowSize;
                          starttimestamp = WindowStart;  
                                
                          sortrare(starttimestamp,endtimestamp,Quality,tempbufamt2,0);
                                
                          OrderListWithBufferSlope();
                          starttimestamp=WindowSize;
                          endtimestamp=tempstarttimestamp;
                          for(i=0;i<Grayindex;i++)
                               {
                                 if(GrayList[i].nodid==0 && RemNumPkt[i]>0)
                                   Fullsender[i]=0;
                               }  
                            
                              
                          if(endtimestamp==starttimestamp) {starttimestamp=starttimestamp-1; if (starttimestamp<0) starttimestamp=0; }
                          if(endtimestamp<starttimestamp) starttimestamp=WindowStart;
                          if(endtimestamp<starttimestamp) {printf("end %d is smaller than windowstart %d, adjusted\n",endtimestamp,starttimestamp);
                                                            starttimestamp=playtime+(int)(MWM*PKT_PER_SEC);}
      		          if(starttimestamp<endtimestamp)
                             sortrare(starttimestamp,endtimestamp,targetqual,tempbufamt2,0);      		           
			   bufneeded=tempneeded;
			   bufbw=(qualneeded>TargetPkt ? (qualneeded-TargetPkt) : 0); 
			   if((TargetPkt-Extra)>0) {bufbt=(tempneeded>0 ? (TargetPkt-Extra) : 0);
			                           }
			   qualbt=ActualPkt;                 
			}
			else {
			      endtimestamp=(W+1)*(int)WindowWidth * PKT_PER_SEC+playtime+(int)(MWM * PKT_PER_SEC);
                              endtimestamp=(endtimestamp>MaxTab ? endtimestamp : MaxTab);
			      sortrare(WindowStart,endtimestamp,Quality,tempbufamt2,0);
                             }   
			TotPkt=ActualPkt;
		}
		else {int W=(int)((srcwin*2)/WIN_SIZE);
		      endtimestamp=(W+1)*(int)WindowWidth * PKT_PER_SEC+playtime+(int)(MWM * PKT_PER_SEC);
		      endtimestamp=(endtimestamp>MaxTab ? endtimestamp : MaxTab);
		      sortrare(WindowStart,endtimestamp,Quality,tempbufamt2,0);
		     }                                                       	
	        float addcond;
	        if(PktPerSwarm>0) 
	          addcond = TotUseBW-(TotUseDev-(float)(effswarmbuf2*C)/(float)PktPerSwarm);
                else addcond=0;
		if (addcond>(Quality+1)*C)		
		{
			if (TotUseBW > (Quality + 1) * C)
			{	if (Quality < MAX_LAYER)
				{
	
					DEBUG_NumOfChangeSum++;
					printf("%f : adding layer %d totpkt %d %d\n", TIME, Quality,TotPkt,DEBUG_NumOfChangeSum);
					Quality++;		
				}
				
			}
		}
		
        static FILE * log=fopen("PRIMErareold.out","a+");
        static FILE * log1=fopen("PRIMErare.out","a+");
        static FILE * log11=fopen("PRIMErare2.out","a+");
        
        
        int maxdelta=(int)floor((float)(MaxTab+1-(playtime+(int)(MWM * PKT_PER_SEC)))/((float)(WIN_SIZE*PKT_PER_SEC)));
        if(maxdelta<0) maxdelta=W+2;
        if(log!=0)
         {fprintf(log,"-1 %f %d\n",TIME,rid_);
          if(startup==0 && TIME>(startuptime+20)) {fprintf(log1,"-1 %f %d \n",TIME,rid_);
                             fprintf(log11,"-1 %f %d \n",TIME,rid_);
                            } 
          for(j=0;j<W+2;j++)
            {fprintf(log,"%d %d %d %d ",distance,rid_,j,DEBUG_availwin[j]);
             if(TIME>(startuptime+20)) {fprintf(log1,"%d %d %d %d ",distance,rid_,j,DEBUG_availwin[j]);
                                fprintf(log11,"%d %d %d %d ",distance,rid_,j,DEBUG_availwin2[j]);
                               } 
             for(i=0;i<(Grayindex+2);i++)
              {fprintf(log,"%d %f ",DEBUG_avail[j][i], (DEBUG_availwin[j]>0 ? ((float)DEBUG_avail[j][i]/(float)DEBUG_availwin[j]) : 0));
               if(startup==0 && TIME>(startuptime+20)) {fprintf(log1,"%d %f ",DEBUG_avail[j][i], (DEBUG_availwin[j]>0 ? ((float)DEBUG_avail[j][i]/(float)DEBUG_availwin[j]) : 0));
                                  fprintf(log11,"%d %f ",DEBUG_avail2[j][i], (DEBUG_availwin2[j]>0 ? ((float)DEBUG_avail2[j][i]/(float)DEBUG_availwin2[j]) : 0));
                                 } 
              } 
             fprintf(log,"\n"); 
             if(startup==0 && TIME>(startuptime+20)) {fprintf(log1,"\n");
                                fprintf(log11,"\n");
                               } 
            } 
         }    
       
	if (startup==0 && TIME>(startuptime+20))
	{DEBUG_avgcount++;
	 DEBUG_normnew+=(newneeded>0 ? ((float)newbt/(float)newneeded) : 0);
	 DEBUG_normbuf+=(bufneeded>0 ? ((float)bufbt/(float)bufneeded) : 0);
	 DEBUG_normqual+=(qualneeded>0 ? ((float)qualbt/(float)qualneeded) : 0);
	 DEBUG_normnewbw+= (TotPktCopy>0 ? (float)newbw/(float)TotPktCopy : 0);
	 DEBUG_normbufbw+= (TotPktCopy>0 ? (float)bufbw/(float)TotPktCopy : 0);
	 if(log2!=0) fprintf(log2,"norm in %d %f %f %f %f %f %f %d %d %d %d %d %d\n",rid_,TIME,DEBUG_normnew,DEBUG_normbuf,DEBUG_normqual,DEBUG_normpa,DEBUG_normplay,newneeded,newbt,bufneeded,bufbt,qualneeded,qualbt);

	 DEBUG_avgdelta+=(WindowSize-WindowStart);
	
	 if(MaxTab-lasttmax>0);
	   DEBUG_avggaplastthis+=MaxTab-lasttmax;
	
	 if(lasttmax>max)
	  DEBUG_avggapmaxlast += lasttmax-max;
	
	 lasttmax=MaxTab;
	
	 DEBUG_avggapavailtmax+=max-playtime;
	
	 if(lasttmax>playtime)
		DEBUG_avggaptmax+=lasttmax-playtime;
	if(lasttmax>max)
		DEBUG_avggapstretch+=lasttmax-max;
	}
	else lasttmax=MaxTab;

	PA(tempbufamt2);
}


/*
This function order assigned packets in playing regions based on some formulas (pktslope)
sort the list according to the slope criteria, will give an ordered list
 (y - mx,x) is the rank of a point. smaller c means that the slant line is closer to the origin and hence more important
 if y - mx(=c) are same check if x is larger.
*/

void RPALApp::OrderListWithBufferSlope()
{
	int i, j, k, li, lj, tsi, tsj;
	for(i=0;i<Grayindex;i++)
	{ if(assignindex[i]==0) continue;
	  for(j=diffind[i];j<assignindex[i];j++)
		for(k=j+1;k<assignindex[i];k++)
		{
			tsi = DuePkt[i][j].timestamp; tsj = DuePkt[i][k].timestamp;
			li = DuePkt[i][j].layer_id; lj = DuePkt[i][k].layer_id;
			if ( (tsi + PktSlope * li > tsj + PktSlope * lj) || ((tsi + PktSlope * li == tsj + PktSlope * lj) && (li - lj) > 0) )
			{	
				DuePkt[i][j].layer_id = lj; DuePkt[i][j].timestamp = tsj;
				DuePkt[i][k].layer_id = li; DuePkt[i][k].timestamp = tsi;
			}
		}

	}
}

/*
This function is mainly responsbile of filling the remaining packet budget of all parents with marked packets (if there is any remaining budget that we could not assign useful packets).
This basically captures the content bottleneck meaning there was bandwidth but not enough content to be requested. -2 packets are for remaining budget based solely on bandwidth of parents and -3 
is for remaining budget based on deviation of bandwidth.
In each scheduling event we try not to send all the requests simultaneously due to increase in loss rate. PendingReq takes care of sending the rest of prepared requests over a short time.
*/
void RPALApp::PA(int BufState[MAX_BUFFER])
{
	int i;
	int srcmintime=0;
	if(srcflag!=-1) srcmintime=GrayList[srcflag].tplay;
	starttimestamp=WindowSize;
	
	int cou=0;
        bzero(reglength,n_maxp*sizeof(int));
        bzero(extralength,n_maxp*sizeof(int));	
	int paneeded[n_maxp],pabt=0,tempneeded=0;
	bzero(paneeded,sizeof(paneeded));
	for(i=0;i<Grayindex;i++)
	{if(RemNumPkt[i]!=0) paneeded[i]=RemNumPkt[i];
	 if(ActualPkt==0)	
		{
		 index[i]=0;
  		 DueNumPkt[i]=assignindex[i];
                 DueNumPktCons[i]=DueNumPkt[i];
		 seqnum[i]++;
		 extralength[i]=0;
		 reglength[i]=0; 
		 if(cou<1)
                 { SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],0);
 		   cou++;
		 }
		 else  sending_time[i]=0;
		}
	else if(GrayList[i].nodid!=0)
		  { 
	            if(RemNumPkt[i]>0 && paneeded[i]>0 ) {pabt += RemNumPkt[i]; tempneeded+=paneeded[i];}
	            if(RemNumPkt[i]>DueNumExtraPkt[i])
		     {reglength[i]=RemNumPkt[i]-DueNumExtraPkt[i]; 
		      while(RemNumPkt[i]>DueNumExtraPkt[i]) {DuePkt[i][assignindex[i]].timestamp=-2; 
		  			                     DuePkt[i][assignindex[i]++].layer_id=-2;
		  			                     RemNumPkt[i]--;
		  			                     }
		     }	
		     extralength[i]=RemNumPkt[i];		                     
		    while(RemNumPkt[i]>0) {DuePkt[i][assignindex[i]].timestamp=-3;
		                          DuePkt[i][assignindex[i]++].layer_id=-3;
		                          RemNumPkt[i]--;
		                         }
		                                                                                                                                                                                          			                     
		   assert(RemNumPkt[i]==0);
		   DueNumPkt[i]=assignindex[i];
		   DueNumPktCons[i]=DueNumPkt[i];
		   seqnum[i]++;
                  if(DueNumPkt[i]!=0) { if(cou<1 && srcflag!=-1) {cou++; SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],0);}
                                        else if(cou<1 && srcflag==-1) {cou++; SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],0);}
					else sending_time[i]=0;
				      }
		  }
	 }
	
	if(ActualPkt!=0 && srcflag!=-1)
	{	if(RemNumPkt[srcflag]==0)
		{  DueNumPkt[srcflag]=assignindex[srcflag];
                   DueNumPktCons[srcflag]=DueNumPkt[srcflag];
		   index[srcflag]=0;
		   seqnum[srcflag]++;
                   SendRequest(0, DuePkt[srcflag], DueNumPkt[srcflag],0);
		}
		else 
		{  
		  if(RemNumPkt[srcflag]!=0 && paneeded[srcflag]>0) {
			  pabt += RemNumPkt[srcflag];
			  tempneeded+=paneeded[srcflag];} 
                  if(RemNumPkt[srcflag]>DueNumExtraPkt[srcflag])
                  {reglength[srcflag]=RemNumPkt[srcflag]-DueNumExtraPkt[srcflag];
                   while(RemNumPkt[srcflag]>DueNumExtraPkt[srcflag]) {DuePkt[srcflag][assignindex[srcflag]].timestamp=-2;
                                                                      DuePkt[srcflag][assignindex[srcflag]++].layer_id=-2;
                                                                      RemNumPkt[srcflag]--;
                                                                     }
                  }
                  extralength[srcflag]=RemNumPkt[srcflag];
		  while(RemNumPkt[srcflag]>0) {DuePkt[srcflag][assignindex[srcflag]].timestamp=-3;
                                          DuePkt[srcflag][assignindex[srcflag]++].layer_id=-3;
                                          RemNumPkt[srcflag]--;
                                         }
                   assert(RemNumPkt[srcflag]==0);

 		  DueNumPkt[srcflag]=assignindex[srcflag];
                  DueNumPktCons[srcflag]=DueNumPkt[srcflag];
		  seqnum[srcflag]++;
                  SendRequest(GrayList[srcflag].nodid, DuePkt[srcflag], DueNumPkt[srcflag],0);
		}
	}
        if(startup==0 && TIME>(startuptime+20)) {DEBUG_neg2pkt+=pabt;
	 DEBUG_normpa+=(tempneeded>0) ? ((float)pabt/(float)tempneeded) : 0;   
	}        
	bzero(index, n_maxp*sizeof(int));
	                  
}
/*
This is the start function which initializes and zeros all arrays and set the incoming and outgoing degree of peers based on 
their bandwidth and n_maxp. 
*/

void RPALApp::start()
{
        assert(stopped_==1);
        
        if(TIME>10 && randomstart) {float randd=drand48()/50;
                                     starttimer_.resched(randd/2);
                                     randomstart=0;
                                     return;
                                    } 
	int i;
	init();
	int tempmax=0, tempmin=0;
	distance=9;
        if(rid_!=0) {tempmin=(int)(((float)(n_maxp*degree))/(float)960000.00);
        
	int n_maxp2;
	tempmax=(int)(tempmin);
	n_maxp2=(tempmin<n_max ? tempmin : n_max);
	printf("start %d at %f deg %d outdeg %d\n",rid_, TIME,degree,n_maxp2);
        spal[rid_]->sid_=rid_;   
        spal[rid_]->n_maxp=n_maxp2;	
        n_maxp=n_maxp2;
        n_minp=n_maxp2;
	}
	if(firstst)                                
         	GrayList= (nodelist *) malloc((n_maxp) * sizeof(nodelist));
	bzero(GrayList, sizeof(nodelist)* n_maxp);
	for(i=0;i<n_maxp;i++)
	  GrayList[i].bufsize=0;
	targetneigh=n_minp;
	assert(targetneigh<=n_maxp);
	assert(targetneigh>=n_minp);
	stopped_ = 0;
	tr_start=TIME;
	DEBUG_prevavg2=0;
        DEBUG_prevavg2=TIME;
	LastBWCalcTime = TIME;
	DEBUG_lastpar=TIME;
	DEBUG_lastdist=TIME;
	if(rid_ == 0) bootStartup();	
	else {if(firstst) start_all();
	      zero_all();
	      Startup();
	     } 
}

void RPALApp::init()
{ 
  distance=0; Num_Senders=0; TargetPkt=0; DEBUG_Excesspkt=0;  distance_t=0;
 difindex=0;stdifindex=0;
 DEBUG_Excessevent=0; MaxPktLoss=0; firstqa=0; firstfill=1; firstrequest=1; firstcal=1; firstbw=1; startpoint=-1;
 starttimestamp=0; endtimestamp=0; Quality=1; PlayQuality=1; qual=0; startplay=-2; fastmode=-1;
 lastSend=-1; DEBUG_neg2pkt=0; srcflag=-1; randomstart=1;
 firstboot=0; udpindex=2; MaxTab=0; OldMaxTab=0; DEBUG_upper=0; DEBUG_down=0; DEBUG_totalpkt=0; lasttry=0;  Ref_TH=1; bufplayindex=0; DEBUG_TotExt=0; DEBUG_TotExt2=0;
 DEBUG_NumAggPkt=0; DEBUG_NumAggPkt1=0; DEBUG_NumAggPkt2=0; DEBUG_NumAggPrime1=0; DEBUG_NumAggPrime2=0; DEBUG_NumAggPrime=0; DEBUG_ewmahop=0; DEBUG_ewmatime=0; 
 DEBUG_DevHop=0; DEBUG_Devtime=0; DEBUG_TotAvail=0; DEBUG_TotAvailExt=0; DEBUG_Extrasw2=0; DEBUG_Extrasw3=0; DEBUG_Extradif2=0; DEBUG_Extradif3=0; 
 DEBUG_AGGdiff=0; DEBUG_AGGsw=0;  DEBUG_avggapavailtmax=0; DEBUG_avggaptmax=0;  DEBUG_avggaplastthis=0; DEBUG_avggapstretch=0; DEBUG_avggapmaxlast=0;  DEBUG_avgdelta=0; 
 DEBUG_avgcount=0; dumpflag=1; DEBUG_tottimestamp=0;  DEBUG_normpa=0; DEBUG_normbuf=0; DEBUG_normplay=0; DEBUG_normqual=0; DEBUG_normnew=0;  DEBUG_normnewbw=0; DEBUG_normbufbw=0; 
 playtime=0; playtime2=-2000; DEBUG_laterequests=0;  startup=1; DEBUG_AvgQuality=0; DEBUG_AvgQuality2=0;  DEBUG_AvgQuality3=0; 
 DEBUG_NumOfChangeSum=1; DEBUG_ExtraPkt3=0; MWM=0.4; IsOverlap=1; EnableQACheck=1; 
 EWMABW_WT=0.01; LookAhead=2.0;  DEBUG_DropCount=0; DEBUG_LossC2=0; DEBUG_Nloss=0;  DEBUG_Inefficiency=0;  DEBUG_LayerDiff=0;  DEBUG_Unrequested=0;  PktSlope=1; 
 stopped_=0;  WarmUp=1;  DEBUG_avghopcount=0; DEBUG_avgelaps=0;  RefTime=0;  pendindex=0;  
 LastWindowStartPosition=0; firststart=1; udpindex=0; bufferlength=0; DEBUG_totrcvd=0; maxts=0; lasttmax=-1; DEBUG_reportloss=0; 
 DEBUG_recloss=0; coop=1; lasttimeboot=0; firstpend=-1; DEBUG_TotalPktRequested = 0; startuptime=0; firstslide=0;
 DEBUG_avgpar=0; DEBUG_avgpar2=0; DEBUG_avgch=0;DEBUG_prevavg=0; DEBUG_prevavg2=0; prestop=0; DEBUG_avgdist=0; DEBUG_prevavgdist=0; DEBUG_lastpar=0; DEBUG_lastdist=0; DEBUG_lastparavg=0; DEBUG_lastdistavg=0; DEBUG_parch=0; DEBUG_distch=0;
 FILE * fp=fopen ("rin.in","r");
         if(fp!=0) {fscanf(fp,"%f %d %d %d %d",&WIN_SIZE,&srcwin,&n_maxp,&SRC_D,&seed);
                    n_minp=n_maxp; fclose(fp);}
 LookAhead = WIN_SIZE + MWM;
 
 MAX_PACKETS = (int)(PKT_PER_SEC * MAX_SIM_TIME * 2);
                         

}

void RPALApp::zero_all()
{ bzero(LastBWCalc,n_maxp*sizeof(float));
  bzero(DEBUG_hopdist,sizeof(DEBUG_hopdist));
  if(firstst) bzero(firstduealoc,n_maxp*sizeof(int));
  bzero(ewmausebw,n_maxp*sizeof(float));
  bzero(ewmabw, n_maxp*sizeof(float));
  bzero(sampleBW, n_maxp*sizeof(float));
  bzero(DEBUG_sampleContBTBW,n_maxp*sizeof(float));
  bzero(DEBUG_ewmaconbtbw,n_maxp*sizeof(float));
  bzero(DEBUG_ewmabw2,n_maxp*sizeof(float));
   bzero(DevUseBW,n_maxp*sizeof(float));
  bzero(DevBW,n_maxp*sizeof(float));
  bzero(NumUseful,n_maxp*sizeof(int));
  bzero(NumPktRcvd, n_maxp*sizeof(int));
  bzero(DEBUG_NumPRIMEPktRcvd,n_maxp*sizeof(int));
  bzero(NumConBT,n_maxp*sizeof(int));
  bzero(DueNumPkt,n_maxp*sizeof(int));
  bzero(RemNumPkt,n_maxp*sizeof(int));
  bzero(sending_time,n_maxp*sizeof(float));
  bzero(DEBUG_ExtraPkt, n_maxp*sizeof(int));
  bzero(DEBUG_ExtraPkt2,n_maxp*sizeof(int));
  bzero(Sender_TotPkt, n_maxp*sizeof(int));
  bzero(DEBUG_ContDif,n_maxp*sizeof(int));
  bzero(DEBUG_ContSW,n_maxp*sizeof(int));
  bzero(LossCount, n_maxp*sizeof(int));
  bzero(LossCount2, n_maxp*sizeof(int));
  bzero(EndSeqNo, n_maxp*sizeof(int)); 
  bzero(BeginSeqNo, n_maxp*sizeof(int)); 
  bzero(StSeqNo,n_maxp*sizeof(int)); 
  bzero(TotalLoss, n_maxp*sizeof(int)); 
  bzero(seqnum, n_maxp*sizeof(int)); 
  bzero(Ack, n_maxp*sizeof(int)); 
  bzero(reglength,n_maxp*sizeof(int));
  bzero(extralength,n_maxp*sizeof(int));
  bzero(DEBUG_reporloss,n_maxp*sizeof(int));
  bzero(nodeidpool,(MAX_NODES+1)*sizeof(int));
  bzero(DEBUG_NumDup,sizeof(DEBUG_NumDup));
  bzero(DEBUG_NumPktReq,sizeof(DEBUG_NumPktReq));
  bzero(bufindex,sizeof(bufindex));
  bzero(buftailtimestamp,sizeof(buftailtimestamp));
  bzero(tailbuf,sizeof(tailbuf));
  bzero(LossRate,n_maxp*sizeof(float));
  DEBUG_avail[0][0]=0;
  activeindex=0;
  bzero(bufquality,sizeof(bufquality));
  bzero(difbuf,sizeof(difbuf));
  int i,j;
  for (i = 0; i <= MAX_LAYER; i++)
  {bzero(buf[i], sizeof(buffer)*MAX_BUFFER); 
        for(j=0;j<MAX_BUFFER;j++)
        {buf[i][j].flag=0;
         buf[i][j].hopcount=0;
         buf[i][j].time=0;
        }
  }
  for (i = 0; i < MAX_LAYER; i++)
  {bzero(table[i], sizeof(ConTab)*MAX_BUFFER);
   bzero(table2[i], sizeof(int)*MAX_BUFFER);
   for(j=0;j<MAX_BUFFER;j++)
   {table[i][j].flag=0;
    table2[i][j]=0;
   }
  }
  bzero(tablemirror,MAX_BUFFER*MAX_LAYER*sizeof(int));
  bzero(tabqualmirror,sizeof(int)*MAX_BUFFER);
  bzero(tabqual,sizeof(int)*MAX_BUFFER);
  bzero(DEBUG_Late, sizeof(DEBUG_Late));
  bzero(BufEndIndex, sizeof(BufEndIndex));
  bzero(UdpList,sizeof(PktListBoot) * n_maxp);
  
  for (i =0; i < n_maxp; i++){
    srtt[i]=0.2;
    DueSize[i]=512;
    repnum[i]=-1;
   }
   
                                                  
}  

void RPALApp::start_all()
{ 
  firstduealoc=(int*) malloc(n_maxp*sizeof(int));
  Fullsender=(int*) malloc(n_maxp*sizeof(int));
  
  AssBWRatio=(float*)malloc(n_maxp*sizeof(float));

  srtt=(float*)malloc(n_maxp*sizeof(float));
  
  ewmausebw=(float*)malloc(n_maxp*sizeof(float));
  LastBWCalc=(float*)malloc(n_maxp*sizeof(float));
  
  ewmabw=(float*)malloc(n_maxp*sizeof(float));

  sampleBW=(float*)malloc(n_maxp*sizeof(float));
  
  DEBUG_sampleContBTBW=(float*)malloc(n_maxp*sizeof(float));

  DEBUG_ewmaconbtbw=(float*)malloc(n_maxp*sizeof(float));

  DEBUG_ewmabw2=(float*)malloc(n_maxp*sizeof(float));
  
  
  DevUseBW=(float*)malloc(n_maxp*sizeof(float));
   
  DevBW=(float*)malloc(n_maxp*sizeof(float));

  NumPktRcvd=(int*) malloc(n_maxp*sizeof(int));
  NumUseful=(int*) malloc(n_maxp*sizeof(int));
                          
  DEBUG_NumPRIMEPktRcvd=(int*) malloc(n_maxp*sizeof(int));

  NumConBT=(int*) malloc(n_maxp*sizeof(int));


  DueSize=(int*) malloc(n_maxp*sizeof(int));
  
  DueNumPkt=(int*) malloc(n_maxp*sizeof(int));
    
  diffind=(int*) malloc(n_maxp*sizeof(int));
  assignindex=(int*) malloc(n_maxp*sizeof(int));
  
  RemNumPkt=(int*) malloc(n_maxp*sizeof(int));
  
  index=(int*) malloc(n_maxp*sizeof(int));
  
  DueNumPktCons=(int*) malloc(n_maxp*sizeof(int));

  DueNumExtraPkt=(int*) malloc(n_maxp*sizeof(int));


  sending_time=(float*)malloc(n_maxp*sizeof(float));
  
  DEBUG_ExtraPkt=(int*) malloc(n_maxp*sizeof(int));
  
  DEBUG_ExtraPkt2=(int*) malloc(n_maxp*sizeof(int));
  Sender_TotPkt=(int*) malloc(n_maxp*sizeof(int));
  
  DEBUG_ContDif=(int*) malloc(n_maxp*sizeof(int));
  
  DEBUG_ContSW=(int*) malloc(n_maxp*sizeof(int));
  
  LossCount=(int*) malloc(n_maxp*sizeof(int));
  
  LossCount2=(int*) malloc(n_maxp*sizeof(int));
  
  EndSeqNo=(int*) malloc(n_maxp*sizeof(int));
  
  BeginSeqNo=(int*) malloc(n_maxp*sizeof(int));
  
  StSeqNo=(int*) malloc(n_maxp*sizeof(int));
  
  TotalLoss=(int*) malloc(n_maxp*sizeof(int));
  
  seqnum=(int*) malloc(n_maxp*sizeof(int));
  
  Ack=(int*) malloc(n_maxp*sizeof(int));
  
  repnum=(int*) malloc(n_maxp*sizeof(int));

  LossRate=(float*)malloc(n_maxp*sizeof(float));
  
  extralength=(int*) malloc(n_maxp*sizeof(int)); 
  reglength=(int*) malloc(n_maxp*sizeof(int)); 
  
  DEBUG_reporloss=(int*) malloc(n_maxp*sizeof(int));
  UdpList= (PktListBoot*) malloc(n_maxp * sizeof(PktListBoot));
  
}  
/*this function is for debugging*/  
void RPALApp::Dumpsnap()
{	static FILE * log29=fopen("RPRIMEChurn.dump","w+");
        if(log29==0) log29= fopen("RPRIMEChurn.dump","a");
	if(!startup) {DEBUG_avgpar+=Grayindex*(TIME-DEBUG_prevavg);
	              DEBUG_avgch+=spal[rid_]->requestindex*(TIME-DEBUG_prevavg);
	               DEBUG_prevavg=TIME;
	               DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
	               DEBUG_prevavgdist=TIME;
                      }
                      DEBUG_avgpar2+=Grayindex*(TIME-DEBUG_prevavg2);
                      DEBUG_prevavg2=TIME;
        if(log29!=0) {fprintf(log29, "%d %.2f %.2f %.2f %.2f %.2f %.2f %f %f %f %f %f %f %f %d %f %f %f %d %f %d %d %f %f %f %f\n",rid_,TIME,startuptime,tr_start, 
        (DEBUG_NumAggPkt>0 ? (float)DEBUG_NumAggPrime/(float)DEBUG_NumAggPkt : 0) , DEBUG_avgpar,DEBUG_prevavg,(TIME>startuptime ? DEBUG_avgpar/(TIME-startuptime) : 0),DEBUG_avgdist,DEBUG_prevavgdist,DEBUG_avgch,(TIME>startuptime ? DEBUG_avgpar/(TIME-startuptime) : 0),
        DEBUG_lastpar,DEBUG_lastparavg,DEBUG_parch,(DEBUG_parch>0 ? DEBUG_lastparavg/DEBUG_parch : 0),DEBUG_lastdist,DEBUG_lastdistavg,DEBUG_distch,(DEBUG_distch>0 ? DEBUG_lastdistavg/DEBUG_distch : 0),DEBUG_NumAggPkt2, DEBUG_NumAggPrime2,(DEBUG_NumAggPkt2>0 ? ((float)DEBUG_NumAggPrime2/(float)DEBUG_NumAggPkt2) : 0),
        DEBUG_avgpar2,DEBUG_prevavg2,((float)DEBUG_avgpar2)/(TIME-tr_start));
                      fflush(log29);
                     }   
}

/*this function is for debugging*/                       
void RPALApp::DumpSimData()
{
	int i=0, j=0;

	static FILE *fp1 = fopen("RPRIMESimData.out", "w+");
	if(fp1==0) fp1 = fopen("RPRIMESimData.out", "a");
	if (!fp1) perror("fopen failed");

	static FILE *log22 = fopen("RPRIMEHop1.out", "w+");
	if(log22==0) log22 = fopen("RPRIMEHop1.out", "a");

	 static FILE *log28 = fopen("RPRIMEHop2.out", "w+");
        if(log28==0) log28 = fopen("RPRIMEHop2.out", "a");


	static FILE *fp3 = fopen("RPRIMEDrop.out", "w+");
	if(fp3==0) fp3 = fopen("RPRIMEDrop.out", "a");

	static FILE *log23 = fopen("RPRIMEAvgQual.out", "w+"); 
	if(log23==0) log23 = fopen("RPRIMEAvgQual.out", "a");

	static FILE * log21=fopen("RPRIMEAggres.out","w+");
        if(log21==0) log21=fopen("RPRIMEAggres.out","a");

	static FILE * log24=fopen("RPRIMEGap.out","w+");
	if(log24==0) log24= fopen("RPRIMEGap.out","a");
	
	static FILE * log25=fopen("RPRIMEUtil.out","w+");
        if(log25==0) log25= fopen("RPRIMEUtil.out","a");

	static FILE * log26=fopen("RPRIMENegone.out","w+");
        if(log26==0) log26= fopen("RPRIMENegone.out","a");

	static FILE * log27=fopen("RPRIMENegtwo.out","w+");
        if(log27==0) log27= fopen("RPRIMENegtwo.out","a");
        static FILE *log29 = fopen("RPRIMEChurn.out", "w+");
        if(log29==0) log29 = fopen("RPRIMEChurn.out", "a");
	int numaggpkt=0;
	static FILE * log2=fopen("RPRIMEFEC.out","w+");
        if(log2==0) log2= fopen("RPRIMEFEC.out","a");
        fprintf(log2,"%d %d %d %d %d %d %d ",rid_,DEBUG_Extradif2,DEBUG_Extrasw2,DEBUG_Extradif3,DEBUG_Extrasw3,DEBUG_AGGdiff,DEBUG_AGGsw);
        
        printf("DEBUG_NumAgg %d %d %d %d %d\n",DEBUG_NumAggPkt,DEBUG_NumAggPrime ,rid_,DEBUG_TotExt,DEBUG_TotExt2);        
        float temptime=TIME;
        if(TIME<6000) temptime=TIME;
        else temptime=6000;
        if(DEBUG_NumAggPkt>((temptime-(startuptime+20))*(float)(PKT_PER_SEC*MAX_LAYER))) numaggpkt=(int)((temptime-(startuptime+20))*PKT_PER_SEC*MAX_LAYER);
	else numaggpkt=DEBUG_NumAggPkt;
	printf("DEBUG_NumAgg %d %d %d\n",DEBUG_NumAggPkt,rid_,numaggpkt);
	if(log25!=0 && numaggpkt>0) fprintf(log25,"%d %.2f %d %d %d %d %d %d\n",rid_,(float)DEBUG_NumAggPrime/(float)numaggpkt,DEBUG_NumAggPrime1,DEBUG_NumAggPrime2,DEBUG_NumAggPkt1,DEBUG_NumAggPkt2,DEBUG_NumAggPrime,numaggpkt);
	if(numaggpkt>0 && log26!=0) fprintf(log26,"%d %.2f \n",rid_,(float)DEBUG_TotExt/(float)numaggpkt);

        if(log23!=0) fprintf(log23, "%d %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f ",rid_,(numaggpkt>0 ? (float)DEBUG_NumAggPrime/(float)numaggpkt : 0) ,(numaggpkt>0 ? (float)DEBUG_TotExt/(float)numaggpkt : 0 ),DEBUG_ewmahop,DEBUG_DevHop,(DEBUG_totrcvd>0 ? (float)DEBUG_avghopcount/(float)DEBUG_totrcvd : 0),DEBUG_ewmatime,DEBUG_Devtime,(DEBUG_totrcvd>0 ? (float)DEBUG_avgelaps/(float)DEBUG_totrcvd : 0));
	float dupratio, AvgEff=0,AvgExtraPkt2=0, AvgExtraPkt = 0,totpkt =0;
	int totlate = 0,totreq=0, totdup=0;
	int totconbtpkt=0;
	if(log28!=0) fprintf(log28,"%d %.2f %.2f %.2f ",rid_,(DEBUG_totrcvd>0 ? (float)DEBUG_avghopcount/(float)DEBUG_totrcvd : -1),DEBUG_ewmahop,DEBUG_DevHop);
	for(i=0;i< MAX_LAYER; i++)
	{
		
		dupratio = 100 * ((DEBUG_NumPktReq[i] > 0) ? DEBUG_NumDup[i] / (float)DEBUG_NumPktReq[i] : 0);
		if(fp1!=0) {fprintf(fp1, "%d %d %d %d %.2f \n", rid_,i, DEBUG_NumPktReq[i], DEBUG_NumDup[i], dupratio);
			fflush(fp1);}
		totreq += DEBUG_NumPktReq[i]; totdup += DEBUG_NumDup[i]; 
	}
	float AvgGapavail=0,AvgGaplasttmax=0,AvgGaplastthis=0,AvgGaptmax=0,AvgGapstretch=0,AvgDelta=0;
	if(DEBUG_avgcount!=0)
	{	AvgDelta=(float)((float)DEBUG_avgdelta/(float)DEBUG_avgcount);
		AvgGapavail=(float)((float)DEBUG_avggapavailtmax/(float)DEBUG_avgcount);
		AvgGaplasttmax =(float)((float)DEBUG_avggapmaxlast/(float)DEBUG_avgcount);
		AvgGaplastthis=(float)((float)DEBUG_avggaplastthis/(float)DEBUG_avgcount);
		AvgGaptmax=(float)((float)DEBUG_avggaptmax/(float)DEBUG_avgcount);
		AvgGapstretch=(float)((float)DEBUG_avggapstretch/(float)DEBUG_avgcount);
	}
	if(log24!=0) {fprintf(log24,"%d %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f\n",rid_,((float)AvgGapavail/(float)(srcwin*2*PKT_PER_SEC)),((float)AvgGaplastthis/(float)(srcwin*2*PKT_PER_SEC)),((float)AvgGaptmax/(float)(srcwin*2*PKT_PER_SEC)),((float)AvgGapstretch/(float)(srcwin*2*PKT_PER_SEC)),((float)AvgGaplasttmax/(float)(srcwin*2*PKT_PER_SEC)),(AvgDelta>0 ? (float)(AvgGapavail/AvgDelta) : 0),(AvgDelta>0 ? (float)(AvgGaplastthis/AvgDelta) : 0 ),(AvgDelta>0 ? (float)(AvgGaptmax/AvgDelta) : 0 ), (AvgDelta>0 ? (float)(AvgGapstretch/AvgDelta) : 0), (AvgDelta>0 ? (float)(AvgGaplasttmax/AvgDelta) : 0));
		      fflush(log24);
		     }
	AvgEff = (DEBUG_DropCount > 0 ? 100 - DEBUG_Inefficiency / DEBUG_DropCount : 100);
	float totPALSpkt = 0;
	float lossrate=0;
	 static FILE * fp10=fopen("RPRIMEDifbt.out","w+");
         if(fp10==0) fp10= fopen("RPRIMEDifbt.out","a");
         static FILE * fp11=fopen("RPRIMESWbt.out","w+");
         if(fp11==0) fp11= fopen("RPRIMESWbt.out","a");
                  
	totconbtpkt=DEBUG_TotExt2;         
	for (i = 0; i < Grayindex; i++)
	{	if(GrayList[i].dist<distance)
	          fprintf(fp10,"%d %d %d %f \n",rid_,GrayList[i].nodid,DEBUG_ContDif[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ContDif[i])/(float)Sender_TotPkt[i] : 100));
	        else fprintf(fp10,"%d %d -1 -1 \n",rid_,GrayList[i].nodid);
	        if(GrayList[i].dist>=distance)
                  fprintf(fp11,"%d %d %d %f \n",rid_,GrayList[i].nodid,DEBUG_ContSW[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ContSW[i])/(float)Sender_TotPkt[i] : 100));
                else fprintf(fp11,"%d %d -1 -1 \n",rid_,GrayList[i].nodid);
	        fflush(fp10); fflush(fp11);                                    
		totpkt += Sender_TotPkt[i];
		
		totPALSpkt += (Sender_TotPkt[i] - DEBUG_ExtraPkt[i]);
		AvgExtraPkt += (Sender_TotPkt[i]>0 ? (100 * DEBUG_ExtraPkt[i] / (float)Sender_TotPkt[i]) : 100);
		AvgExtraPkt2+= (Sender_TotPkt[i]>0 ? (100 * DEBUG_ExtraPkt2[i] / (float)Sender_TotPkt[i]) : 100);
		if(Sender_TotPkt[i]!=0) printf("Non-PRIME packets : %.2f %%\n", 100 * DEBUG_ExtraPkt[i] / (float)Sender_TotPkt[i]);
	        if(fp1!=0) {fprintf(fp1,"-1 %d %d %.2f %.2f %d\n",rid_,GrayList[i].nodid,(Sender_TotPkt[i]>0 ? (float)(100 * DEBUG_ExtraPkt[i]) / (float)Sender_TotPkt[i] : 100),(Sender_TotPkt[i]>0 ? (float) (100 * DEBUG_ExtraPkt2[i]) / (float)Sender_TotPkt[i] : 100),DEBUG_ExtraPkt2[i]);
			   }
		if(GrayList[i].nodid==0)  
		    if(fp1!=0) fprintf(fp1,"-2 %f \n",LossRate[i]);
		lossrate+= LossRate[i];		
        }
	if(numaggpkt>0 && log27!=0) fprintf(log27,"%d %.2f \n",rid_,(float)totconbtpkt/(float)numaggpkt);
	fprintf(log23," %.2f %.2f ",(numaggpkt>0) ? ((float)totconbtpkt/(float)numaggpkt) : 0,(numaggpkt>0) ? ((float)DEBUG_ExtraPkt3/(float)numaggpkt) : 0);
	if(Grayindex>0)
	{lossrate /= Grayindex;
    	 AvgExtraPkt /= Grayindex;
	 AvgExtraPkt2 /=Grayindex;
	} 
	for (i = 0; i < MAX_LAYER; i++)
	{
		totlate += DEBUG_Late[i];
	}
	static FILE *fp4 = fopen("RPIMEUnrecLoss.out", "a+");
	if(fp4==0) fp4=fopen("RPRIMEUnrecLoss.out","w+"); 

        static FILE *fp6 = fopen("lossreq.table", "a+");
	if(fp6==0) fp6=fopen("lossreq.table","w+");

	int totloss = 0;
	float UnrecLossPercent, totstream = 0;
	float ActualLoss=0;
	for (i = 0; i < Grayindex; i++)
	{
		totloss += LossCount[i]; 
		ActualLoss+=((EndSeqNo[i]-StSeqNo[i])>0 ? (float)LossCount[i]/(float)(EndSeqNo[i]-StSeqNo[i]) : 0);
		totstream += Sender_TotPkt[i];
		UnrecLossPercent = (Sender_TotPkt[i] > 0) ? 100 * (float)LossCount[i] / (float)Sender_TotPkt[i] : 0;
		if(fp4!=0) {fprintf(fp4, "%d %d %f %d %f %f\n",rid_, GrayList[i].nodid, UnrecLossPercent,Sender_TotPkt[i],DEBUG_ewmabw2[i],DevBW[i]);
		            fflush(fp4);
			    }
	}	
	
	float totdupratio;
	if(totreq>0) totdupratio= (float)totdup / (float)totreq;
	float AvgTime,avgqual=0,avgqual2=0,avgqual1=0;
	if(DEBUG_NumOfChangeSum>0) AvgTime = (MAX_SIM_TIME - 10) / (float)DEBUG_NumOfChangeSum;
	if(log23!=0) fprintf(log23," %.2f %.2f %.2f ",(DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality/(float)DEBUG_tottimestamp : 0),(DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality2/(float)DEBUG_tottimestamp: 0) ,(DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality3/(float)DEBUG_tottimestamp : 0));
	if(DEBUG_totrcvd>0) {avgqual = DEBUG_AvgQuality/(float)(DEBUG_totrcvd);
	avgqual1= DEBUG_AvgQuality2 /(float)(DEBUG_totrcvd);
	avgqual2=DEBUG_AvgQuality3 /(float)(DEBUG_totrcvd);
	}
	float layerdiff=0;
	 if(DEBUG_tottimestamp>0)
		layerdiff = DEBUG_LayerDiff / (float)(DEBUG_tottimestamp);
	
	if(log23!=0) fprintf(log23," %.2f %.2f %.2f ",avgqual,avgqual1,avgqual2);
	if(!startup) {DEBUG_avgpar+=Grayindex*(TIME-DEBUG_prevavg);
	              DEBUG_avgch+=spal[rid_]->requestindex*(TIME-DEBUG_prevavg);
	               DEBUG_prevavg=TIME;
	               DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
	               DEBUG_prevavgdist=TIME;
                      }
                      DEBUG_avgpar2+=Grayindex*(TIME-DEBUG_prevavg2);
                      DEBUG_prevavg2=TIME;
        if(log29!=0) {fprintf(log29, "%d %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %f %.2f %.2f %f %f %d %f %f %f %d %f %d %d %f %f %f %f\n",rid_,TIME,startuptime,tr_start, (numaggpkt>0 ? (float)DEBUG_NumAggPrime/(float)numaggpkt : 0) ,(numaggpkt>0 ? (float)DEBUG_TotExt/(float)numaggpkt: 0 ),DEBUG_avgpar,DEBUG_prevavg,(TIME>startuptime ? DEBUG_avgpar/(TIME-startuptime) : 0), (DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality/(float)DEBUG_tottimestamp : 0),(DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality2/(float)DEBUG_tottimestamp: 0) ,(DEBUG_tottimestamp>0 ? (float)DEBUG_AvgQuality3/(float)DEBUG_tottimestamp : 0),avgqual,avgqual1,avgqual2,DEBUG_avgdist,DEBUG_prevavgdist,DEBUG_avgch,(TIME>startuptime ? DEBUG_avgpar/(TIME-startuptime) : 0),
        DEBUG_lastpar,DEBUG_lastparavg,DEBUG_parch,(DEBUG_parch>0 ? DEBUG_lastparavg/DEBUG_parch : 0),DEBUG_lastdist,DEBUG_lastdistavg,DEBUG_distch,(DEBUG_distch>0 ? DEBUG_lastdistavg/DEBUG_distch : 0),DEBUG_NumAggPkt2, DEBUG_NumAggPrime2,(DEBUG_NumAggPkt2>0 ? ((float)DEBUG_NumAggPrime2/(float)DEBUG_NumAggPkt2) : 0),DEBUG_avgpar2,DEBUG_prevavg2,((float)DEBUG_avgpar2)/(TIME-tr_start));
                      fflush(log29);
                     } 
	if(MAX_SIM_TIME>0) DEBUG_Unrequested = 100 * DEBUG_Unrequested / (float)(PKT_PER_SEC * MAX_SIM_TIME);
	float aggbw1=0,aggbw2=0;
	int avghopdist[n_maxp],avghop[MAX_NODES+1],totprimepkt=0;
	bzero(avghopdist,sizeof(avghopdist));
	float aggdev=0;
	int totrep=0;
	float replossrate=0;
	float aggbwdiff=0,aggbwsw=0;
	bzero(avghop,sizeof(avghop));
	for (j = 0; j < Grayindex; j++){
		totprimepkt +=DEBUG_NumPRIMEPktRcvd[j];
		aggbw1+=DEBUG_ewmabw2[j];
		aggbw2+=DEBUG_ewmaconbtbw[j];
		aggdev+=DevBW[j];
		if(GrayList[j].dist<distance) aggbwdiff+=DEBUG_ewmabw2[j];
		                else aggbwsw+=DEBUG_ewmabw2[j];
		                
		for(i=0;i<MAX_NODES+1;i++)
		  {if(DEBUG_hopdist[j][i]>0) {
		                       avghopdist[j]+=(DEBUG_hopdist[j][i]*i);
				       avghop[i]+=DEBUG_hopdist[j][i];
				      }
		  }
		if (DEBUG_NumPRIMEPktRcvd[j]>0 && log22!=0) {fprintf(log22,"%.2f %d\n",(float)(avghopdist[j])/(float)(DEBUG_NumPRIMEPktRcvd[j]),DEBUG_NumPRIMEPktRcvd[j]);
							fflush(log22);}
		else if(log22!=0) {fprintf(log22,"0 \n"); fflush(log22);}
		avghopdist[j]=0;
                if(repnum[j]>0) 
                {  totrep+=repnum[j];
                   replossrate+=(float)DEBUG_reporloss[j]/(float)repnum[j];
                } 
	}
	fprintf(log2,"%f %f \n",aggbwdiff,aggbwsw);
	float controltraffic = ((totprimepkt+totconbtpkt)>0 ? 100 * (4.5 *(float)(DEBUG_TotalPktRequested-DEBUG_neg2pkt)) / (float)((totprimepkt+totconbtpkt) * 1000) : 0);
	 if(fp6!=0) {fprintf(fp6, "%d %f %d %d %f %.2f %.2f %d %d %d %d %.2f \t%d %d %d \t%d %d %d %.2f %.2f %f\n",rid_,lossrate,DEBUG_Nloss,DEBUG_LossC2,(Grayindex>0 ? ActualLoss/(float)Grayindex : 0),ActualLoss,(DEBUG_NumAggPkt>0 ? (float)totloss/(float)DEBUG_NumAggPkt : 0),totloss,totlate,totdup,totreq,controltraffic,DEBUG_TotalPktRequested,totprimepkt,totconbtpkt,DEBUG_reportloss,totrep,DEBUG_recloss,(totrep>0 ? (float)DEBUG_reportloss/(float)totrep : 0),(totrep>0 ? (float)DEBUG_recloss/(float)totrep : 0),(Grayindex>0 ? replossrate/(float)Grayindex : 0));fflush(fp6);} 

	if(log23!=0) {fprintf(log23," %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f\n",aggbw1,aggbw2,aggdev,AvgExtraPkt,AvgExtraPkt2,(DEBUG_avgcount>0? DEBUG_normplay/(float)DEBUG_avgcount : 0),(DEBUG_avgcount>0 ? DEBUG_normbuf/(float)DEBUG_avgcount : 0), (DEBUG_avgcount>0 ? DEBUG_normnew/(float)DEBUG_avgcount : 0),(DEBUG_avgcount>0 ? DEBUG_normpa/(float)DEBUG_avgcount : 0),(DEBUG_avgcount>0 ? DEBUG_normqual/(float)DEBUG_avgcount : 0)); fflush(log23);}
	if(log22!=0) fprintf(log22,"%d %d \t",rid_, totprimepkt);
	static FILE *log30=fopen("RPRIMEHop3.out","a+");
	
        if(log30==0) log30=fopen("RPRIMEHop3.out","w+");
        if(log30!=0) fprintf(log30,"%d ",rid_);
	  for (j = 0; j < MAX_NODES+1; j++)
		if(avghop[j]>0 && log22!=0)  {fprintf(log22," %f %d %d \t",(totprimepkt>0 ? (float)(avghop[j])/(float)(totprimepkt) : 0),avghop[j],j);
								fflush(log22);
				              }				
		if(log22!=0) {fprintf(log22,"\n");	fflush(log22);}

	for(j=0; j < 22;j++)
  		if(log30!=0) fprintf(log30,"%d %f ",avghop[j],(totprimepkt>0 ? (float)(avghop[j])/(float)(totprimepkt) : 0));

	if(log30!=0) fprintf(log30,"\n");


	if(log21!=0)  {fprintf(log21,"%d %.2f %.2f %.2f %.2f %.2f %.2f \n",rid_,aggbw1,aggbw2,AvgExtraPkt,AvgExtraPkt2,(DEBUG_avgcount>0 ? (float)DEBUG_TotAvail/(float)DEBUG_avgcount : 0),(DEBUG_avgcount>0 ? (float)DEBUG_TotAvailExt/(float)DEBUG_avgcount : 0));
			fflush(log21);}
	if(fp3!=0) {fprintf(fp3, "%d %.2f %d %d %d \t%f %.2f %.2f %.2f %.2f %d %.2f %.2f %.2f %2f %d %f %f %d %d %d\n",rid_,WIN_SIZE,srcwin,n_maxp,n_minp, 
			layerdiff,(DEBUG_tottimestamp>0 ? (float)DEBUG_DropCount/(float)DEBUG_tottimestamp : 0),(DEBUG_tottimestamp>0 ? (DEBUG_AvgQuality-DEBUG_AvgQuality2)/(float)DEBUG_tottimestamp : 0),((DEBUG_Excessevent>0) ? (float)DEBUG_Excesspkt/(float)DEBUG_Excessevent : 0),(DEBUG_tottimestamp>0 ? (float)DEBUG_Excessevent/(float)DEBUG_tottimestamp : 0),DEBUG_DropCount,totdupratio,controltraffic,(Grayindex>0 ? ActualLoss/(float)Grayindex : 0) ,((DEBUG_totrcvd>0) ? (float)totlate/(float)DEBUG_totrcvd:0),DEBUG_laterequests,
			(DEBUG_avgcount>0 ? DEBUG_normnewbw/(float)DEBUG_avgcount : 0),(DEBUG_avgcount>0 ? DEBUG_normbufbw/(float)DEBUG_avgcount : 0),DEBUG_upper,DEBUG_down,DEBUG_totalpkt);
		   fflush(fp3);}
}

/*
This stops the peer and call the dumping function, DumpSimData().
*/  
void RPALApp::stop()
{	printf("call stop in %d at %f %d %d\n",rid_,TIME,Grayindex,activeindex);
        prestop=1;
	int i=0,j;
	firstst=0;
	assert(stopped_==0);
	if(stopped_==1) return;
	if(rid_!=0) DumpSimData();
	if(rid_!=0)
	{	if(TIME<360)
	 	{for (i = 0; i < Grayindex; i++)
		  {
		   int pre=Grayindex;
		   sendudpRequest(-1,GrayList[i].nodid,0,0);
		   if(Grayindex==pre) 
		     removefromlist(GrayList[i].nodid);
		   if(Grayindex==0) break;
		   else i=-1;
		  }
		  for (i = 0; i < activeindex;i++)
		  {
		   sendudpRequest(-1,(int)recrapconnection[i][0],0,0);
		  } 
		 SendTobootstrap(-1,0);
		}
		else {
		      for (i = 0; i < Grayindex; i++)
		      { int sender=GrayList[i].nodid;
		        int reqind=spal[sender]->requestindex;
		        if(reqind<n_maxp)
		        {for(j=0;j<reqind;j++)
		         {int listid=spal[sender]->reclist[j].listid;
		          if(spal[sender]->reclist[j].id==rid_ && spal[sender]->first[listid])
		          {printf("rap agent here stopped %d sender %d\n",rid_,sender);
                           rname[spal[sender]->reclist[j].rapport]->stop();
                           spal[sender]->first[listid]=0;
                           break;
                          }
                         }
                        }
                      }
                     }       
		spal[rid_]->stop();
	}
        if(rid_==0)
        {spal[0]->stop();
         for(i=1;i<MAX_NODES;i++)
          {if(rprime[i]->stopped_==0)
            rprime[i]->stop();
          }
         }   
                                
                          
	        
	Grayindex=0;
	stopped_ = 1;
}

/*
This is used in ns only for attaching applications to transport layer and so on.
*/
int RPALApp::command(int argc, const char*const* argv)
{
        Tcl& tcl = Tcl::instance();
	int id,i;
        if (argc == 2) {
                if (strcmp(argv[1], "start") == 0) {
                        start();
                        return (TCL_OK);
                }
                if (strcmp(argv[1], "stop") == 0) {
                        stop();
                        return (TCL_OK);
                }
        }
        else if (argc == 3 && rid_!=0) {
                if (strcmp(argv[1], "attach-udp-agent") == 0) {
                        sudp_ = (UdpAgent*) TclObject::lookup(argv[2]);
                        rprime[rid_] = this;
		        if (sudp_ == 0) {
                                tcl.resultf("no such agent %s", argv[2]);
                                return(TCL_ERROR);
                        }
                        sudp_->attachApp(this);
                        udname[rid_]->attachApp(this);
                        for (i=0; i<n_max; i++)
                           {assert((rid_*2*n_max+n_max+i)<(MAX_NODES+2)*2*n_max);
                            rname[rid_*2*n_max+n_max+i]->attachApp(this);}

			return(TCL_OK);
                }
        }
	else if (argc == 4) {
		if (rid_ == 0 && strcmp(argv[1], "attach-udp-agent") == 0) {
			id = atoi(argv[3]);
			assert(id<=MAX_NODES);
                        rudp_[id] = (UdpAgent*) TclObject::lookup(argv[2]);
                        rprime[rid_] = this;
                        if (rudp_[id] == 0) {
                                tcl.resultf("no such agent %s", argv[2]);
                                return(TCL_ERROR);
                        }
		        rudp_[id]->attachApp(this);
                        return(TCL_OK);
                }
        }

        return (Application::command(argc, argv));
}

buffer **  RPALApp::readbuf()
{
	buffer **bufpoint;
	bufpoint=buf;
	return bufpoint;
}

int RPALApp::readhop(int timestamp,int layer)
{	if(layer<0 && timestamp<0) return 0;
	assert (timestamp<playtime+MAX_BUFFER);
	int var;
	
	if(timestamp>playtime)
	{ var=timestamp % MAX_BUFFER;
	  if(startup==0 && TIME>(startuptime+20)) assert(buf[layer][var].flag>0);
	  return buf[layer][var].hopcount;
	}
	else if(timestamp>=playtime-2*PKT_PER_SEC)
	  return 20; 
	else return 0;
}

int RPALApp::readtp()
{ if(startup) return -2000;
  return playtime;
}

int RPALApp::readtp2()
{ if(!startup) return -2000;
  return playtime2;
}

int RPALApp::readtbuf()
{ int i,max=0; 
	for(i=0;i<MAX_LAYER;i++)
 	  if(max<BufEndIndex[i])	max=BufEndIndex[i];
return max;
}

int RPALApp::readts()
{
  return bufferlength;
}

int * RPALApp::readlast() {
 return BufEndIndex;
}

/* This checks the ttls for expiration in bootstrap node
This is used for ungraceful departure of peers
*/
void RPALApp::checkttl()
{
	int i;
	for(i=1;i<nodeindex;i++)
		if((TIME - nodepool[i].ttl) > ExpTh) {	
			nodepool[i]=nodepool[--nodeindex];			
			nodeidpool[i]=nodeidpool[nodeindex];
		}
}

/*
This functions is used in bootstrap node to randomly assign parents to peers.
*/
void RPALApp::assignparent(int nodeid,int num)
{	frombootmessage_= new RPRIMESigMSG;
	int temp=0,i,parentindex=0,found=0;
	frombootmessage_->emptrap=-1;
	frombootmessage_->rprime_id_=0;
	frombootmessage_->request_flag_=0;
	frombootmessage_->curbitmap=NULL;
        frombootmessage_->list_=NULL;
         frombootmessage_->extlen=0;
         frombootmessage_->reglen=0;
         frombootmessage_->sprime_id_=0;
        frombootmessage_->request_list_=NULL;
	int j,assignnum=0;
	PktListBoot * parentlist;
	if(num>0) parentlist = (PktListBoot*) malloc(num * sizeof(PktListBoot));
	
	bzero(parentlist,sizeof(PktListBoot)*num);
	int overflag=0;
	if (nodeid<=20) overflag=1;
	while(parentindex<num)
	{	found=0;
	        temp=0;
		if (nodeindex!=0 && nodeindex>(num+1)) {
		                                        temp= rand() % (nodeindex+8);
                                                        if(temp>=nodeindex) temp=0; 
		                                       }
		else if(nodeindex>1){ 
			for(i=0;i<nodeindex;i++)
				if(nodeid!=nodeidpool[i]) {
					for(j=0;j<nodeindex;j++)
		                                if(nodepool[j].nodid==nodeidpool[i]) parentlist[parentindex].uptime=nodepool[j].uptime;
					parentlist[parentindex++].parent_id=nodeidpool[i];
					
					assignnum++;
				}
			
			break; 
		}
		for(i=0;i<parentindex;i++)
		{ 	if(nodeid == nodeidpool[temp] || parentlist[i].parent_id==nodeidpool[temp]) {found=1; break;} 
			else continue;
		}
		if (found==0 && nodeid!=nodeidpool[temp]) 
		{	for(j=0;j<nodeindex;j++) 
			  {if(nodepool[j].nodid==nodeidpool[temp]) parentlist[parentindex].uptime=nodepool[j].uptime;}
			assert(temp<MAX_NODES);
			parentlist[parentindex++].parent_id=nodeidpool[temp];
			assignnum++;

			assert(parentindex<=num);
		}
	}
	for(i=0;i<assignnum;i++)
	{if(parentlist[i].parent_id==0)	
		{	parentlist[i].parent_id=parentlist[0].parent_id;
			parentlist[i].uptime=parentlist[0].uptime;
			parentlist[0].parent_id=0;
			parentlist[0].uptime=nodepool[0].uptime;
			break;
		}
	}
	frombootmessage_->length=assignnum; 
	frombootmessage_->list_= parentlist;
	frombootmessage_->rprime_id_=rid_;
	int nbytes=frombootmessage_->size();
	assert(nodeid<MAX_NODES);
	rudp_[nodeid]->sendmsg(nbytes, frombootmessage_, 0);		
	lastsendparent[nodeid]=-1;	
}

/*This function is called when bootstrap node receive a udp message from peers. 
message-> req_flag_ shows the type of requests of peers: 0 is join
1 is hearbeat 
-1 is leave
*/
void RPALApp::process_udpboot_data(int size, AppData* data) 
{	
	RPRIMEMSGBoot* message = (RPRIMEMSGBoot*) data;
	int reqflag,i,nodeid,numparents,found=0;
	nodeid= message-> rec_id_;
	reqflag= message-> req_flag_;
	numparents= message-> num_;
	checkttl(); 
	if (reqflag == 0)
	{ for (i=0; i < nodeindex ; i++)
		if (nodepool[i].nodid == nodeid) {found=1; nodepool[i].ttl= TIME; printf("node %d \n",nodeid); break;} 
	  if (found ==0 ) 
	  {
	    nodepool[nodeindex].nodid = nodeid;
	    nodepool[nodeindex].bufsize=numparents;
	    nodepool[nodeindex].uptime = TIME;
	    nodepool[nodeindex].ttl= TIME;
            nodeidpool[nodeindex]=nodeid;
	    nodeindex++;
	  }
	   if(firstboot) 
	     assignparent(nodeid,numparents);
	   found=0;
	}
	else if(reqflag==1) 
	{ found=0;
	  for (i=0; i < nodeindex ; i++)
                if (nodepool[i].nodid == nodeid) {found=1; nodepool[i].ttl= TIME; break;}
	  if(found==0)
	  {
            nodepool[nodeindex].nodid = nodeid;
            nodepool[nodeindex].uptime = TIME;
            nodepool[nodeindex].ttl= TIME;
            nodeidpool[nodeindex]=nodeid;
            nodeindex++;
            if(firstboot && numparents!=0)
            assignparent(nodeid,numparents);
	  }		
	}
	else if(reqflag==-1) 
	{  for (i=0; i < nodeindex ; i++)
                if (nodepool[i].nodid == nodeid) 
		{	
			nodepool[i].nodid=nodepool[--nodeindex].nodid;
			nodepool[i].uptime=nodepool[nodeindex].uptime;
			nodepool[i].bufsize=nodepool[nodeindex].bufsize;
			nodepool[i].ttl=nodepool[nodeindex].ttl;
                        nodeidpool[i]=nodeidpool[nodeindex];
		}
		return;
	}
	if(!firstboot && numparents!=0)
           { if(nodeindex>=(int)((float)MAX_NODES/(float)2))
                { pendindex=2;                  
                  assignparent(nodeidpool[1],nodepool[1].bufsize);
                  firstboot=1;
		  PendingReq();
                }
           }

	assert(reqflag==0 || reqflag==1 || reqflag==-1);
}	

/*
This function is called when a udp message is received. rid_==0 is bootstrap which calls process_udpboot_data.
If the message->rprime_id_==0, the message is from bootstrap and then checkneigh will be called
Otherwise, the packet is from other peers (signalling message) and process_sigmsg_data will be called
*/
void RPALApp::process_udp_data(int size, AppData* data)
{  	  if(stopped_) return;
 	if (rid_ == 0) {
                process_udpboot_data(size , data);
                return;
        }
 	else { 
	 RPRIMESigMSG* message = (RPRIMESigMSG *) data;
	 if(message->rprime_id_==0) 
	 {PktListBoot *neighlist = message->list_;
	  int num = message->length;
	  assert(rid_<MAX_NODES);
	  checkneigh(neighlist,num);		  
	 }
	 else process_sigmsg_data(size,data); 
	}	
}

/*Upon receiving a udp message from other peers, check the message->request_flag_. If it is -1, it is a request denied message.
Receiving 1 is an accept message by a parent. Receiving 0 means a connection request from a child, so we call spal[rid_]->process_udp_data which is the sender side of this peer 
to act accordingly.
*/
void RPALApp::process_sigmsg_data( int size,AppData* data)
{	RPRIMESigMSG* message = (RPRIMESigMSG *) data;
	int request=message->request_flag_;
	int sender=0; sender=message->sprime_id_;
	int k=0,i=0,found=0;
	
    	assert(rid_<MAX_NODES);  
	if (request==-1)
	{ 

           removefromlist(sender);	
	 
   	  printf("previous request was denied by %d %f %d process data \n",sender,TIME,rid_);
	}
	else if(request==1) 
	 { 
	   for(i=0;i<Grayindex;i++)
	    {
		if(GrayList[i].nodid==sender) {found=1; break;} 
	    }	
	   for(k=0;k<activeindex;k++)
             { if(recrapconnection[k][0]==(float)sender)
                {recrapconnection[k][2]=TIME; break;}
             }

	   if(found==0 && message->emptrap !=-1 && Grayindex<n_maxp) 
	   {
	    if(TIME<6000)	
		{
		 if(findrap(sender)==-1) return;
		    i=Grayindex; 
		    if(!startup) {DEBUG_avgpar+=Grayindex*(TIME-DEBUG_prevavg);
		                  DEBUG_avgch+=spal[rid_]->requestindex*(TIME-DEBUG_prevavg);
		                  DEBUG_prevavg=TIME;
		                 } 
		                 DEBUG_avgpar2+=Grayindex*(TIME-DEBUG_prevavg2);
                                 DEBUG_prevavg2=TIME;
		    GrayList[Grayindex++].nodid=sender; 
		    DueNumPkt[i]=0; sending_time[i]=0; Ack[i]=0;
		    printf("in rid %d addnode %d %d %d length %d\n",rid_,sender,i,Grayindex,message->length);
		    int ndistance=distance;
		    if(sender==0) {srcflag=Grayindex-1; 
		                   if(!startup) {DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
                                                 DEBUG_prevavgdist=TIME;}
                                   ndistance=1;}
		    GrayList[i].dist=message->dist;

		    if(ndistance>(GrayList[i].dist+1)) { if(!startup) {DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
      		                                                      DEBUG_prevavgdist=TIME;}
		                                        ndistance=GrayList[i].dist+1;
		                                      }  
		    if(distance!=ndistance) {  assert(DEBUG_lastdist<=TIME);
                                               DEBUG_lastdistavg+=(TIME-DEBUG_lastdist);
                                               DEBUG_lastdist=TIME;
                                               DEBUG_distch++;
                                               distance_t=TIME;
                                               distance=ndistance;
		                              }                                  
		    GrayList[i].dist2=message->dist2;
		    extractcontent(message->length,message->curbitmap,sender,i,message->tb,message->tp,message->tp2,message->repid,message->repbk);
		}
	   }
		
	   if(found==1 && message->emptrap != -1) {GrayList[i].dist=message->dist;
	                                           GrayList[i].dist2=message->dist2;
                                                   extractcontent(message->length,message->curbitmap,sender,i,message->tb,message->tp,message->tp2,message->repid,message->repbk);
                                                  }
	 }
	else if(request==0) 
        { 
	 found=0;

	 for(i=0;i<Grayindex;i++)
	 { if(GrayList[i].nodid==sender) {found=1; break;}
	 }
	     if(sender!=0) spal[rid_]->process_udp_data(message->size(),message);
	}
}

/*
This function extract the bitmap or report of parents.
Length is the number of packets in this bitmap. 
sid is the parent id
i is the index of parent (sid) in GrayList
tbuf is the last available timestamp in the parent
tplay is the playtime of the parent
tplay2 is the second (fake) playtime of the parent
repid is the id of this report to detect loss in reports
repbk is a portion of bitmap which is reported the second time. Each peer as parent report its new packets two times to decrease the probability of loss
*/
void RPALApp::extractcontent(int length,PktList* bitmap,int sid,int i,int tbuf,int tplay,int tplay2,int repid,int repbk)
{
	int j=0;
	assert(i<Grayindex);
        GrayList[i].tbuf=tbuf;
        GrayList[i].tplay=tplay;
        GrayList[i].tplay2=tplay2;
        if(sid==0) 
          {if(tbuf>MaxTab) MaxTab=tbuf;         
           GrayList[i].bufsize=length;
           return;
          } 
        if(length<=0) 
        { if(repid>repnum[i] && repnum[i]!=-1) {repnum[i]=repid; }
            return;  
        }    
        int lossflag=0;
        if(repid > repnum[i]+2) {DEBUG_reportloss+=(repid-repnum[i]-2);
                                 DEBUG_reporloss[i]+=(repid-repnum[i]-2);
                                 lossflag=1;}
        else if(repid > repnum[i]+1) {DEBUG_recloss++;
                                      lossflag=1;
                                      }
        if (repid<=repnum[i] && repid!=0) {
                                           return;
                                          }    
        if(length>0) {if(lossflag==1) GrayList[i].bufsize+=length;
                                 else GrayList[i].bufsize+=(length-repbk);
                                } 
        repnum[i]=repid;
        assert(GrayList[i].bufsize>0);
        int startbuf=0;
        if(lossflag==1) startbuf=0;
        else startbuf=repbk;
        for(j=startbuf;j<length;j++)
         {int timesbuf= bitmap[j].timestamp % MAX_BUFFER;
          if(bitmap[j].timestamp>MaxTab) MaxTab=bitmap[j].timestamp;
          if(startpoint!=-1)   
            assert(MaxTab<playtime+MAX_BUFFER);
          if(bitmap[j].timestamp<playtime) {
                                            if((j+1)<length)
                                              continue;
                                            else break;  
                                           }
          if(bitmap[j].timestamp<startpoint && startup)
                                          {
                                          if((j+1)<length)
                                           continue;
                                          else break; 
                                          }                                  
          if(startpoint!=-1)                                
           assert(bitmap[j].timestamp<playtime+MAX_BUFFER);
           assert(bitmap[j].layer_id>=0 && bitmap[j].layer_id<MAX_LAYER);
                                             
	   if(buf[bitmap[j].layer_id][timesbuf].flag>0)   {table2[bitmap[j].layer_id][timesbuf]++; table[bitmap[j].layer_id][timesbuf].flag=-3; continue;}
	   int m;
	   assert(table2[bitmap[j].layer_id][timesbuf]<n_maxp);  
	   table[bitmap[j].layer_id][timesbuf].Listid[table[bitmap[j].layer_id][timesbuf].flag]=sid;
	   table[bitmap[j].layer_id][timesbuf].Listind[table[bitmap[j].layer_id][timesbuf].flag]=i;
	   if(table[bitmap[j].layer_id][timesbuf].flag==0)
	     tabqual[timesbuf]++;
	   assert(table[bitmap[j].layer_id][timesbuf].flag>=0); 
	   table[bitmap[j].layer_id][timesbuf].flag++;
	   assert(table[bitmap[j].layer_id][timesbuf].flag<=n_maxp);
 	 }  
 	 if(MaxTab<playtime)       MaxTab=playtime;
 	 if(!startup && MaxTab<playtime+(int)(MWM * PKT_PER_SEC)) MaxTab=playtime+(int)(MWM * PKT_PER_SEC);
}

/*
This function is called when a parent (sender) denies a request or departs
We should clean all of the reported packets by this parent from table[][]
*/
void RPALApp::removefromlist(int sender)
{	printf("TIME: %f sender %d removed %d \n",TIME,sender,rid_);
	int i=0,length;

	for(i=0;i<activeindex;i++)
	{if(recrapconnection[i][0]==(float)sender)
		{recrapconnection[i][0]=recrapconnection[--activeindex][0];
		 recrapconnection[i][1]=recrapconnection[activeindex][1];
  		 recrapconnection[i][2]=recrapconnection[activeindex][2];
		 recrapconnection[activeindex][0]=0;
		 recrapconnection[activeindex][1]=0;
		 recrapconnection[activeindex][2]=0;
		}
	}
	 static FILE * fp1=fopen("RPRIMERemove.out","w+");
	 if(fp1==0) fp1=fopen("RPRIMERemove.out","a+");
	 
	if(TIME<6000)
	{for(i=0;i<Grayindex;i++)
	  if(GrayList[i].nodid==sender) 
	  {    
                fprintf(fp1,"%f %f %f %d %d %d %d		%d %.2f %d %.2f 	%d %.2f %d %.2f \n",TIME,tr_down,tr_start,rid_,GrayList[i].nodid,distance,GrayList[i].dist,DEBUG_ContDif[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ContDif[i])/(float)Sender_TotPkt[i] : 100),DEBUG_ContSW[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ContSW[i])/(float)Sender_TotPkt[i] : 100), DEBUG_ExtraPkt[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ExtraPkt[i])/(float)Sender_TotPkt[i] :100),DEBUG_ExtraPkt2[i],(Sender_TotPkt[i]>0 ? (float)(100* DEBUG_ExtraPkt2[i])/(float)Sender_TotPkt[i] : 100));
                fflush(fp1);
                int lastts=GrayList[i].tbuf;
                if(!prestop)
                {assert(DEBUG_lastpar<=TIME);
                 DEBUG_lastparavg+=(TIME-DEBUG_lastpar);
                 DEBUG_lastpar=TIME;
                 DEBUG_parch++;
                } 
	        if(!startup) {DEBUG_avgpar+=Grayindex*(TIME-DEBUG_prevavg);
	                      DEBUG_avgch+=spal[rid_]->requestindex*(TIME-DEBUG_prevavg);
	                      DEBUG_prevavg=TIME;
	                     } 
	        if(!prestop) {DEBUG_avgpar2+=Grayindex*(TIME-DEBUG_prevavg2);
                              DEBUG_prevavg2=TIME;}             
		length=GrayList[--Grayindex].bufsize;
		if(firstduealoc[i]==1) bzero(DuePkt[i],DueSize[i]*sizeof(PktList));		
		DueNumPkt[i]=0;
		Ack[i]=0;
		Ack[Grayindex]=0;
		sending_time[i]=sending_time[Grayindex];
		seqnum[i]=seqnum[Grayindex];
		repnum[i]=repnum[Grayindex];
		Sender_TotPkt[i]=Sender_TotPkt[Grayindex];
		DEBUG_ExtraPkt[i]=DEBUG_ExtraPkt[Grayindex];
		DEBUG_ExtraPkt2[i]=DEBUG_ExtraPkt2[Grayindex];
		DEBUG_ContDif[i]=DEBUG_ContDif[Grayindex];
		DEBUG_ContSW[i]=DEBUG_ContSW[Grayindex];
		DEBUG_reporloss[i]=DEBUG_reporloss[Grayindex];
		GrayList[i]=GrayList[Grayindex];
		EndSeqNo[i]=EndSeqNo[Grayindex];
		NumPktRcvd[i]=NumPktRcvd[Grayindex];
		Sender_TotPkt[Grayindex]=0;
		DEBUG_ContSW[Grayindex]=0;
		DEBUG_ContDif[Grayindex]=0;
		DEBUG_ExtraPkt2[Grayindex]=0;
		DEBUG_ExtraPkt[Grayindex]=0;
		NumPktRcvd[Grayindex]=0;
		NumUseful[i]=NumUseful[Grayindex];
		NumUseful[Grayindex]=0;
		LastBWCalc[i]=LastBWCalc[Grayindex];
		LastBWCalc[Grayindex]=0;
		sending_time[Grayindex]=0;
		DueNumPkt[Grayindex]=0;
		repnum[Grayindex]=-1;
		DEBUG_reporloss[Grayindex]=0;
  		seqnum[Grayindex]=0;
  		GrayList[Grayindex].bufsize=0;
  		EndSeqNo[Grayindex]=0; 
  		ewmabw[i]=ewmabw[Grayindex];
  		ewmausebw[i]=ewmausebw[Grayindex];
  		DEBUG_ewmabw2[i]=DEBUG_ewmabw2[Grayindex];
  		DevBW[i]=DevBW[Grayindex];
  		DevUseBW[i]=DevUseBW[Grayindex];
  		ewmabw[Grayindex]=0;
  		DEBUG_ewmabw2[Grayindex]=0;
  		ewmausebw[Grayindex]=0;
  		DevBW[Grayindex]=0;
  		DevUseBW[Grayindex]=0;
  		int k=0,l=0,m=0;
  		int cou=0, stts=0;
  		assert(playtime>=0);
  		if(lastts<MaxTab) lastts=MaxTab;
  		if(lastts<GrayList[Grayindex].tbuf) lastts=GrayList[Grayindex].tbuf;
                if(prestop) return;
                stts=playtime;
                if(startup) stts=(lastts-(MAX_BUFFER+1))> 0 ? (lastts-(MAX_BUFFER+1)) : 0;
  		for(k=stts;k<=lastts;k++)
  		  {if(tabqual[k%MAX_BUFFER]>0)                 
  		    {
  		     for(l=0;l<MAX_LAYER;l++)
  		     {cou=0;
  		      if(table[l][k%MAX_BUFFER].flag>0)
  		      {for(m=0;m<table[l][k%MAX_BUFFER].flag;m++)
  		       {if(table[l][k%MAX_BUFFER].Listid[m]==GrayList[Grayindex].nodid && GrayList[Grayindex].nodid!=0)
  		         {
  		          table[l][k%MAX_BUFFER].Listind[m]=i;
  		          table[l][k%MAX_BUFFER].Listid[m]=GrayList[Grayindex].nodid;
  		         } 
  		        if(table[l][k%MAX_BUFFER].Listid[m]==sender)
  		         {table[l][k%MAX_BUFFER].Listid[m]=-1;
  		          table[l][k%MAX_BUFFER].Listind[m]=0;
  		          int temp=table[l][k%MAX_BUFFER].flag;
  		          assert(temp>=0);
  		          if(temp>1)
                          {temp--;
                           table[l][k%MAX_BUFFER].Listid[m]=table[l][k%MAX_BUFFER].Listid[temp];
                           if(table[l][k%MAX_BUFFER].Listid[temp]==GrayList[Grayindex].nodid)
                             table[l][k%MAX_BUFFER].Listind[m]=i;
                           else 
                             table[l][k%MAX_BUFFER].Listind[m]=table[l][k%MAX_BUFFER].Listind[temp];  
                           
                           table[l][k%MAX_BUFFER].Listid[temp]=-1;
                           table[l][k%MAX_BUFFER].Listind[temp]=0;
                           assert(Grayindex==0 || table[l][k%MAX_BUFFER].Listind[m]<Grayindex);
                          } 
  		           cou++; 
  		         }
  		         assert(Grayindex==0 || table[l][k%MAX_BUFFER].Listind[m]<Grayindex);
  		        }
                      }
                      assert(cou<=1);
                      if(cou>0)
                      {table[l][k%MAX_BUFFER].flag--;
                       if(table[l][k%MAX_BUFFER].flag==0)
                        tabqual[k%MAX_BUFFER]--;
                       assert(table[l][k%MAX_BUFFER].flag>=0 && tabqual[k%MAX_BUFFER]>=0);
                      } 
                     }
                    
                    }
                  }       		          
		printf("in %d remove %d %d %d %d %d\n",rid_,sender,Grayindex,i,MaxTab,tabqual[MaxTab%MAX_BUFFER]);
	  }	
	}
	
	int count=0;
	int fflag=0;
	OldMaxTab=MaxTab>OldMaxTab ? MaxTab : OldMaxTab;
	MaxTab=0;
	int ndistance=distance;
        ndistance=9;
	for(i=0;i<Grayindex;i++)
		{
		 if(seqnum[i]==0) count++;
		 if(MaxTab<GrayList[i].tbuf) MaxTab=GrayList[i].tbuf;
		 if(GrayList[i].nodid==0)
                  {srcflag=i; 
                   ndistance=1;
                  }
                 if(ndistance>(GrayList[i].dist+1))  
                  ndistance=GrayList[i].dist+1;
		}
	if(ndistance==20) {assert(Grayindex==0); ndistance=9;} 
	assert(startup || ndistance<10);
      	if(!startup) {DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
                      DEBUG_prevavgdist=TIME;
                     }
        if(ndistance!=distance) {  assert(DEBUG_lastdist<=TIME);
                                   DEBUG_lastdistavg+=(TIME-DEBUG_lastdist);
                                   DEBUG_lastdist=TIME;
                                   DEBUG_distch++;
                                   distance_t=TIME;
                                   distance=ndistance;
                                  }             
		
	if(count==Grayindex && startup) {firstfill=1; firstrequest=1;}
	if(sender==0) srcflag=-1;
	return;
}

/* This function check the list of possible parents sent by bootstrap (nlist). If any is existed in the GrayList it will be removed from the list
and EstablishUdp will be called for the rest
*/
void RPALApp::checkneigh(PktListBoot * nlist,int num)
{ 	int i=0,j=0,found=0;
        assert(num<=n_maxp);
	udpindex=0;
	udpindex2=0;
	bzero(UdpList,sizeof(PktListBoot) * n_maxp);
	for(i=0;i<num;i++)
	{for (j=0; j<Grayindex; j++)
	  	if(nlist[i].parent_id == GrayList[j].nodid) {found =1; break;} 
         assert(udpindex<n_maxp);
	 if(found == 0) 
	  UdpList[udpindex++]=nlist[i];	 
	 found=0;
	}
	if(udpindex==0)
		{
		 SendTobootstrap(0,n_maxp);
		}
	if((TIME-lasttry)>TryEstab || lasttry==0)
		EstablishUdp();
}

/*
In this function, child peer sends connection request to the list of potential parents from UdpList. 
*/
void RPALApp::EstablishUdp() 
{	
	int i=0,tempid;
	int diff=0;
	if(udpindex==-1) {udpindex=udpindex2; lasttimeboot=0; return;}
	if(Grayindex<targetneigh)
	{diff=targetneigh-Grayindex;
	 if(diff>=(udpindex-udpindex2))
	 {for(i=udpindex2;i<udpindex;i++)
	  {   tempid=UdpList[i].parent_id;
	      assert(tempid<MAX_NODES);
    	      udname[rid_]->connect((ns_addr_t)srudp[tempid]->faddr()); 
		if(findrap(tempid)!=-1)
	         sendudpRequest(0,tempid,0,0); 
    
	  }
 	 udpindex2=udpindex;
	 lasttimeboot=0;
	 }
	 else {assert((diff+udpindex2)<=n_maxp);
	  for(i=udpindex2;i<(diff+udpindex2);i++)
          {   
                tempid=UdpList[i].parent_id;
                assert(tempid<MAX_NODES);
              udname[rid_]->connect((ns_addr_t)srudp[tempid]->faddr()); 
            if(findrap(tempid)!=-1)
		sendudpRequest(0,tempid,0,0); 
	   
	  }
	 udpindex2=diff+udpindex2;
	 }
	lasttry=TIME;
	}
}

/* Either a connection request or a departure message will be sent through this function
*/	 
void RPALApp::sendudpRequest(int flag,int sid,PktList* list,int length)
{ int i;
  PktList * temp;
  signalingmessage_ = new RPRIMESigMSG;
  signalingmessage_->request_flag_=flag;
  signalingmessage_->emptrap=-1;
  signalingmessage_->rprime_id_=rid_;
  signalingmessage_->sprime_id_=rid_;
  signalingmessage_->curbitmap=NULL;
  signalingmessage_->list_=NULL;
  signalingmessage_->extlen=0;
  signalingmessage_->reglen=0;
  signalingmessage_->request_list_=NULL;
  signalingmessage_->length=0;
  int nbytes=signalingmessage_->size();
    
  assert(sid<MAX_NODES);
  if(flag==1 || sid==0) udname[rid_]->connect((ns_addr_t)srudp[sid]->faddr());
  else  {signalingmessage_->sprime_id_=rid_;
	 signalingmessage_->rprime_id_=rid_;
	 udname[rid_]->connect((ns_addr_t)srudp[sid]->faddr());
 	}
   udname[rid_]->send(nbytes,signalingmessage_);
  
}

// in this function receiver wants to find an idle rap connection to report it to the sender 
// it will wait for a threshhold of RapExp to expire an idle connection , the one that waiting for the 
// first message and is not in GrayList yet
//   

int RPALApp::findrap(int id)
{ int found=0,i=0,j=0,flag=1;
  for (i=0;i<activeindex;i++)
         if ((float)id == recrapconnection[i][0]) {found=1; break;} 
  if(found==1) return (int)recrapconnection[i][1]; 
  else if(found != 1) 
  {if(activeindex>=n_maxp) checkrapconnection(); 
   if(activeindex<n_maxp)
    for (i=((rid_*2*n_max)+n_max);i<((rid_*2*n_max)+n_maxp+n_max);i++)
    { j=0;
      flag=0;
      while(j<n_maxp)
      if(recrapconnection[j++][1]==(float)i) {flag=1; break;}
      if(flag!=1) break; 
    }
   if(flag==1) return -1;
   recrapconnection[activeindex][0]=(float)id;
   recrapconnection[activeindex][1]=(float)i;
   recrapconnection[activeindex++][2]=TIME;
  }
return i;
}

/* This fuction check all the rap connections to see whether any are idle/expired. If any connection is in GrayList that means the rap connection is started so we dont remove 
it. Otherwise we check the RapExp time.
recrapconnection[i][0] is the id of parent
recrapconnection[i][1] is the index of rap connection in NS
recrapconnection[i][2] is the most recent time that the peer receives a message from this id
*/
void RPALApp::checkrapconnection()
{ int i=0,j=0,active=0;
   signalingmessage2 = new RPRIMESigMSG;
  signalingmessage2->request_flag_=-1;
  signalingmessage2->curbitmap=NULL;
  signalingmessage2->list_=NULL;
  signalingmessage2->request_list_=NULL;
  signalingmessage2->length=0;
  signalingmessage2->extlen=0;
  signalingmessage2->reglen=0;
  for(i=0;i<activeindex;i++)
  {active=0;
   for(j=0;j<Grayindex;j++)
   if( recrapconnection[i][0]==(float)GrayList[j].nodid ) 
   {active=1;	
    break;
   }
   if(active==0) 
    if(TIME-recrapconnection[i][2] > RapExp) 
    {signalingmessage2->sprime_id_=(int)recrapconnection[i][0];
     signalingmessage2->rprime_id_=(int)recrapconnection[i][0];
     signalingmessage2->emptrap=-1;
     int sid=(int)recrapconnection[i][0];
     assert(sid<MAX_NODES);
     activeindex--;
     assert(activeindex>=0);
     recrapconnection[i][0]=recrapconnection[activeindex][0];
     recrapconnection[i][1]=recrapconnection[activeindex][1];
     recrapconnection[i][2]=recrapconnection[activeindex][2];
     recrapconnection[activeindex][0]=0;
     recrapconnection[activeindex][1]=0;
     recrapconnection[activeindex][2]=0;
     udname[rid_]->connect((ns_addr_t)srudp[sid]->faddr());
     sendudpRequest(-1,sid,0,0);
     if(activeindex<n_maxp) break;   
    }	
  }
 assert (activeindex<=n_maxp);
}

/* This function is called whenever a rap or tcp packet is received. It keeps track of lost packets. Calls extractcontent for extracting the reported bitmap,
updates DueNum and buffer state for the received packet.
*/
void RPALApp::process_rap_data(int size, AppData* data)
{	
	SPRIMEMessage* message = (SPRIMEMessage*) data;
	int i, id, layer, time, flag = 0,seq;
	if(stopped_) return;	
        int j=0;
	int temptime=0;
	id = message->sender_id_; 
	int listid=0,k=0,foundflag=0;
        layer = message->layer_id_;
        time = message->timestamp_;
        if(TIME>40) DEBUG_NumAggPkt2++;
        if(time>=0) temptime=time % MAX_BUFFER;
	for(k=0;k<Grayindex;k++)
 	 if(GrayList[k].nodid==id) {listid=k; foundflag=1;}
 	if(foundflag==0) {printf("TIME %f inconsistency %d %d %d %d\n", TIME,rid_,id,message->layer_id_,message->timestamp_); 
 	                  if(message->layer_id_>0 && message->timestamp_>0)
     	                  {
                            if (message->timestamp_ > BufEndIndex[message->layer_id_])          
                            {       BufEndIndex[message->layer_id_] = message->timestamp_;      
                                    bufindex[layer]=time % MAX_BUFFER;
                            }
                      	    if(buftailtimestamp[layer]<time) {buftailtimestamp[layer]=time; tailbuf[layer]=time % MAX_BUFFER;}
                            if (time < playtime)
                            {	
                	        DEBUG_Late[layer]++;			
                		return;
                            }
                      	    if(!startup && TIME>(startuptime+20)) DEBUG_NumAggPrime++;
  	                    if(TIME>40) DEBUG_NumAggPrime2++;
                            if (buf[layer][temptime].flag <= 0)
                            {	bufquality[temptime]++;
                		assert(bufquality[temptime]<=MAX_LAYER);
                		bufferlength++;
                                buf[layer][temptime].flag = 1;           
                               if(table[layer][temptime].flag>0)
                                table2[layer][temptime]=table[layer][temptime].flag;
                              else 
                                table2[layer][temptime]=1;  
                              table[layer][temptime].flag =-3;
                
                              spal[rid_]->fillcontent(time,layer); 	
                            }
                          } 
 	                  return;
 	                 }
        int ndistance=distance;
        
        if(message->dist!=GrayList[listid].dist)
        {
         ndistance=GrayList[listid].dist+1;
         for(i=0;i<Grayindex;i++)
         { if(ndistance>(GrayList[i].dist+1))
            { ndistance=GrayList[i].dist+1;  
            } 
         }
          if(!startup && ndistance!=distance) {DEBUG_avgdist+=distance*(TIME-DEBUG_prevavgdist);
                                       DEBUG_prevavgdist=TIME;
                          }
        }    
        if(ndistance!=distance) {assert(DEBUG_lastdist<=TIME);
                                 DEBUG_lastdistavg+=(TIME-DEBUG_lastdist);
                                 DEBUG_lastdist=TIME;
                                 DEBUG_distch++;
                                 distance_t=TIME;
                                 distance=ndistance;
                                }  
                                if(distance>10) {printf("distance is reset in %d %d \n",rid_,distance); distance=9;}
	seq = message->sequence_;
	int hopcou= message->hopc;
	int tempsize;
	tempsize=size;
	if(time!=-2 && time!=-1 && time!=-3 ) NumUseful[listid]++;
 	if(!startup && TIME>(startuptime+20)) {LossCount[listid] += ((size - 1 - EndSeqNo[listid])>0 ? (size - 1 - EndSeqNo[listid]) : 0); 
 	                          if(GrayList[listid].dist<distance) DEBUG_AGGdiff++;
 	                          else DEBUG_AGGsw++;
 	                         }
 	DEBUG_LossC2+=((size - 1 - EndSeqNo[listid])>0 ? (size - 1 - EndSeqNo[listid]) : 0);
 	if(id==0)
 	{if((size - 1 - EndSeqNo[listid])>0)
 	  { int counn=size - 1 - EndSeqNo[listid]; 	   
 	    while(counn!=0) {spal[0]->findloss(size-counn,rid_); counn--;}
 	  }  
 	}    
 	else {if((size - 1 - EndSeqNo[listid])>0)
   	     {int counn=size - 1 - EndSeqNo[listid];
             }
             }
	                                  
 	DEBUG_Nloss++;                                           
 	LossCount2[listid] += ((size - 1 - EndSeqNo[listid])>0 ? (size - 1 - EndSeqNo[listid]) : 0);
	if(size>=(EndSeqNo[listid]+1))
		EndSeqNo[listid] = size;
	NumPktRcvd[listid]++;               
        if(startup==0 && TIME>(startuptime+20)) 
          {Sender_TotPkt[listid]++;
	   DEBUG_NumAggPkt++;
	   if(time == -1 && layer == -1) DEBUG_TotExt++;
	  } 
        GrayList[listid].dist=message->dist;
        GrayList[listid].dist2=message->dist2;
	extractcontent(message->length,message->curbitmap,id,listid,message->tb,message->tp,message->tp2,message->repid,message->repbk);
        srtt[listid] = message->srtt_;
        if (time == -1 && layer == -1)
        {if(!startup && TIME>(startuptime+20)){
		
                DEBUG_ExtraPkt[listid]++;
	        }
	 else if(fastmode!=0 && seq==seqnum[listid])
	      {index[listid]=DueNumPkt[listid];
	       DueNumPkt[listid]=0;
		RFC(listid);
	      }
	                           
                return;
        }
        if ((time == -2 && layer ==-2 ) || (time == -3 && layer ==-3 )) 
        { if (!startup && TIME>(startuptime+20)) 
              { if(GrayList[listid].dist<distance) DEBUG_ContDif[listid]++;
                else DEBUG_ContSW[listid]++; 
                if(time == -2 && layer ==-2 ) {DEBUG_ExtraPkt2[listid]++;
                                               DEBUG_TotExt2++;
                                                  if(GrayList[listid].dist<distance) DEBUG_Extradif2++;
                                                    else DEBUG_Extrasw2++;}
                 else { DEBUG_ExtraPkt3++; if(GrayList[listid].dist<distance) DEBUG_Extradif3++;
                                                                        else DEBUG_Extrasw3++;
                      }
                                                                                                                            
		 NumConBT[listid]++;
	      }

        }
	        
	if (time!=-2 && time!=-3 && layer>=0 && layer<=MAX_LAYER)
	{if(startup==0 && TIME>(startuptime+20)) DEBUG_NumPRIMEPktRcvd[listid]++;
	
	 if (time > BufEndIndex[layer])          
         {       BufEndIndex[layer] = time;      
                bufindex[layer]=time % MAX_BUFFER;

         }
	 assert(time>=0);
	 if(id!=0 && !startup) assert(buftailtimestamp[layer]>=time);
	 assert(time<playtime+MAX_BUFFER);
	 if(buftailtimestamp[layer]<time) {buftailtimestamp[layer]=time; tailbuf[layer]=time % MAX_BUFFER;}
	 if (time < playtime)
	 {	
	        DEBUG_Late[layer]++;			
		return;
	 }
 	 if(!startup && TIME>(startuptime+20)) DEBUG_NumAggPrime++;
         if(TIME>40) DEBUG_NumAggPrime2++;
	 if(id!=0 && !startup)
          { 
            assert(buf[layer][temptime].flag != 0);	
          }  

         if (time<playtime)
         j=1;
	}	

	if (startup && firstcal )		
	{
		int tag = 0;
		for (i = 0; i < Grayindex; i++)
			if (srtt[i] != 0)
				tag++;
		if (tag!=0)
		{
			firstcal = 0;
			CalculateEWMABW();
		}
	}

	if (!startup && seq==seqnum[listid])
	  {	flag = 1;
	         if (Ack[listid]==0)
                       { 
                        Ack[listid]=1;
                       }
          }
         else if(startup && seq==seqnum[listid])
                       {if(Ack[listid]==0)
                          Ack[listid]=1;
                        flag=1;                    
                       }                                       	                                                                                      
        if(startup)               
	{for (i = index[listid]; i < index[listid] + DueNumPkt[listid]; i++)
	 {
		if (DuePkt[listid][i].layer_id == layer && DuePkt[listid][i].timestamp == time )
                 if(startup && seq==seqnum[listid]) 
                 {	if(Ack[listid]==0)
				Ack[listid]=1;
                        DueNumPkt[listid] -= (i - index[listid] + 1);
                        index[listid] = i + 1;
                        flag = 1;       
                        break;
                 }
	 }
	}
	if(time!=-2 && time!=-3) 
        {
         if(srcflag!=-1) { assert(distance==1);}

         assert(distance>0 && distance<=10);   
         
         if (buf[layer][temptime].flag <= 0)
          {	bufquality[temptime]++;
		assert(bufquality[temptime]<=MAX_LAYER);
		bufferlength++;
	  	if(hopcou<n_max)
	  	 buf[layer][temptime].hopcount=hopcou;	
	  	else buf[layer][temptime].hopcount=distance; 
	  	assert(time>=0 && time<(MAX_SIM_TIME*PKT_PER_SEC));
		if(startup==0 && TIME>(startuptime+20)) {if(hopcou<n_max) DEBUG_hopdist[listid][(int)hopcou]++;
			else {DEBUG_hopdist[listid][n_max]++; printf("hopcount error %d in %d from %d\n",hopcou,rid_,id);}
		}
                buf[layer][temptime].flag = 1;           
                
                if(id!=0)
                {if(!startup || tabqual[temptime]>=1) tabqual[temptime]--;
                } 
                if(table[layer][temptime].flag>0)
                  table2[layer][temptime]=table[layer][temptime].flag;
                else 
                  table2[layer][temptime]=1;  
                table[layer][temptime].flag =-3;
                
                if(spal[rid_]->stopped!=1 && TIME>(startuptime+20)) assert(tabqual[temptime]>=0);
                
                spal[rid_]->fillcontent(time,layer); 	
          }
          else if(!startup)			
           {     buf[layer][temptime].flag++;             
                 assert(table[layer][temptime].flag<0);
           }

/*           if(spal[0]->RateTab[distance][layer][time]==0)
            spal[0]->RateTab[distance][layer][time]=TIME;
           if(GrayList[listid].dist<distance)
            spal[0]->RedTab[distance][layer][time]++;
           
               
           if(GrayList[listid].dist>=distance)
            spal[0]->SWTab1[distance][layer][time]++;
           if(GrayList[listid].dist==distance)
            spal[0]->SWTab2[distance][layer][time]++;
 */         
          if(!startup && TIME>80)
          {if(GrayList[listid].dist<distance)
             DEBUG_upper++;
           else 
             DEBUG_down++;
           DEBUG_totalpkt++;
          }                                                         
                               
        }
	 if (flag && startup && !firstcal && fastmode!=0) 
		RFC(listid);
	 if (startup){
		Startup();
         }
}

/*used only during startup, adjust designated playtime and duration of startup phase.
startplay -> determines the duration of startup phase minus 2* delta in the fastmode
startpoint -> is the first timestamp being played
playtime2 -> is the fake palytime during startup phase 
here we initially dont have bw estimation so we should adjust DuePkt, DueNumPkt.
when BW is known, then find ratio of a sender's BW to slowest parent
The scheduling is different in startup phase, we only care for one description of each timestamp. Identify a timestamp and then a description (layer) and parent for that
*/
void RPALApp::SendRequestToAll()
{	
	int i=0;
        for (i=0;i<Grayindex;i++)
            if(GrayList[i].nodid==0)
               srcflag=i;
        int ndistance=distance;       
        if(srcflag!=-1) {ndistance=1;
                        } 
        else {ndistance=9;
             }
             
        int j=0,Tempstart1,Tempstart2,sum=0,flag,sum2=0,num=0;
	float avg1=0,avg2=0;
	int nor=1;
	 for(i=0;i<Grayindex;i++)
	 { if(firstduealoc[i]==0)
	   { DuePkt[i]=(PktList*) malloc(DueSize[i]*sizeof(PktList));
	     firstduealoc[i]=1;
	   }
	   if((GrayList[i].dist+1)<ndistance) ndistance=GrayList[i].dist+1;
	 }
	 if(ndistance!=distance) {assert(DEBUG_lastdist<=TIME);
                                  DEBUG_lastdistavg+=(TIME-DEBUG_lastdist);
                                  DEBUG_lastdist=TIME;
                                  DEBUG_distch++;
                                  distance_t=TIME;
                                  distance=ndistance;
                               }
         lastSend=TIME;                       
	 bzero(tablemirror,MAX_BUFFER*MAX_LAYER*sizeof(int));
	 bzero(tabqualmirror,MAX_BUFFER*sizeof(int));
	 if(startpoint==-1)
	{	for(i=0;i<Grayindex;i++)
		{  
		   if(GrayList[i].tplay!=-2000) 
			{sum+=GrayList[i].tplay;
			 num++;	
			 sum2+=GrayList[i].tbuf;
			}
		}
		if(num==0)
		{ for(i=0;i<Grayindex;i++)
                 {
                   if(GrayList[i].bufsize!=0)
			{num++;
			 sum2+=GrayList[i].tbuf;
			 sum+=GrayList[i].tplay2;
			}
		 }
		}
		if (num==0) {firstfill=1;
			return;
			}
        
		avg2=sum/num+srcwin*PKT_PER_SEC;
	        
	}
	if (firstrequest && startpoint==-1) {
		 if(num!=0)
		 {
		  avg1=sum/num;
		  Tempstart1=(int) (avg1+avg2)/2;
		  if(Tempstart1>=0) startpoint=Tempstart1; 
		  else {nor=0;
			startpoint=0;
		       }
		  if(Tempstart1>MaxTab) Tempstart1=MaxTab;
		 }
		  float randd=rand() % asyn + drand48();
		  randd=randd/2;
		  int neg=rand() % 2;

 		  if(neg==0) neg=-1;
		  else neg=1;
		  neg=0; 
		 if(nor) 
		 { if((avg2-avg1)/(2*PKT_PER_SEC) - (2 * 3)+(randd*neg)>0)
			{ startplay=TIME+(avg2-avg1)/(2*PKT_PER_SEC)+randd*neg - 2 * 3;
			  assert(startplay>=0);
			  playtime2=startpoint-(int)(avg2-avg1)/2;
			  fastmode=-1;
			  assert(startplay>0);
			}
		   else {printf("warning startplaying is not optimal %d %f %f %f %f\n", rid_,(float)(avg2-avg1)/(2*PKT_PER_SEC),TIME,avg2,avg1);
			startplay=0;
			assert(startplay>=0);
			if(((avg2-avg1)/(2*PKT_PER_SEC)+randd*neg)>0)
  			  fastmode=TIME+(avg2-avg1)/(2*PKT_PER_SEC)+randd*neg;
  			else fastmode=TIME+(avg2-avg1)/(2*PKT_PER_SEC);  
  			assert(fastmode>TIME);
			playtime2=startpoint-(int)(avg2-avg1)/2;
		       }
		 }
		 else {
			startplay=TIME+randd*neg+(startpoint-avg1)/PKT_PER_SEC-(2 * 3);
			assert(startplay>=0);
			playtime2=(int)avg1;
			fastmode=-1;
			assert (startplay>0);
		     }
		   playtime=startpoint;
	}
 
	int Tempbuf1, Tempbuf2;
	Tempstart1= startpoint>MaxTab ? MaxTab : startpoint;
        Tempstart2= MaxTab;
	assert(Tempstart2<Tempstart1+MAX_BUFFER);

	if (startplay==0) {Tempstart2 = ( Tempstart1+(int)(6*PKT_PER_SEC)>MaxTab ? MaxTab : (Tempstart1+(int)(6*PKT_PER_SEC)) );
		 	  printf("%d entering fast mode %f \n",rid_,TIME);
			  }
	
	
	if (firstrequest || WarmUp==1)
	{
		firstrequest = 0;
		bzero(index, n_maxp*sizeof(int));
		Tempbuf1=Tempstart1 % MAX_BUFFER;
		Tempbuf2=Tempstart2 % MAX_BUFFER;
		for (i = 0; i < Grayindex; i++)
		{	assignindex[i]=0;
			index[i]=0;
			Fullsender[i]=0;
			DueNumPkt[i] = START_PKT;
			RemNumPkt[i]=DueNumPkt[i];
		}
		ActualPkt=START_PKT*Num_Senders;
	}
	else {	int Ratio[n_maxp], total = 0, rounds;
		bzero(index, n_maxp*sizeof(int));
                float MinBW = minbw(), factor;
		Tempbuf1=Tempstart1 % MAX_BUFFER;
                Tempbuf2=Tempstart2 % MAX_BUFFER;
                assert(WarmUp == 0);
		num=0;
                for (i = 0; i < Grayindex; i++)
                {	index[i]=0;
			Fullsender[i]=0;
			DueNumPkt[i]=0;
			if(MinBW!=0)
                         Ratio[i] = (int)(ewmabw[i] / MinBW);
                        else {DueNumPkt[i]=START_PKT; Ratio[i]=START_PKT; }
			if(Ratio[i]==0 ) {Ratio[i]=START_PKT; DueNumPkt[i]=START_PKT; continue;}
			num++;
                        total += Ratio[i];
                }
		factor = START_PKT * num/ (float)total;
		if (factor >= 1)
                        rounds = (int)factor;
                else
                        rounds = 1;
		sum=0;
		for(i=0;i<Grayindex;i++)
		{	 if (factor < 1)
                                Ratio[i] = (int)(Ratio[i] * factor);
                       if(DueNumPkt[i]!=START_PKT) DueNumPkt[i] = (int)(Ratio[i] * rounds);
			if(DueNumPkt[i]>DueSize[i])
			{ 
			  while(DueSize[i]<DueNumPkt[i]) DueSize[i] *= 2;
			  assert(DueSize[i]>=DueNumPkt[i]);
		          DuePkt[i]=(PktList*) realloc (DuePkt[i],DueSize[i] * sizeof(PktList));
			}
			bzero(DuePkt[i],DueSize[i]*sizeof(PktList));
			sum+=DueNumPkt[i];
			if (DueNumPkt[i] > 0 )
                              { 
				 RemNumPkt[i]=DueNumPkt[i];
				 assignindex[i]=0;
			      }
                        else if(DueNumPkt[i]==0)
                               { 
				 RemNumPkt[i]=DueNumPkt[i];
				 Fullsender[i]=1;
                                 assignindex[i]=0;
			       }
			
		}
		ActualPkt=sum;
		
	}

	int length=(Tempstart2>MaxTab ? Tempstart2 : MaxTab);
	length=length-Tempstart1+1;
	int tabindex;
	playindex=0;
	int tempbufamt2[MAX_BUFFER];
	bzero(tempbufamt2,sizeof(tempbufamt2));

	memcpy(tempbufamt2,bufquality,MAX_BUFFER * sizeof(int));
	 int shuf;
	 int tempshuf;
	flag=1;
	int amt=1; 
	int temporary1=Tempstart1;
	assert(MaxTab>=Tempstart1);
	int State[MAX_LAYER+1][MaxTab-Tempstart1+10];
	int stateindex[MAX_LAYER+1];
	bzero(stateindex,(1+MAX_LAYER)*sizeof(int));
	bzero(State,sizeof(State));
	int temporary2=Tempstart2;
	int m=0,l=0;
	Tempbuf2=MaxTab % MAX_BUFFER;
	
	if(Tempbuf1<=Tempbuf2)
        {	for (i = Tempbuf1; i <= Tempbuf2; i++)
                  {     
			if(temporary1+i-Tempbuf1<playtime) {tempbufamt2[i]++;continue;}
                        if(temporary1+i-Tempbuf1>MaxTab) {tempbufamt2[i]++;break;}
                        assert(tempbufamt2[i]<=MAX_LAYER && tempbufamt2[i]>=0);
                        assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
                        tabqualmirror[i]=tabqual[i];
                        if(tabqual[i]<=0 && srcflag==-1) continue;
			if(startplay!=0)
			{if( (i+temporary1-Tempbuf1)<(LookAhead*PKT_PER_SEC))
				{if(tempbufamt2[i]==0) State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;}
			 else 
			 { 	 assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
				 State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;
			 }
			}
		  
		  	if(startplay==0 && tempbufamt2[i]==0) 
			  { if((i-Tempbuf1+temporary1)>temporary2)
				State[MAX_LAYER][stateindex[MAX_LAYER]++]=i;
			    else State[0][stateindex[0]++]=i;
			  }
		  }
	}
	else    
	{	for (i = Tempbuf1; i < MAX_BUFFER; i++)
                {      if(temporary1+i-Tempbuf1<playtime) {tempbufamt2[i]++;continue;}
                        if(temporary1+i-Tempbuf1>MaxTab) {tempbufamt2[i]++;break;}
                        assert(tempbufamt2[i]<=MAX_LAYER && tempbufamt2[i]>=0);
                        assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
                        tabqualmirror[i]=tabqual[i];
                        if(tabqual[i]<=0 && srcflag==-1) continue;
                      if(startplay!=0)
			{if( (i+temporary1-Tempbuf1)<(LookAhead*PKT_PER_SEC))
                               { if(tempbufamt2[i]==0) State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;}
                         else 
                         { assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
                           State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;
                         }
			}

                        if(startplay==0 && tempbufamt2[i]==0) 
                          { if((i-Tempbuf1+temporary1)>temporary2)
                                State[MAX_LAYER][stateindex[MAX_LAYER]++]=i;
                            else State[0][stateindex[0]++]=i;
                          }
                }
		for (i = 0; i <= Tempbuf2; i++)
		{       if(Tempstart2+i-Tempbuf2<playtime) {tempbufamt2[i]++;continue;}
                        if(Tempstart2+i-Tempbuf2>MaxTab) {tempbufamt2[i]++;break;}
                        assert(tempbufamt2[i]<=MAX_LAYER && tempbufamt2[i]>=0);
                        assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
                        tabqualmirror[i]=tabqual[i];
                        if(tabqual[i]<=0 && srcflag==-1) continue;
			if(startplay!=0)
                        { if((i-Tempbuf2+Tempstart2)<(LookAhead*PKT_PER_SEC))
                               { if(tempbufamt2[i]==0) State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;}
                          else 
                          { assert(stateindex[tempbufamt2[i]]<=(MaxTab-Tempstart1+1));
                            State[tempbufamt2[i]][stateindex[tempbufamt2[i]]++]=i;
                          }
			}

                        if(startplay==0 && tempbufamt2[i]==0) 
                          { if((i-Tempbuf2+Tempstart2)>temporary2)
                                State[MAX_LAYER][stateindex[MAX_LAYER]++]=i;
                            else State[0][stateindex[0]++]=i;
                          }
                }
	}  
	int shufindex=0,tempamt=0,tempamt2=0,tempi=0;
	int tempactualpkt=ActualPkt;
	int fastflag=1;
	bzero(AssBWRatio,n_maxp*sizeof(float));
	
	while(flag)
	{
	    assert(amt<=MAX_LAYER);
	    shufindex=0;
	    if(startplay!=0) 
	    {	for(i=0;i<amt;i++)
		  shufindex=shufindex+stateindex[i];			
               for(i=0;i<shufindex;i++)
                { shuf=rand() % shufindex;
		  tempamt=0;
		  tempamt2=0;
		  tempi=0;

		  for(m=0;m<amt;m++)
		  { tempamt=tempamt+stateindex[m];
		    if(shuf>=tempamt)
			continue;
		    else break;
		  }
		  for(l=0;l<amt;l++)
                  { tempamt2=tempamt2+stateindex[l];
                    if(i>=tempamt2)
                        continue;
                    else break;
                  }
		  tempi=i-(tempamt2-stateindex[l]);
		  shuf=shuf-(tempamt-stateindex[m]);
                  tempshuf=State[m][shuf];
                  State[m][shuf]=State[l][tempi];
                  State[l][tempi]=tempshuf;
                }
	   }
	   else 
	   { if(fastflag)
		shufindex=stateindex[0];
	     else
	 	shufindex=stateindex[0]+stateindex[MAX_LAYER];
	     for(i=0;i<shufindex;i++)
	     {    shuf=rand() % shufindex;
	          tempamt=stateindex[0];
                  tempamt2=0;
                  tempi=0;
		  if(fastflag)
		  {tempshuf=State[0][shuf];
		   State[0][shuf]=State[0][i];
		   State[0][i]=tempshuf;
		  }
		  else
		  { if(i>=stateindex[0])
		    {tempi=i-stateindex[0];
		     tempshuf=State[MAX_LAYER][tempi];
		     if(shuf>=stateindex[0])
		     {State[MAX_LAYER][tempi]=State[MAX_LAYER][shuf-stateindex[0]];
		      State[MAX_LAYER][shuf]=tempshuf;
		     }
		     else {State[MAX_LAYER][tempi]=State[0][shuf];
			   State[0][shuf]=tempshuf;
			  }
		    }
		    else 
		    {tempshuf=State[0][i];
		     if(shuf>=stateindex[0])
		     {State[0][i]=State[MAX_LAYER][shuf-stateindex[0]];
		      State[MAX_LAYER][shuf]=tempshuf;			  
		     }
		     else 
		     {State[0][i]=State[0][shuf];
		      State[0][shuf]=tempshuf;
		     }
		    }
                  }
	     }
           }
	 TargetPkt=5000;
	 int layrand;
	 for(i=0;i<shufindex;i++)
	 {	
		tempamt=0;
		if(startplay!=0) 
		{   for(m=0;m<amt;m++)
                  { tempamt=tempamt+stateindex[m];
                    if(i>=tempamt)
                        continue;
                    else break;
                  }
		}
		else 
		{ m=0;
		  if(fastflag || i<stateindex[0])
		   tempamt=stateindex[0];
		  else 
		  {tempamt=stateindex[0]+stateindex[MAX_LAYER];
		   m=MAX_LAYER;}
		}   
		tempi=i-(tempamt-stateindex[m]);
		tabindex=State[m][tempi];
                assert(tabqual[tabindex]>0 || srcflag!=-1);
                flag=-1;
		if(tabqualmirror[tabindex]>0)
		{
		   flag=assignglobrare(tabindex);
		}
		else flag=-1; 
		if(flag==-1) 
		 {if(srcflag!=-1) 
		   { 	int tss;
		        int tempp=playtime % MAX_BUFFER;
		        if(tabindex<tempp) tss=playtime+(MAX_BUFFER-tempp)+tabindex;
		        else tss=tabindex-tempp+playtime;	
		        assert((tss-playtime)<=MAX_BUFFER && tss>=playtime);
			if(RemNumPkt[srcflag]>0) 
				 {assert(tss>=0);
				  flag=-1;
				  layrand=rand() % MAX_LAYER;
				  assert(layrand<MAX_LAYER);		  
		                  for(j=layrand;j<MAX_LAYER;j++)
                		  {if(tablemirror[j][tabindex]!=-2 && table[j][tabindex].flag!=-3 && buf[j][tabindex].flag<=0 && tss>=GrayList[srcflag].tplay)
	                            { assert(j>=0);
	  			     SenderAssign(srcflag,tss,j); 
				     flag=1; break;
				    }
				  }
				  if(layrand!=0 && flag!=1)
				  {for(j=0;j<layrand;j++)
                		   {if(tablemirror[j][tabindex]!=-2 && table[j][tabindex].flag!=-3 && buf[j][tabindex].flag<=0 && tss>=GrayList[srcflag].tplay)
	                            { assert(j>=0);
	  			      SenderAssign(srcflag,tss,j); 
				      flag=1; break;
				    }
				   }				
				  }
				 }
			else break;
		   }
		}
		if(ActualPkt<=0) break;
	 }


  	 if( (shufindex==0) || (shufindex< tempactualpkt))
                   { if(amt<2 && startplay!=0) {amt++;
                     if ( (Tempstart1+(int)(LookAhead*PKT_PER_SEC))<Tempstart2 )
                      { Tempbuf1=(Tempstart1+(int)(LookAhead*PKT_PER_SEC)) % MAX_BUFFER;
			temporary1=Tempstart1+(int)(LookAhead*PKT_PER_SEC);
		      }
		     else flag=0;
		    }
                    else if(amt<=2 && amt<MAX_LAYER && startplay!=0) {amt++;
							 }
		    
			    		        
		    else flag=0;
		    if(startplay==0 && (shufindex< (int)(0.9* tempactualpkt)) && fastflag) 
							  {fastflag=0;
							  flag=1;}
                   }
         else flag=0;
	}
	int howmany=0;
	for (i = 0; i < Grayindex; i++)
	{	
		if(assignindex[i]!=0 || assignindex[i]==0) 
                { while(RemNumPkt[i]>0) {DuePkt[i][assignindex[i]].timestamp=-2;
                                          DuePkt[i][assignindex[i]++].layer_id=-2;
                                          RemNumPkt[i]--;
                                         }
                   assert(RemNumPkt[i]==0);

		 DueNumPkt[i]=assignindex[i];
		 DueNumPktCons[i]=DueNumPkt[i];
		 seqnum[i]++;
		 if(howmany<1) SendRequest(GrayList[i].nodid, DuePkt[i], DueNumPkt[i],0);
		 else sending_time[i]=0;
		 howmany++;
		}
	}
	if(howmany==0) {firstfill=1;
			firstrequest=1;
			}
}

/* This function sends a udp message to bootstrap
*/
void RPALApp::SendTobootstrap(int rflag,int num)
{  int nbytes;
   tobootmessage_ = new RPRIMEMSGBoot;
   tobootmessage_->req_flag_ = rflag;
   tobootmessage_->rec_id_ = rid_;
   tobootmessage_->num_= num; 
   nbytes=tobootmessage_->size();
   printf("%f peer %d request from bootstrap %d %d %d\n",TIME,rid_,num,rflag,Grayindex);
   assert(rid_<MAX_NODES);
   
   sudp_->sendmsg(nbytes, tobootmessage_, 0);
   lasttimeboot=TIME;
}   

/*This functions sends a udp request message (flag) to any peer
*/
void RPALApp::SendRequest(int id, PktList *rlist, int length,int flag)
{
	int i=0, nbytes,listid;
	PktList *temp;
	 if (stopped_) return;   
        if(length==0) return;
                assert(length != 0);
        if(startup==0 && TIME>(startuptime+20)) DEBUG_TotalPktRequested += length;
        for(i=0;i<Grayindex;i++)
         if(GrayList[i].nodid==id) {listid=i; break;}
         
        if (length > 0)
        {	assert(length<=DueSize[listid]);
                temp = (PktList*) malloc(length * sizeof(PktList));
                memcpy(temp,rlist,length*sizeof(PktList));

        }
        else
                temp = NULL;
  printf("Send :%f: id = %d, num = %d seqnum %d in %d\n", TIME, id, length,seqnum[listid],rid_);
  sending_time[listid]=TIME;
  signalingmessage_ = new RPRIMESigMSG;
  signalingmessage_->list_=NULL;
  signalingmessage_->curbitmap=NULL;
  signalingmessage_->request_flag_=1;
  signalingmessage_->rprime_id_=rid_;
  signalingmessage_->request_list_=temp;
  signalingmessage_->emptrap=findrap(id);
  signalingmessage_->length=length;
  signalingmessage_->extlen=extralength[listid];
  signalingmessage_->reglen=reglength[listid];
  signalingmessage_->seq_=seqnum[listid];
  signalingmessage_->tp=playtime;
  signalingmessage_->tb=WindowPkt;
  signalingmessage_->sprime_id_=0;
  nbytes=signalingmessage_->size();
  Ack[listid]=0;
  assert(id<MAX_NODES);
        udname[rid_]->connect((ns_addr_t)srudp[id]->faddr());
  udname[rid_]->send(nbytes,signalingmessage_);
}


float RPALApp::maxsrtt()
{
        int i=0;
        float max = 0;
        for (i = 0; i < Grayindex; i++)
                if (srtt[i] > max)
                        max = srtt[i];
        return max;
}


float RPALApp::totbw()
{
        int i=0;
        float tot = 0;
        for (i = 0; i < Grayindex; i++)
                tot += ewmabw[i];
        return tot;
}
float RPALApp::totbw2()
{
	int i=0;
	float tot=0;
	for(i=0;i<Grayindex;i++)
		tot+=ewmausebw[i];
	return tot;
}

float RPALApp::minbw()
{
        int i=0;
        float min;
        for(i=0;i<Grayindex;i++)
          if(ewmabw[i]!=0) {min=ewmabw[i]; break;}
        if(min==0) return min;
        for (i = 0; i < Grayindex; i++)
                if (ewmabw[i] < min && ewmabw[i]!=0)
                        min = ewmabw[i];
        return min;
}
