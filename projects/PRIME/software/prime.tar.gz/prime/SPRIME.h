// Copyright (c) 2008 by the University of Oregon
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Oregon, Computer and Information
// Sciences Department, Mirage Lab.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF Oregon makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// SPRIME.h
//      Header Code for the 'Sender Agent' 
//
// Author: 
//   Nazanin Magharei (nazanin@cs.uoregon.edu)
//

#ifndef ns_spal_h
#define ns_spal_h

typedef struct SendList
{
        int layer_id;
        int timestamp;
        float time;
        int seqq;
        };

class PlayoutTimer : public TimerHandler
{
     public:
             PlayoutTimer(SPALApp *a) : TimerHandler() { a_ = a; }
     protected:
             void expire(Event *e);
             SPALApp *a_;
};

class SPALApp : public Application
{
    public:
        SPALApp();
        ~SPALApp() {}

        void process_data(int size, AppData* data){}
        void process_udp_data(int size, AppData* data);
        void process_rap_data(int size, AppData* data) {size=1;}
	AppData* get_prime_data(int& nbytes, int rapaddr);
        int command(int argc, const char*const* argv);
        void PktToRec(int);
        void source_opt(int ,int *, int *);
        int findemptrap(int);
        void findloss(int seqq,int rid);
        void fillcontent(int,int);
        void fillnew(int,int);
        PktList *buffermap[n_max];
        int *buffersize;
        int *drainindex;
        int AboutToRec(int layer, int ts,int tempid);
        void stop();
        void sendingupdate();
        void startplaying();
        int sid_,n_maxp;
        void setid(int id) {sid_=id;};
        int requestindex;
        int datapkt;
        int *startindex;
        int playtime_,playtime2;
        int startsending;
        int stopped;
//        float GenTime[MAX_SIM_TIME*PKT_PER_SEC];
        float * GenTime;
        ReceiverList *reclist;
        int *first;
        int population;
    protected:
        PlayoutTimer playtimer_;
    private:
	RapAgent *rap_;
	UdpAgent *udp_;
	SPRIMEMessage *message_;
	RPRIMESigMSG * reply;
	int SRC_Win,SRC_D,DEBUG_opt,DEBUG_opt2,DEBUG_dupreq,DEBUG_swap;
	int bitindex,tempindex,DEBUG_lossrecov;
	int *numbk_,*DEBUG_OverCount,*extlength,*reglength;
	int DEBUG_Totext,DEBUG_Totreg,DEBUG_Tot,DEBUG_TotOverext,DEBUG_TotOverreg,DEBUG_TotOver;
	float DEBUG_OverWrite,*DEBUG_Overext,*DEBUG_Overreg,*DEBUG_Over;
	int firstreceiver; //for the source to start playing
	int *index_,*listsize,*firstseq;
	SentList * SentPkt;
	int extra,DEBUG_Aggsend,DEBUG_Aggsend1,DEBUG_Aggsend2,DEBUG_Aggsend3,DEBUG_AggExtra,DEBUG_Aggsend4;
	int *num_;
	int *recbngindex,*recendindex;
	PktList * curbitma;
	PktList * bitmabk[n_max];
	int DEBUG_Requested[n_max][MAX_LAYER];
        int *DEBUG_BTReq;
	SendList *list_[n_max];
	int *firstlistaloc;
	int * sendbuf[MAX_LAYER];
	int * sendbufts;
	int firstslide;
//	int *req;
	int *seq;
	int *repid;
	int startcou;
	float starttime;
	int *occupy;
	int *drainbk,*repbk;
	int *numExtra,late,late1,late2,late3;
	int redundant;
	int WindowStart_,WindowLast_,WindowPkt_;
	SendList Receiving[n_max][2010];
	void accessbuf();
	void start_all();
	void zero_all();
	void newrap(int,int);
	void process_request(int,int,PktList*,int,int,int,int,int);
	void removeid(int,int);
	void addid(int,int,int,int,int,int);
	int sendbitmap(int,int);
	int *LossReq,*LossStart,*seqStart;
	int MAX_TS;
	float *ReqTime;
	int tr_id,tracefile,ldump;
	float tr_sttime, tr_ftime,sdump;
	int FILEEND,dump;
        void slidewindow();
        void Sendudpfromsource(int,int,int);	
        void sendudp(int,int,int,int,int);
};

  
#endif
