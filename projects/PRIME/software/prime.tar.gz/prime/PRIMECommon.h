// Copyright (c) 2008 by the University of Oregon
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Oregon, Computer and Information
// Sciences Department, Mirage Lab.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF Oregon makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// PRIMECommon.h 
//      Header file 
//
// Author: 
//   Nazanin Magharei (nazanin@cs.uoregon.edu)
//

#ifndef ns_pals_common_h
#define ns_pals_common_h

#include <stdio.h>
#include <assert.h>
#include "agent.h"
#include "node.h"
#include "packet.h"
#include "rap.h"
#include "udp.h"
#include <time.h>
//#include <mcheck.h>
//#include "memcheck.h"

#define PKT_SIZE 	1000	// packet size, in bytes
#define Rec_Th		3	//threshhold for start sending in source
#define PKT_PER_SEC	20	//default is 20
#define MAX_BUFFER      3000	//default is 4000
#define n_max		15
#define n_min		10
#define MAX_NODES	200
#define MAX_LAYER 	6	//default is 10		
#define MAX_SIM_TIME 	6000	// maximum simulation time in seconds
#define START_PKT	50 	// number of pkts per sender asked for during startup
#define TIME		Scheduler::instance().clock()
#define ExpTh		50	//expiration timeout
#define RapExp		1	//expiration time for an idle rap connectio
#define Heartbeat	20
#define TryEstab	1
#define BitMap_TH	0.2	//asking for bitmap again

typedef struct PktList
{
        int layer_id;
        int timestamp;
        int priority;
};

typedef struct SentList		//this struct is for the source and receivers
{
        int ts;
        int lay;
        int id;
};

typedef struct PktListBoot
{
        int parent_id;
        float uptime;
};
                        
typedef struct ReceiverList
{
       int	id;
       int	rapport;
       int  recaddr; 
       int listid;
       float time;
       int active;
};

typedef struct nodelist
{
        float uptime;
        float ttl;
        int nodid;
        int dist;
        int dist2;
        int tbuf;
        float rtt;
        int bufsize;
        int tplay;
        int tplay2;
        float BW;
};
//class SPRIMEMSGBoot : public AppData
//{
//    public:
//            SPRIMEMSGBoot() : AppData(RPAL_DATA) {}
           
//            int size() const { return sizeof(SPRIMEMSGBoot); }
//            AppData* copy() { return new SPRIMEMSGBoot(*this); }
                            
//            PktListBoot *list_;
//            int length;
//};


class RPRIMEMSGBoot : public AppData
{
    public:
            RPRIMEMSGBoot() : AppData(RPRIME_Boot) {}

            int size() const { return sizeof(RPRIMEMSGBoot); }
            AppData* copy() { return new RPRIMEMSGBoot(*this); }
            
            int rec_id_;
            int req_flag_;
            int num_;
};

class RPRIMESigMSG : public AppData
{
    public:
            RPRIMESigMSG() : AppData(RPRIME_Sig) {}

            int size() const { return sizeof(RPRIMESigMSG); }
            AppData* copy() { return new RPRIMESigMSG(*this); }
	    void freepoint(AppData*);
            PktListBoot *list_;
            int length;
            int extlen;
            int reglen;
            int rprime_id_;
            int sprime_id_;
            int request_flag_; // 0 for content bitmap
            int emptrap;            
            PktList *request_list_;
	    PktList *curbitmap;
            int seq_;
            int dist;
            int dist2;
            int ts;	
            int tp; 	//playtime
            int tp2;
            int tb;	//tmax
            int repid;
            int repbk;
};
                                                    
class RPALMessage : public AppData
{
    public:
        RPALMessage() : AppData(RPAL_DATA3) {}

	int size() const { return sizeof(RPALMessage); }
	AppData* copy() { return new RPALMessage(*this); }

        PktList *list_;
        int length_;
        int seq_;
        int id_;
};

class SPRIMEMessage : public AppData
{
    public:
    SPRIMEMessage() : AppData(SPRIME_MSG) {}
            
    int size() const { return PKT_SIZE; }
    AppData* copy() { return new SPRIMEMessage(*this); }
    void freepoint(AppData*);                            
    int sender_id_;         // which sender
    int layer_id_;          // which layer packet belongs to
    int timestamp_;         // timestamp of the packet in stream
    int sequence_;          //sequence number of the request
    double srtt_;           // srtt obtained from underlying RAP agent
    int hopc;
    int fec;
    int length;
    int tb;
    int tp;
    int tp2;
    int repid;
    int dist;
    int dist2;
    int repbk;
    PktList * curbitmap;	//bitmap of available content, frequently or event driven based is updated
    };
    
class SPALApp;
                                                                    
class SPALMessage : public AppData
{
    public:
        SPALMessage() : AppData(SPAL_DATA) {}

        int size() const { return PKT_SIZE; }
        AppData* copy() { return new SPALMessage(*this); }

        int sender_id_;         // which sender
        int layer_id_;          // which layer packet belongs to
        int timestamp_;         // timestamp of the packet in stream
        int sequence_;		//sequence number of the request
        double srtt_;           // srtt obtained from underlying RAP agent
};
class SPALApp;

class RPALApp;

//SPALApp * spal[MAX_NODES+1];
//RPALApp * rprime[MAX_NODES+1];
//UdpAgent * udname[300];
//RapAgent * rname[(MAX_NODES+1)*60];
//RapAgent * srrap[30];
//UdpAgent * srudp[MAX_NODES+1];


#endif
