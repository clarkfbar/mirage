In this directory:

   Topology files:
	topo.tcl
	coretopo.tcl

   Input files:
	rin.in - Input file for the receiver parameters
		 format: Size of delta, Half size of the buffer, peer degree, source degree, random seed

	sin.in - Input file for the sender parameters
 		 format: Half size of the buffer, source degree


To run the code type "ns topo.tcl".